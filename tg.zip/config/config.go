package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"

	_ "github.com/joho/godotenv/autoload"

	"github.com/amarnathcjd/gogram/telegram"
)

// No secret has a default value any more. Everything comes from the
// environment (or a local .env that is never committed).
var (
	ApiID    = getEnvInt("API_ID", 0)
	ApiHash  = getEnv("API_HASH", "")
	Token    = getEnv("BOT_TOKEN", "")
	LoggerID = getEnvInt64("LOGGER_ID", 0)
	MongoURL = getEnv("MONGO_URL", "")
	DbName   = getEnv("DB_NAME", "xydbbrc")

	OwnerID = getEnvInt64("OWNER_ID", 0)
	Owner   *telegram.UserObj

	// MandatoryChannels is OPT-IN. Accounts are only auto-joined to these
	// chats when the operator explicitly lists them (comma separated).
	MandatoryChannels = splitCSV(getEnv("MANDATORY_CHANNELS", ""))
)

func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

func getEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func getEnvInt(key string, def int) int {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	return n
}

func getEnvInt64(key string, def int64) int64 {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	n, err := strconv.ParseInt(v, 10, 64)
	if err != nil {
		return def
	}
	return n
}

func Load() error {
	missing := []string{}
	if ApiID == 0 {
		missing = append(missing, "API_ID")
	}
	if ApiHash == "" {
		missing = append(missing, "API_HASH")
	}
	if Token == "" {
		missing = append(missing, "BOT_TOKEN")
	}
	if MongoURL == "" {
		missing = append(missing, "MONGO_URL")
	}
	if OwnerID == 0 {
		missing = append(missing, "OWNER_ID")
	}
	if len(missing) > 0 {
		return fmt.Errorf("missing required env vars: %v", missing)
	}
	return nil
}

func ResolveOwner(client *telegram.Client) error {
	user, err := client.GetUser(OwnerID)
	if err != nil {
		return fmt.Errorf("failed to resolve owner (OWNER_ID=%d): %w", OwnerID, err)
	}
	if user == nil {
		return fmt.Errorf("failed to resolve owner (OWNER_ID=%d): user not found", OwnerID)
	}
	Owner = user
	return nil
}
