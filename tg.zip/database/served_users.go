package database

// AddServedUser records that a Telegram user has interacted with the bot.
func AddServedUser(id int64) error {
	return modifyBotState(func(s *BotState) bool {
		var added bool
		s.Users, added = addUnique(s.Users, id)
		return added
	})
}

// ServedUserIDs returns every user that has interacted with the bot — the
// read side for the owner-only /broadcast tool.
func ServedUserIDs() ([]int64, error) {
	state, err := getBotState()
	if err != nil {
		return nil, err
	}
	out := make([]int64, len(state.Users))
	copy(out, state.Users)
	return out, nil
}
