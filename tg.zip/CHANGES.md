# What was fixed
Secrets/config: no hardcoded token/API hash/owner (env only), .env files removed,
ENC_KEY from env (legacy key only for decrypting old data), .env.example added.
Security: delegation re-validated on every action + cleared on terminate; delegates
cannot add clients, phones hidden; unauthorized prompt rate-limited; mandatory
channel join is opt-in; OTP/2FA messages deleted; zip-bomb/size limits; HTML escaping.
Bugs: conversation channel race; client-slice data race; auto-react/view scoped to the
real owner + chat-id normalised + skips own messages + jitter; leave/stop/end now stops
the auto-rejoin monitor (no more rejoin loops), stale calls closed, Stop() outside lock;
flood-wait respects cancel; reject flow no longer hijacks other conversations; pending
requests expire; OTP listener no longer uses an invalid inline reply keyboard; DB save
failure reported; startup connects max 8 at once with retry; graceful shutdown; reactions
no longer fetched via the bot; per-download media dir + 500MB cap + startup cleanup.
Build: Dockerfile runs install.sh and installs ffmpeg; .dockerignore fixed; app.json/README.
Misc: Mongo index on token, dead code removed, bio row removed, phone-login OTP retry.
