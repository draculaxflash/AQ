package modules

import (
	"context"
	"fmt"
	"strings"
	"time"

	"tgmultibot/config"
	"tgmultibot/manager"

	"github.com/amarnathcjd/gogram/telegram"
)

func joinMandatoryChannels(ownerID int64) {
	if len(config.MandatoryChannels) == 0 {
		return // opt-in only
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()

	for _, ch := range config.MandatoryChannels {
		if ctx.Err() != nil {
			return
		}
		results := cm.JoinChannel(ctx, ownerID, ch)
		for _, r := range results {
			if r.Error != nil {
				sendTraceback(fmt.Sprintf("mandatory join failed for owner %d channel %s: %v", ownerID, ch, r.Error))
			}
		}
	}
}

func handleJoinChannelPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(
			"╭─❰ ❌ 𝗡𝗢 𝗖𝗟𝗜𝗘𝗡𝗧𝗦 ❱\n│\n"+
				"│  Add a client before joining a channel.\n│\n"+
				"╰─❰ ➕ Tap Add Client first ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ctx, ok := guardProcess(m, "Join Channel")
	if !ok {
		return nil
	}
	cg.SetListening(userID)

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))

	_, err := m.Reply(
		"╭─❰ 🔗 𝗝𝗢𝗜𝗡 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 / 𝗚𝗥𝗢𝗨𝗣 ❱\n│\n"+
			"│  Send a username or invite link.\n│\n"+
			"│  🌐  <b>Public</b>  ›  <code>@username</code>\n"+
			"│  🔒  <b>Private</b> ›  <code>t.me/+InviteHash</code>\n│\n"+
			"│  All your clients will attempt to join.\n│\n"+
			"╰─❰ ⌨️ Awaiting your link (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)
	if err != nil {
		ps.done(userID)
		return err
	}

	go joinChannelLoop(ctx, userID, ownerID)
	return nil
}

func joinChannelLoop(ctx context.Context, userID, ownerID int64) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in joinChannelLoop: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ 𝗧𝗜𝗠𝗘𝗗 𝗢𝗨𝗧 ❱\n│\n"+
					"│  Tap <b>🔗 Join Channel</b> to try again.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: telegram.Button.Clear()},
			)
		}
		return
	}

	if ctx.Err() != nil {
		return
	}

	text := strings.TrimSpace(msgs[0].Text())
	if text == "" {
		c.SendMessage(userID,
			"╭─❰ 📎 𝗧𝗘𝗫𝗧 𝗢𝗡𝗟𝗬 ❱\n│\n"+
				"│  Send a username or invite link,\n"+
				"│  not a file.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return
	}

	prog, _ := c.SendMessage(userID,
		fmt.Sprintf(
			"╭─❰ ⏳ 𝗝𝗢𝗜𝗡𝗜𝗡𝗚 ❱\n│\n"+
				"│  Trying with <b>%d</b> client(s)...\n│\n"+
				"╰─❰ — ❱",
			cm.Count(ownerID),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)

	if ctx.Err() != nil {
		if prog != nil {
			prog.Edit(
				"╭─❰ 🚫 𝗖𝗔𝗡𝗖𝗘𝗟𝗟𝗘𝗗 ❱\n│\n"+
					"│  Cancelled before joining.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
		}
		return
	}

	results := cm.JoinChannel(ctx, ownerID, text)

	joined, approvalPending, failed := 0, 0, 0
	var accountErrors []manager.AccountError
	var traceErrors []string

	for _, r := range results {
		switch {
		case r.Error != nil:
			failed++
			accountErrors = append(accountErrors, manager.AccountError{AccountID: r.AccountID, Err: r.Error})
			traceErrors = append(traceErrors, fmt.Sprintf("Account %d: %s", r.AccountID, r.Error.Error()))
		case r.InviteRequestSent:
			approvalPending++
		default:
			joined++
		}
	}

	if len(traceErrors) > 0 {
		sendTraceback(fmt.Sprintf("JoinChannel errors for user %d:\n%s", userID, strings.Join(traceErrors, "\n")))
	}

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))
	opts := &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)}

	if ctx.Err() != nil {
		result := fmt.Sprintf(
			"╭─❰ 🚫 𝗖𝗔𝗡𝗖𝗘𝗟𝗟𝗘𝗗 ❱\n│\n"+
				"│  ➕  <b>Joined</b>            ›  %d\n"+
				"│  ⏳  <b>Approval Pending</b>  ›  %d\n"+
				"│  ❌  <b>Failed</b>            ›  %d\n│\n",
			joined, approvalPending, failed,
		)
		if len(accountErrors) > 0 {
			summary := manager.SummarizeErrors(accountErrors)
			result += "╰─❰ ⚠️ See error summary below ❱\n\n" +
				manager.FormatErrorSummary(summary, "<b>Errors:</b>")
		} else {
			result += "╰─❰ — ❱"
		}
		if prog != nil {
			prog.Edit(result, opts)
		}
		return
	}

	var result string
	switch {
	case joined == 0 && approvalPending > 0:
		result = fmt.Sprintf(
			"╭─❰ 📨 𝗝𝗢𝗜𝗡 𝗥𝗘𝗤𝗨𝗘𝗦𝗧𝗦 𝗦𝗘𝗡𝗧 ❱\n│\n"+
				"│  ⏳  <b>Approval Pending</b>  ›  %d\n"+
				"│  ❌  <b>Failed</b>            ›  %d\n│\n"+
				"│  An admin must approve before the join\n"+
				"│  is complete.\n│\n",
			approvalPending, failed,
		)
	default:
		result = fmt.Sprintf(
			"╭─❰ ✅ 𝗝𝗢𝗜𝗡 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘 ❱\n│\n"+
				"│  ➕  <b>Joined</b>            ›  %d\n"+
				"│  ⏳  <b>Approval Pending</b>  ›  %d\n"+
				"│  ❌  <b>Failed</b>            ›  %d\n│\n",
			joined, approvalPending, failed,
		)
	}

	if len(accountErrors) > 0 {
		summary := manager.SummarizeErrors(accountErrors)
		result += "╰─❰ ⚠️ See error summary below ❱\n\n" +
			manager.FormatErrorSummary(summary, "<b>Errors:</b>")
	} else {
		result += "╰─❰ ✨ All done ❱"
	}

	if prog != nil {
		prog.Edit(result, opts)
	} else {
		c.SendMessage(userID, result, opts)
	}
}

func escapeHTML(s string) string {
	s = strings.ReplaceAll(s, "&", "&amp;")
	s = strings.ReplaceAll(s, "<", "&lt;")
	s = strings.ReplaceAll(s, ">", "&gt;")
	return s
}