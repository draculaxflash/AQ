package modules

import (
	"context"
	"fmt"
	"strings"
	"time"

	"tgmultibot/manager"

	"github.com/amarnathcjd/gogram/telegram"
)

func handleReactPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(
			"╭─❰ ❌ 𝗡𝗢 𝗖𝗟𝗜𝗘𝗡𝗧𝗦 ❱\n│\n"+
				"│  Add a client before sending reactions.\n│\n"+
				"╰─❰ ➕ Tap Add Client first ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ctx, ok := guardProcess(m, "Send Reaction")
	if !ok {
		return nil
	}
	cg.SetListening(userID)

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))

	_, err := m.Reply(
		"╭─❰ ❣️ 𝗦𝗘𝗡𝗗 𝗥𝗘𝗔𝗖𝗧𝗜𝗢𝗡𝗦 ❱\n│\n"+
			"│  Send me the message link to react to.\n│\n"+
			"│  🌐  <b>Public</b>   ›  <code>t.me/username/123</code>\n"+
			"│  🔒  <b>Private</b>  ›  <code>t.me/c/1234567890/123</code>\n│\n"+
			"╰─❰ ⌨️ Awaiting your link (send /cancel) ❱",
		&telegram.SendOptions{
			ParseMode:   telegram.HTML,
			ReplyMarkup: kb.BuildReply(ropts),
		},
	)
	if err != nil {
		ps.done(userID)
		return err
	}

	go reactLoop(ctx, userID, ownerID)
	return nil
}

func reactLoop(ctx context.Context, userID, ownerID int64) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in reactLoop: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	for {
		if ctx.Err() != nil {
			return
		}

		msgs, ok := cg.Recv(userID, 5*time.Minute)
		if !ok {
			if ctx.Err() == nil && cg.IsListening(userID) {
				c.SendMessage(userID,
					"╭─❰ ⏰ 𝗧𝗜𝗠𝗘𝗗 𝗢𝗨𝗧 ❱\n│\n"+
						"│  Tap ❣️ Send Reaction to try again.\n│\n"+
						"╰─❰ — ❱",
					&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: telegram.Button.Clear()},
				)
			}
			return
		}

		if ctx.Err() != nil {
			return
		}

		msg := msgs[0]
		link := strings.TrimSpace(msg.Text())
		if link == "" {
			c.SendMessage(userID,
				"╭─❰ 📎 𝗧𝗘𝗫𝗧 𝗢𝗡𝗟𝗬 ❱\n│\n"+
					"│  Send a message link, not a file.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML})
			cg.SetListening(userID)
			continue
		}

		peer, msgID, err := resolveMsgLink(link)
		if err != nil {
			c.SendMessage(userID,
				"╭─❰ ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗟𝗜𝗡𝗞 ❱\n│\n"+
					"│  Expected formats:\n│\n"+
					"│  🌐  <code>t.me/username/123</code>\n"+
					"│  🔒  <code>t.me/c/1234567890/123</code>\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
			cg.SetListening(userID)
			continue
		}

		if ctx.Err() != nil {
			return
		}

		prog, _ := c.SendMessage(userID,
			fmt.Sprintf(
				"╭─❰ ⏳ 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗥𝗘𝗔𝗖𝗧𝗜𝗢𝗡𝗦 ❱\n│\n"+
					"│  Trying with <b>%d</b> client(s)...\n│\n"+
					"╰─❰ — ❱",
				cm.Count(ownerID),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)

		errs := cm.SendReactions(ctx, ownerID, peer, int32(msgID))

		kb := telegram.NewKeyboard()
		kb.AddRow(telegram.Button.Text(BtnBackToMenu))
		opts := &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)}

		if ctx.Err() != nil {
			cancelled := cm.Count(ownerID) - len(errs)
			result := fmt.Sprintf(
				"╭─❰ 🚫 𝗖𝗔𝗡𝗖𝗘𝗟𝗟𝗘𝗗 ❱\n│\n"+
					"│  ❣️  <b>Reacted before cancel</b>  ›  %d\n"+
					"│  ❌  <b>Failed</b>                  ›  %d\n│\n"+
					"╰─❰ — ❱",
				cancelled, len(errs),
			)
			if prog != nil {
				prog.Edit(result, opts)
			} else {
				c.SendMessage(userID, result, opts)
			}
			return
		}

		total := cm.Count(ownerID)
		failed := len(errs)
		done := total - failed

		var result string
		if len(errs) > 0 {
			result = fmt.Sprintf(
				"╭─❰ ✅ 𝗥𝗘𝗔𝗖𝗧𝗜𝗢𝗡𝗦 𝗦𝗘𝗡𝗧 ❱\n│\n"+
					"│  ❣️  <b>Reacted</b>  ›  %d\n"+
					"│  ❌  <b>Failed</b>    ›  %d\n│\n",
				done, failed,
			)
		} else {
			result = fmt.Sprintf(
				"╭─❰ ✅ 𝗥𝗘𝗔𝗖𝗧𝗜𝗢𝗡𝗦 𝗦𝗘𝗡𝗧 ❱\n│\n"+
					"│  ❣️  <b>Reacted</b>  ›  %d\n│\n",
				done,
			)
		}

		if len(errs) > 0 {
			var accountErrors []manager.AccountError
			for _, e := range errs {
				accountErrors = append(accountErrors, manager.AccountError{Err: e})
			}
			summary := manager.SummarizeErrors(accountErrors)
			result += "╰─❰ ⚠️ See error summary below ❱\n\n" +
				manager.FormatErrorSummary(summary, "<b>Errors:</b>")
		} else {
			result += "╰─❰ ✨ All clients reacted ❱"
		}

		if prog != nil {
			prog.Edit(result, opts)
		} else {
			c.SendMessage(userID, result, opts)
		}

		c.SendMessage(userID,
			"╭─❰ 🔁 𝗥𝗘𝗔𝗖𝗧 𝗔𝗚𝗔𝗜𝗡 ❱\n│\n"+
				"│  Send another message link to react\n"+
				"│  again, or tap 🔙 Back to Menu to stop.\n│\n"+
				"╰─❰ ⌨️ Awaiting your next link ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
		)
		cg.SetListening(userID)
	}
}

func resolveMsgLink(link string) (any, int, error) {
	link = strings.TrimPrefix(link, "https://")
	link = strings.TrimPrefix(link, "http://")
	link = strings.TrimPrefix(link, "t.me/")
	parts := strings.Split(strings.Trim(link, "/"), "/")

	switch {
	case len(parts) == 3 && parts[0] == "c":
		var chanID int64
		if _, err := fmt.Sscanf(parts[1], "%d", &chanID); err != nil {
			return nil, 0, fmt.Errorf("invalid channel id")
		}
		var msgID int
		if _, err := fmt.Sscanf(parts[2], "%d", &msgID); err != nil {
			return nil, 0, fmt.Errorf("invalid msg id")
		}
		return chanIDToPeer(chanID), msgID, nil

	case len(parts) == 2:
		var msgID int
		if _, err := fmt.Sscanf(parts[1], "%d", &msgID); err != nil {
			return nil, 0, fmt.Errorf("invalid msg id")
		}
		return parts[0], msgID, nil

	default:
		return nil, 0, fmt.Errorf("unrecognised link format")
	}
}

func chanIDToPeer(id int64) int64 {
	var result int64
	s := fmt.Sprintf("-100%d", id)
	fmt.Sscanf(s, "%d", &result)
	return result
}