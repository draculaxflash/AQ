package modules

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

type autoPanel string

const (
	panelReact autoPanel = "react"
	panelView  autoPanel = "view"
	panelCall  autoPanel = "call"
)

var (
	panelMu    sync.RWMutex
	userPanels = make(map[int64]autoPanel)
)

func setUserPanel(userID int64, p autoPanel) {
	panelMu.Lock()
	userPanels[userID] = p
	panelMu.Unlock()
}

func getUserPanel(userID int64) autoPanel {
	panelMu.RLock()
	defer panelMu.RUnlock()
	return userPanels[userID]
}

type panelConfig struct {
	title      string
	mark       string
	actionWord string
	addFn      func(userID, chatID int64) error
	removeFn   func(userID, chatID int64) error
	listFn     func(userID int64) ([]int64, error)
}

var panelConfigs = map[autoPanel]panelConfig{
	panelReact: {
		title:      "🔁 Auto React",
		mark:       "🔁 ᴀᴜᴛᴏ ʀᴇᴀᴄᴛ",
		actionWord: "reactions",
		addFn:      database.AddAutoReactChat,
		removeFn:   database.RemoveAutoReactChat,
		listFn:     database.GetAutoReactChats,
	},
	panelView: {
		title:      "👁 Auto View",
		mark:       "👁 ᴀᴜᴛᴏ ᴠɪᴇᴡ",
		actionWord: "views",
		addFn:      database.AddAutoViewChat,
		removeFn:   database.RemoveAutoViewChat,
		listFn:     database.GetAutoViewChats,
	},
	panelCall: {
		title:      "🤖 Auto Call",
		mark:       "🤖 ᴀᴜᴛᴏ ᴄᴀʟʟ",
		actionWord: "call joins",
		addFn:      database.AddAutoCallChat,
		removeFn:   database.RemoveAutoCallChat,
		listFn:     database.GetAutoCallChats,
	},
}

func panelKeyboardBuilder() *telegram.KeyboardBuilder {
	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnPanelList), styledText(BtnPanelAdd))
	kb.AddRow(styledText(BtnBackToMenu))
	return kb
}

func panelOpts() *telegram.SendOptions {
	return &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: panelKeyboardBuilder().BuildReply(ropts)}
}

func handleAutoReactPrompt(m *telegram.NewMessage) error {
	return openPanel(m, panelReact)
}

func handleAutoViewPrompt(m *telegram.NewMessage) error {
	return openPanel(m, panelView)
}

func handleAutoCallPrompt(m *telegram.NewMessage) error {
	return openPanel(m, panelCall)
}

func openPanel(m *telegram.NewMessage, p autoPanel) error {
	userID := m.SenderID()
	setUserPanel(userID, p)
	cfg := panelConfigs[p]

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ %s ᴘᴀɴᴇʟ ❱\n│\n"+
				"│  📋  <b>List Chats</b>\n"+
				"│      View/remove chats with auto-%s\n│\n"+
				"│  ➕  <b>Add Chat</b>\n"+
				"│      Enable auto-%s in a new chat\n│\n"+
				"╰─❰ ✨ Choose an option below ❱",
			cfg.mark, cfg.actionWord, cfg.actionWord,
		),
		panelOpts(),
	)
	return err
}

func handlePanelListPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	p := getUserPanel(userID)
	if p == "" {
		p = panelReact
		setUserPanel(userID, p)
	}
	cfg := panelConfigs[p]

	chats, err := cfg.listFn(effectiveOwnerID(userID))
	if err != nil {
		sendTraceback(fmt.Sprintf("%s listFn error for user %d: %v", cfg.title, userID, err))
		_, err := m.Reply(
			"╭─❰ ❌ ʟᴏᴀᴅ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  Could not load chat list, please try again.\n│\n"+
				"╰─❰ — ❱",
			panelOpts(),
		)
		return err
	}

	text, kb := buildAutoChatListPageFor(effectiveOwnerID(userID), p, chats)
	_, err = m.Reply(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
	return err
}

const autoChatPageMax = 20

func buildAutoChatListPage(p autoPanel, chats []int64) (string, *telegram.KeyboardBuilder) {
	return buildAutoChatListPageFor(0, p, chats)
}

// buildAutoChatListPageFor titles ke saath list banata hai. ownerID == 0 ho
// to sirf chat-id dikhte hain. Max autoChatPageMax chats dikhte hain taaki
// message / keyboard limits na tootein.
func buildAutoChatListPageFor(ownerID int64, p autoPanel, chats []int64) (string, *telegram.KeyboardBuilder) {
	cfg := panelConfigs[p]
	kb := telegram.NewKeyboard()

	if len(chats) == 0 {
		kb.AddRow(dataBtn("— no chats added yet —", "autochat:noop"))
		return fmt.Sprintf(
			"╭─❰ 📋 %s — ᴄʜᴀᴛꜱ ❱\n│\n"+
				"│  No chats added yet.\n│\n"+
				"╰─❰ ➕ Tap Add Chat to add one ❱",
			cfg.mark,
		), kb
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf(
		"╭─❰ 📋 %s — ᴄʜᴀᴛꜱ ❱\n│\n"+
			"│  <b>%d</b> chat(s) configured:\n",
		cfg.mark, len(chats),
	))
	for i, chatID := range chats {
		if i >= autoChatPageMax {
			sb.WriteString(fmt.Sprintf("│\n│  … and <b>%d</b> more\n", len(chats)-autoChatPageMax))
			break
		}
		title := ""
		if ownerID != 0 {
			if t, err := cm.ChatTitle(ownerID, chatID); err == nil {
				title = t
			}
		}
		if title != "" {
			sb.WriteString(fmt.Sprintf("│\n│  %d.  <b>%s</b>\n│       <code>%d</code>\n", i+1, escapeHTML(truncateRunes(title, 30)), chatID))
		} else {
			sb.WriteString(fmt.Sprintf("│\n│  %d.  <code>%d</code>\n", i+1, chatID))
		}
		kb.AddRow(dataBtn(
			fmt.Sprintf("🗑 Remove #%d", i+1),
			fmt.Sprintf("autochat:%s:removeask:%d", p, chatID),
		))
	}
	sb.WriteString("│\n╰─❰ ⚡ Manage below ❱")
	return sb.String(), kb
}

func handleAutoChatCallback(cb *telegram.CallbackQuery) error {
	data := cb.DataString()
	if !strings.HasPrefix(data, "autochat:") {
		return nil
	}

	if data == "autochat:noop" {
		_, err := cb.Answer("")
		return err
	}

	parts := strings.SplitN(strings.TrimPrefix(data, "autochat:"), ":", 3)
	if len(parts) != 3 || (parts[1] != "remove" && parts[1] != "removeask" && parts[1] != "removecancel") {
		return nil
	}

	p := autoPanel(parts[0])
	cfg, ok := panelConfigs[p]
	if !ok {
		return nil
	}

	var chatID int64
	if _, err := fmt.Sscanf(parts[2], "%d", &chatID); err != nil {
		_, err := cb.Answer("Invalid chat.")
		return err
	}

	userID := effectiveOwnerID(cb.GetSenderID())

	switch parts[1] {
	case "removeask":
		_, _ = cb.Answer("")
		kb := telegram.NewKeyboard()
		kb.AddRow(
			dataBtn("✅ Yes, remove", fmt.Sprintf("autochat:%s:remove:%d", p, chatID)),
			dataBtn("❌ No", fmt.Sprintf("autochat:%s:removecancel:%d", p, chatID)),
		)
		_, err := cb.Edit(
			fmt.Sprintf(
				"╭─❰ 🗑 ʀᴇᴍᴏᴠᴇ ᴄʜᴀᴛ? ❱\n│\n"+
					"│  %s\n│  <code>%d</code>\n│\n"+
					"╰─❰ ⚠️ Confirm removal ❱",
				cfg.mark, chatID,
			),
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()},
		)
		return err

	case "removecancel":
		_, _ = cb.Answer("Cancelled.")
		chats, _ := cfg.listFn(userID)
		text, kb := buildAutoChatListPageFor(userID, p, chats)
		_, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
		return err
	}

	if err := cfg.removeFn(userID, chatID); err != nil {
		sendTraceback(fmt.Sprintf("%s removeFn error for user %d chat %d: %v", cfg.title, userID, chatID, err))
		_, err := cb.Answer("Failed to remove, try again.")
		return err
	}

	chats, err := cfg.listFn(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("%s listFn error for user %d: %v", cfg.title, userID, err))
	}

	text, kb := buildAutoChatListPageFor(userID, p, chats)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}
	_, err = cb.Answer("Removed.")
	return err
}

func handlePanelAddPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)
	p := getUserPanel(userID)
	if p == "" {
		p = panelReact
		setUserPanel(userID, p)
	}
	cfg := panelConfigs[p]

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(
			"╭─❰ ❌ ɴᴏ ᴄʟɪᴇɴᴛꜱ ❱\n│\n"+
				"│  Add a client before enabling auto-"+cfg.actionWord+".\n│\n"+
				"╰─❰ ➕ Tap Add Client first ❱",
			panelOpts(),
		)
		return err
	}

	ctx, ok := guardProcessWithKeyboard(m, cfg.title+" — Add Chat", panelKeyboardBuilder())
	if !ok {
		return nil
	}
	cg.SetListening(userID)

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ ➕ %s — ᴀᴅᴅ ᴄʜᴀᴛ ❱\n│\n"+
				"│  Send a username or invite link to the\n"+
				"│  group / channel you want to enable.\n│\n"+
				"│  🌐  <b>Public</b>  ›  <code>@username</code>\n"+
				"│  🔒  <b>Private</b> ›  <code>t.me/+InviteHash</code>\n│\n"+
				"│  All your clients will join it now.\n│\n"+
				"╰─❰ ⌨️ Awaiting your link (send /cancel) ❱",
			cfg.mark,
		),
		panelOpts(),
	)
	if err != nil {
		ps.done(userID)
		return err
	}

	go autoAddJoinStep(ctx, userID, ownerID, p)
	return nil
}

func autoAddJoinStep(ctx context.Context, userID, ownerID int64, p autoPanel) {
	cfg := panelConfigs[p]

	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in autoAddJoinStep (%s): %v", cfg.title, r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	opts := panelOpts()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ ᴛɪᴍᴇᴅ ᴏᴜᴛ ❱\n│\n"+
					"│  Tap <b>➕ Add Chat</b> to try again.\n│\n"+
					"╰─❰ — ❱",
				opts,
			)
		}
		return
	}
	if ctx.Err() != nil {
		return
	}

	text := strings.TrimSpace(msgs[0].Text())
	if text == "" {
		c.SendMessage(userID,
			"╭─❰ 📎 ᴛᴇxᴛ ᴏɴʟʏ ❱\n│\n"+
				"│  Send a username or invite link,\n"+
				"│  not a file.\n│\n"+
				"╰─❰ — ❱",
			opts,
		)
		return
	}

	prog, _ := c.SendMessage(userID,
		fmt.Sprintf(
			"╭─❰ ⏳ ᴊᴏɪɴɪɴɢ ❱\n│\n"+
				"│  Trying with <b>%d</b> client(s)...\n│\n"+
				"╰─❰ — ❱",
			cm.Count(ownerID),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)
	if ctx.Err() != nil {
		if prog != nil {
			prog.Edit(
				"╭─❰ 🚫 ᴄᴀɴᴄᴇʟʟᴇᴅ ❱\n│\n"+
					"│  Cancelled before joining.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
		}
		return
	}

	results := cm.JoinChannel(ctx, ownerID, text)

	var chatID int64
	joined, pending, failed := 0, 0, 0
	for _, r := range results {
		switch {
		case r.Channel != nil:
			// confirmed join OR already-member with a resolvable chat
			joined++
			if chatID == 0 {
				chatID = r.Channel.ID
			}
		case r.AlreadyMember:
			// already inside but the chat object could not be resolved;
			// count as joined (r.ChatID == 0 keeps the save below guarded)
			joined++
			if chatID == 0 {
				chatID = r.ChatID
			}
		case r.InviteRequestSent:
			pending++
		default:
			failed++
		}
	}

	if chatID == 0 {
		var result string
		if pending > 0 {
			result = fmt.Sprintf(
				"╭─❰ ⏳ ᴊᴏɪɴ ʀᴇǫᴜᴇꜱᴛ ꜱᴇɴᴛ ❱\n│\n"+
					"│  🕓  <b>Pending approval</b>  ›  %d\n"+
					"│  ❌  <b>Failed</b>            ›  %d\n│\n"+
					"│  An admin must approve before the chat\n"+
					"│  can be added. Try <b>➕ Add Chat</b> again\n"+
					"│  only after it's approved.\n│\n"+
					"╰─❰ — ❱",
				pending, failed,
			)
		} else {
			result = fmt.Sprintf(
				"╭─❰ ❌ ᴊᴏɪɴ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
					"│  Could not join with any client.\n│\n"+
					"│  ❌  <b>Failed</b>  ›  %d\n│\n"+
					"╰─❰ Chat not added ❱",
				failed,
			)
		}
		if prog != nil {
			prog.Edit(result, opts)
		} else {
			c.SendMessage(userID, result, opts)
		}
		return
	}

	if chatID > 0 {
		chatID = -1000000000000 - chatID // store the marked (-100...) id
	}
	if err := cfg.addFn(ownerID, chatID); err != nil {
		sendTraceback(fmt.Sprintf("%s addFn error for user %d chat %d: %v", cfg.title, userID, chatID, err))
		result := "╭─❰ ❌ ꜱᴀᴠᴇ ꜰᴀɪʟᴇᴅ ❱\n│\n" +
			"│  Joined but could not save the chat.\n│\n" +
			"╰─❰ Try again ❱"
		if prog != nil {
			prog.Edit(result, opts)
		} else {
			c.SendMessage(userID, result, opts)
		}
		return
	}

	result := fmt.Sprintf(
		"╭─❰ ✅ %s ᴇɴᴀʙʟᴇᴅ ❱\n│\n"+
			"│  ➕  <b>Joined</b>            ›  %d\n"+
			"│  🕓  <b>Pending approval</b>  ›  %d\n"+
			"│  ❌  <b>Failed</b>            ›  %d\n│\n"+
			"│  🆔  <b>Chat ID</b>           ›  <code>%d</code>\n│\n"+
			"╰─❰ ✨ New messages will get auto-%s ❱",
		cfg.mark, joined, pending, failed, chatID, cfg.actionWord,
	)
	if prog != nil {
		prog.Edit(result, opts)
	} else {
		c.SendMessage(userID, result, opts)
	}
}
