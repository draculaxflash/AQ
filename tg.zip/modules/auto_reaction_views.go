package modules

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

type autoPanel string

const (
	panelReact autoPanel = "react"
	panelView  autoPanel = "view"
)

var (
	panelMu    sync.RWMutex
	userPanels = make(map[int64]autoPanel)
)

func setUserPanel(userID int64, p autoPanel) {
	panelMu.Lock()
	userPanels[userID] = p
	panelMu.Unlock()
}

func getUserPanel(userID int64) autoPanel {
	panelMu.RLock()
	defer panelMu.RUnlock()
	return userPanels[userID]
}

type panelConfig struct {
	title      string
	mark       string
	actionWord string
	addFn      func(userID, chatID int64) error
	removeFn   func(userID, chatID int64) error
	listFn     func(userID int64) ([]int64, error)
}

var panelConfigs = map[autoPanel]panelConfig{
	panelReact: {
		title:      "🔁 Auto React",
		mark:       "🔁 𝗔𝗨𝗧𝗢 𝗥𝗘𝗔𝗖𝗧",
		actionWord: "reactions",
		addFn:      database.AddAutoReactChat,
		removeFn:   database.RemoveAutoReactChat,
		listFn:     database.GetAutoReactChats,
	},
	panelView: {
		title:      "👁 Auto View",
		mark:       "👁 𝗔𝗨𝗧𝗢 𝗩𝗜𝗘𝗪",
		actionWord: "views",
		addFn:      database.AddAutoViewChat,
		removeFn:   database.RemoveAutoViewChat,
		listFn:     database.GetAutoViewChats,
	},
}

func panelKeyboardBuilder() *telegram.KeyboardBuilder {
	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnPanelList), telegram.Button.Text(BtnPanelAdd))
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))
	return kb
}

func panelOpts() *telegram.SendOptions {
	return &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: panelKeyboardBuilder().BuildReply(ropts)}
}

func handleAutoReactPrompt(m *telegram.NewMessage) error {
	return openPanel(m, panelReact)
}

func handleAutoViewPrompt(m *telegram.NewMessage) error {
	return openPanel(m, panelView)
}

func openPanel(m *telegram.NewMessage, p autoPanel) error {
	userID := m.SenderID()
	setUserPanel(userID, p)
	cfg := panelConfigs[p]

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ %s 𝗣𝗔𝗡𝗘𝗟 ❱\n│\n"+
				"│  📋  <b>List Chats</b>\n"+
				"│      View/remove chats with auto-%s\n│\n"+
				"│  ➕  <b>Add Chat</b>\n"+
				"│      Enable auto-%s in a new chat\n│\n"+
				"╰─❰ ✨ Choose an option below ❱",
			cfg.mark, cfg.actionWord, cfg.actionWord,
		),
		panelOpts(),
	)
	return err
}

func handlePanelListPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	p := getUserPanel(userID)
	if p == "" {
		p = panelReact
		setUserPanel(userID, p)
	}
	cfg := panelConfigs[p]

	chats, err := cfg.listFn(effectiveOwnerID(userID))
	if err != nil {
		sendTraceback(fmt.Sprintf("%s listFn error for user %d: %v", cfg.title, userID, err))
		_, err := m.Reply(
			"╭─❰ ❌ 𝗟𝗢𝗔𝗗 𝗙𝗔𝗜𝗟𝗘𝗗 ❱\n│\n"+
				"│  Could not load chat list, please try again.\n│\n"+
				"╰─❰ — ❱",
			panelOpts(),
		)
		return err
	}

	text, kb := buildAutoChatListPage(p, chats)
	_, err = m.Reply(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
	return err
}

func buildAutoChatListPage(p autoPanel, chats []int64) (string, *telegram.KeyboardBuilder) {
	cfg := panelConfigs[p]
	kb := telegram.NewKeyboard()

	if len(chats) == 0 {
		kb.AddRow(telegram.Button.Data("— no chats added yet —", "autochat:noop"))
		return fmt.Sprintf(
			"╭─❰ 📋 %s — 𝗖𝗛𝗔𝗧𝗦 ❱\n│\n"+
				"│  No chats added yet.\n│\n"+
				"╰─❰ ➕ Tap Add Chat to add one ❱",
			cfg.mark,
		), kb
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf(
		"╭─❰ 📋 %s — 𝗖𝗛𝗔𝗧𝗦 ❱\n│\n"+
			"│  <b>%d</b> chat(s) configured:\n",
		cfg.mark, len(chats),
	))
	for i, chatID := range chats {
		sb.WriteString(fmt.Sprintf("│\n│  %d.  <code>%d</code>\n", i+1, chatID))
		kb.AddRow(telegram.Button.Data(
			fmt.Sprintf("🗑 Remove #%d", i+1),
			fmt.Sprintf("autochat:%s:remove:%d", p, chatID),
		))
	}
	sb.WriteString("│\n╰─❰ ⚡ Manage below ❱")
	return sb.String(), kb
}

func handleAutoChatCallback(cb *telegram.CallbackQuery) error {
	data := cb.DataString()
	if !strings.HasPrefix(data, "autochat:") {
		return nil
	}

	if data == "autochat:noop" {
		_, err := cb.Answer("")
		return err
	}

	parts := strings.SplitN(strings.TrimPrefix(data, "autochat:"), ":", 3)
	if len(parts) != 3 || parts[1] != "remove" {
		return nil
	}

	p := autoPanel(parts[0])
	cfg, ok := panelConfigs[p]
	if !ok {
		return nil
	}

	var chatID int64
	if _, err := fmt.Sscanf(parts[2], "%d", &chatID); err != nil {
		_, err := cb.Answer("Invalid chat.")
		return err
	}

	userID := effectiveOwnerID(cb.GetSenderID())
	if err := cfg.removeFn(userID, chatID); err != nil {
		sendTraceback(fmt.Sprintf("%s removeFn error for user %d chat %d: %v", cfg.title, userID, chatID, err))
		_, err := cb.Answer("Failed to remove, try again.")
		return err
	}

	chats, err := cfg.listFn(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("%s listFn error for user %d: %v", cfg.title, userID, err))
	}

	text, kb := buildAutoChatListPage(p, chats)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}
	_, err = cb.Answer("Removed.")
	return err
}

func handlePanelAddPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)
	p := getUserPanel(userID)
	if p == "" {
		p = panelReact
		setUserPanel(userID, p)
	}
	cfg := panelConfigs[p]

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(
			"╭─❰ ❌ 𝗡𝗢 𝗖𝗟𝗜𝗘𝗡𝗧𝗦 ❱\n│\n"+
				"│  Add a client before enabling auto-"+cfg.actionWord+".\n│\n"+
				"╰─❰ ➕ Tap Add Client first ❱",
			panelOpts(),
		)
		return err
	}

	ctx, ok := guardProcessWithKeyboard(m, cfg.title+" — Add Chat", panelKeyboardBuilder())
	if !ok {
		return nil
	}
	cg.SetListening(userID)

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ ➕ %s — 𝗔𝗗𝗗 𝗖𝗛𝗔𝗧 ❱\n│\n"+
				"│  Send a username or invite link to the\n"+
				"│  group / channel you want to enable.\n│\n"+
				"│  🌐  <b>Public</b>  ›  <code>@username</code>\n"+
				"│  🔒  <b>Private</b> ›  <code>t.me/+InviteHash</code>\n│\n"+
				"│  All your clients will join it now.\n│\n"+
				"╰─❰ ⌨️ Awaiting your link (send /cancel) ❱",
			cfg.mark,
		),
		panelOpts(),
	)
	if err != nil {
		ps.done(userID)
		return err
	}

	go autoAddJoinStep(ctx, userID, ownerID, p)
	return nil
}

func autoAddJoinStep(ctx context.Context, userID, ownerID int64, p autoPanel) {
	cfg := panelConfigs[p]

	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in autoAddJoinStep (%s): %v", cfg.title, r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	opts := panelOpts()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ 𝗧𝗜𝗠𝗘𝗗 𝗢𝗨𝗧 ❱\n│\n"+
					"│  Tap <b>➕ Add Chat</b> to try again.\n│\n"+
					"╰─❰ — ❱",
				opts,
			)
		}
		return
	}
	if ctx.Err() != nil {
		return
	}

	text := strings.TrimSpace(msgs[0].Text())
	if text == "" {
		c.SendMessage(userID,
			"╭─❰ 📎 𝗧𝗘𝗫𝗧 𝗢𝗡𝗟𝗬 ❱\n│\n"+
				"│  Send a username or invite link,\n"+
				"│  not a file.\n│\n"+
				"╰─❰ — ❱",
			opts,
		)
		return
	}

	prog, _ := c.SendMessage(userID,
		fmt.Sprintf(
			"╭─❰ ⏳ 𝗝𝗢𝗜𝗡𝗜𝗡𝗚 ❱\n│\n"+
				"│  Trying with <b>%d</b> client(s)...\n│\n"+
				"╰─❰ — ❱",
			cm.Count(ownerID),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)
	if ctx.Err() != nil {
		if prog != nil {
			prog.Edit(
				"╭─❰ 🚫 𝗖𝗔𝗡𝗖𝗘𝗟𝗟𝗘𝗗 ❱\n│\n"+
					"│  Cancelled before joining.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
		}
		return
	}

	results := cm.JoinChannel(ctx, ownerID, text)

	var chatID int64
	joined, pending, failed := 0, 0, 0
	for _, r := range results {
		switch {
		case r.Channel != nil:
			joined++
			if chatID == 0 {
				chatID = r.Channel.ID
			}
		case r.InviteRequestSent:
			pending++
		default:
			failed++
		}
	}

	if chatID == 0 {
		var result string
		if pending > 0 {
			result = fmt.Sprintf(
				"╭─❰ ⏳ 𝗝𝗢𝗜𝗡 𝗥𝗘𝗤𝗨𝗘𝗦𝗧 𝗦𝗘𝗡𝗧 ❱\n│\n"+
					"│  🕓  <b>Pending approval</b>  ›  %d\n"+
					"│  ❌  <b>Failed</b>            ›  %d\n│\n"+
					"│  An admin must approve before the chat\n"+
					"│  can be added. Try <b>➕ Add Chat</b> again\n"+
					"│  only after it's approved.\n│\n"+
					"╰─❰ — ❱",
				pending, failed,
			)
		} else {
			result = fmt.Sprintf(
				"╭─❰ ❌ 𝗝𝗢𝗜𝗡 𝗙𝗔𝗜𝗟𝗘𝗗 ❱\n│\n"+
					"│  Could not join with any client.\n│\n"+
					"│  ❌  <b>Failed</b>  ›  %d\n│\n"+
					"╰─❰ Chat not added ❱",
				failed,
			)
		}
		if prog != nil {
			prog.Edit(result, opts)
		} else {
			c.SendMessage(userID, result, opts)
		}
		return
	}

	if chatID > 0 {
		chatID = -1000000000000 - chatID // store the marked (-100...) id
	}
	if err := cfg.addFn(ownerID, chatID); err != nil {
		sendTraceback(fmt.Sprintf("%s addFn error for user %d chat %d: %v", cfg.title, userID, chatID, err))
		result := "╭─❰ ❌ 𝗦𝗔𝗩𝗘 𝗙𝗔𝗜𝗟𝗘𝗗 ❱\n│\n" +
			"│  Joined but could not save the chat.\n│\n" +
			"╰─❰ Try again ❱"
		if prog != nil {
			prog.Edit(result, opts)
		} else {
			c.SendMessage(userID, result, opts)
		}
		return
	}

	result := fmt.Sprintf(
		"╭─❰ ✅ %s 𝗘𝗡𝗔𝗕𝗟𝗘𝗗 ❱\n│\n"+
			"│  ➕  <b>Joined</b>            ›  %d\n"+
			"│  🕓  <b>Pending approval</b>  ›  %d\n"+
			"│  ❌  <b>Failed</b>            ›  %d\n│\n"+
			"│  🆔  <b>Chat ID</b>           ›  <code>%d</code>\n│\n"+
			"╰─❰ ✨ New messages will get auto-%s ❱",
		cfg.mark, joined, pending, failed, chatID, cfg.actionWord,
	)
	if prog != nil {
		prog.Edit(result, opts)
	} else {
		c.SendMessage(userID, result, opts)
	}
}