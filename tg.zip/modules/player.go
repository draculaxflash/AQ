package modules

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"tgmultibot/manager"

	"github.com/amarnathcjd/gogram/telegram"
)

const (
	playMediaDir = "/tmp/tgmultibot_media"
	playMaxRetry = 3
)

// playStarterByChat remembers which user started playback in a given
// (owner, chat) — the playback-end notification goes to that user, not
// blindly to the ownerID. Previously a delegate who started playback never
// got notified: the grantor received the message instead.
type playKey struct {
	ownerID   int64
	chatIDNum int64
}

var (
	playStarterMu     sync.RWMutex
	playStarterByChat = map[playKey]int64{}
)

func rememberPlayStarter(ownerID, chatIDNum, userID int64) {
	playStarterMu.Lock()
	playStarterByChat[playKey{ownerID: ownerID, chatIDNum: chatIDNum}] = userID
	playStarterMu.Unlock()
}

func takePlayStarter(ownerID, chatIDNum int64) int64 {
	playStarterMu.Lock()
	defer playStarterMu.Unlock()
	k := playKey{ownerID: ownerID, chatIDNum: chatIDNum}
	id := playStarterByChat[k]
	delete(playStarterByChat, k)
	return id
}

// Panel headers — the visible wordmark inside the box frame. Context-specific
// so the same control panel can announce "now playing", "media played", etc.
const (
	panelHeaderNowPlaying = "🎵 ɴᴏᴡ ᴘʟᴀʏɪɴɢ"
	panelHeaderAlreadyOn  = "🎵 ᴀʟʀᴇᴀᴅʏ ᴘʟᴀʏɪɴɢ"
	panelHeaderStopped    = "⏹ ꜱᴏɴɢ ꜱᴛᴏᴘᴘᴇᴅ"
	panelHeaderFinished   = "🎵 ꜱᴏɴɢ ꜰɪɴɪꜱʜᴇᴅ"
)

const playerMenuText = `╭─❰ 🎵 ᴘʟᴀʏᴇʀ ❱
│
│  ▶️  <b>Play Media</b>
│      Play audio/video in a voice chat
│
│  📋  <b>Playlist</b>
│      Manage active playback
│
╰─❰ ✨ Choose an option below ❱`

func handlePlayerPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(noClientsMsg(userID), panelReplyOpts(userID))
		return err
	}

	kb := telegram.NewKeyboard()
	kb.AddRow(
		dataBtn("▶️ Play Media", "player:play"),
		dataBtn("📋 Playlist", "player:list"),
	).AddRow(
		dataBtn("🔙 Back to Menu", "player:menu"),
	)
	_, err := m.Reply(playerMenuText,
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
	return err
}

func showPlayerMenu(cb *telegram.CallbackQuery) {
	kb := telegram.NewKeyboard()
	kb.AddRow(
		dataBtn("▶️ Play Media", "player:play"),
		dataBtn("📋 Playlist", "player:list"),
	).AddRow(
		dataBtn("🔙 Back to Menu", "player:menu"),
	)
	_, _ = cb.Edit(playerMenuText,
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func startPlayFlow(userID, ownerID int64) {
	if cm.Count(ownerID) == 0 {
		c.SendMessage(userID, noClientsMsg(userID), panelReplyOpts(userID))
		return
	}

	if existing := ps.current(userID); existing != "" {
		kb := telegram.NewKeyboard()
		kb.AddRow(styledText(BtnBackToMenu))
		c.SendMessage(userID,
			busyMsg(existing),
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)})
		return
	}

	ctx, ok := ps.tryStart(userID, "Player")
	if !ok {
		return
	}
	cg.SetListening(userID)

	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnBackToMenu))

	_, err := c.SendMessage(userID,
		"╭─❰ 🎵 ᴘʟᴀʏ ᴍᴇᴅɪᴀ ❱\n│\n"+
			"│  Send the voice chat's username or Chat ID.\n│\n"+
			"│  🌐  <b>Public</b>   ›  <code>@username</code>\n"+
			"│  🔒  <b>Private</b>  ›  <code>-1001234567890</code>\n"+
			"│                  or  <code>t.me/c/1234567890</code>\n│\n"+
			"│  ⚠️  For private groups/channels:\n"+
			"│      use 🔗 Join Channel first to join all\n"+
			"│      your clients, then come back here with\n"+
			"│      the Chat ID.\n│\n"+
			"╰─❰ ⌨️ Awaiting your link (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)
	if err != nil {
		ps.done(userID)
		return
	}

	go playChatInputStep(ctx, userID, ownerID, 1)
}

func playChatInputStep(ctx context.Context, userID, ownerID int64, attempt int) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in playChatInputStep: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ ᴛɪᴍᴇᴅ ᴏᴜᴛ ❱\n│\n"+
					"│  Tap 🎵 Player to try again.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
			)
		}
		return
	}

	if ctx.Err() != nil {
		return
	}

	text := strings.TrimSpace(msgs[0].Text())
	if text == "" {
		if attempt < playMaxRetry {
			c.SendMessage(userID,
				fmt.Sprintf(
					"╭─❰ 📎 ᴛᴇxᴛ ᴏɴʟʏ ❱\n│\n"+
						"│  Send a username or Chat ID,\n"+
						"│  not a file.\n│\n"+
						"│  🔄 Attempt %d/%d — <b>%d</b> left\n│\n"+
						"╰─❰ — ❱",
					attempt, playMaxRetry, playMaxRetry-attempt,
				),
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
			cg.SetListening(userID)
			go playChatInputStep(ctx, userID, ownerID, attempt+1)
			return
		}
		c.SendMessage(userID,
			"╭─❰ 🚫 ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴇᴍᴘᴛꜱ ❱\n│\n"+
				"│  Tap 🎵 Player to start over.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return
	}

	peer, err := resolveVCPeer(text)
	if err != nil {
		c.SendMessage(userID,
			fmt.Sprintf(
				"╭─❰ ❌ ɪɴᴠᴀʟɪᴅ ᴘᴇᴇʀ ❱\n│\n"+
					"│  %s\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(err.Error()),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML})
		return
	}

	chatIDNum, err := cm.ResolveChatID(ownerID, peer)
	if err != nil {
		c.SendMessage(userID,
			fmt.Sprintf(
				"╭─❰ ❌ ʀᴇꜱᴏʟᴠᴇ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
					"│  %s\n│\n"+
					"│  For private groups, use 🔗 Join Channel\n"+
					"│  first, then come back here with the\n"+
					"│  Chat ID.\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(err.Error()),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML})
		return
	}

	if ctx.Err() != nil {
		return
	}

	if len(cm.SessionsInChat(ownerID, chatIDNum)) > 0 {
		text, kb := buildChatControlPanel(ownerID, chatIDNum, panelHeaderAlreadyOn)
		c.SendMessage(userID, text,
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
		return
	}

	cg.SetListening(userID)
	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnBackToMenu))

	_, err = c.SendMessage(userID,
		"╭─❰ 🎵 ᴘʟᴀʏ ᴍᴇᴅɪᴀ ❱\n│\n"+
			"│  Send the audio or video file to play.\n│\n"+
			"│  Accepted:\n"+
			"│    🎵  Music and voice messages\n"+
			"│    🎬  Videos and video documents\n│\n"+
			"╰─❰ ⌨️ Awaiting your file (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)
	if err != nil {
		ps.done(userID)
		return
	}

	go playMediaForChatStep(ctx, userID, ownerID, chatIDNum, 1)
}

func playMediaForChatStep(ctx context.Context, userID, ownerID, chatIDNum int64, attempt int) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in playMediaForChatStep: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ ᴛɪᴍᴇᴅ ᴏᴜᴛ ❱\n│\n"+
					"│  Tap 🎵 Player to try again.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
			)
		}
		return
	}

	if ctx.Err() != nil {
		return
	}

	m := msgs[0]
	if !m.IsMedia() {
		if attempt < playMaxRetry {
			c.SendMessage(userID,
				fmt.Sprintf(
					"╭─❰ 📎 ɴᴏ ꜰɪʟᴇ ❱\n│\n"+
						"│  Send an audio or video file.\n│\n"+
						"│  🔄 Attempt %d/%d — <b>%d</b> left\n│\n"+
						"╰─❰ — ❱",
					attempt, playMaxRetry, playMaxRetry-attempt,
				),
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
			cg.SetListening(userID)
			go playMediaForChatStep(ctx, userID, ownerID, chatIDNum, attempt+1)
			return
		}
		c.SendMessage(userID,
			"╭─❰ 🚫 ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴇᴍᴘᴛꜱ ❱\n│\n"+
				"│  Tap 🎵 Player to start over.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return
	}

	isVideo, _, err := detectPlayMedia(m)
	if err != nil {
		if attempt < playMaxRetry {
			c.SendMessage(userID,
				fmt.Sprintf(
					"╭─❰ 🚫 ɪɴᴠᴀʟɪᴅ ꜰɪʟᴇ ❱\n│\n"+
						"│  %s\n│\n"+
						"│  🔄 Attempt %d/%d — <b>%d</b> left\n│\n"+
						"╰─❰ — ❱",
					escapeHTML(err.Error()), attempt, playMaxRetry, playMaxRetry-attempt,
				),
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
			cg.SetListening(userID)
			go playMediaForChatStep(ctx, userID, ownerID, chatIDNum, attempt+1)
			return
		}
		c.SendMessage(userID,
			"╭─❰ 🚫 ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴇᴍᴘᴛꜱ ❱\n│\n"+
				"│  Tap 🎵 Player to start over.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return
	}

	if ctx.Err() != nil {
		return
	}

	prog, _ := c.SendMessage(userID,
		"╭─❰ ⏳ ᴅᴏᴡɴʟᴏᴀᴅɪɴɢ ❱\n│\n"+
			"│  Fetching the media file...\n│\n"+
			"╰─❰ — ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML})

	filePath, err := downloadPlayMedia(ctx, m)
	if err != nil {
		msg := fmt.Sprintf(
			"╭─❰ ❌ ᴅᴏᴡɴʟᴏᴀᴅ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  %s\n│\n"+
				"╰─❰ — ❱",
			escapeHTML(err.Error()),
		)
		if prog != nil {
			prog.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML})
		} else {
			c.SendMessage(userID, msg, &telegram.SendOptions{ParseMode: telegram.HTML})
		}
		return
	}

	if ctx.Err() != nil {
		os.Remove(filePath)
		return
	}

	if prog != nil {
		prog.Edit(
			"╭─❰ ✅ ᴍᴇᴅɪᴀ ᴅᴏᴡɴʟᴏᴀᴅᴇᴅ ❱\n│\n"+
				"│  Preparing to play...\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
	}

	durationMs := probeMediaDuration(filePath)
	total := cm.Count(ownerID)

	playingMsg := fmt.Sprintf(
		"╭─❰ ⏳ ꜱᴛᴀʀᴛɪɴɢ ᴘʟᴀʏʙᴀᴄᴋ ❱\n│\n"+
			"│  Joining with <b>%d</b> client(s)...\n│\n"+
			"╰─❰ — ❱",
		total,
	)
	if prog != nil {
		prog.Edit(playingMsg, &telegram.SendOptions{ParseMode: telegram.HTML})
	} else {
		c.SendMessage(userID, playingMsg, &telegram.SendOptions{ParseMode: telegram.HTML})
	}

	results := cm.Play(ctx, ownerID, chatIDNum, filePath, isVideo, durationMs)

	joined, hardErr, playAccountErrors := applyPlayResults(results)
	if hardErr != "" {
		if prog != nil {
			prog.Edit(hardErr, &telegram.SendOptions{ParseMode: telegram.HTML})
		} else {
			c.SendMessage(userID, hardErr, &telegram.SendOptions{ParseMode: telegram.HTML})
		}
		return
	}

	if ctx.Err() != nil {
		var result string
		if joined == 0 {
			result = "╭─❰ 🚫 ᴄᴀɴᴄᴇʟʟᴇᴅ ❱\n│\n" +
				"│  No clients had joined yet.\n│\n" +
				"╰─❰ — ❱"
		} else {
			result = fmt.Sprintf(
				"╭─❰ 🚫 ᴄᴀɴᴄᴇʟʟᴇᴅ ᴍɪᴅ-ᴊᴏɪɴ ❱\n│\n"+
					"│  ✅  <b>Already joined</b>  ›  %d\n│\n"+
					"│  Those %d client(s) are still in the\n"+
					"│  voice chat.\n│\n"+
					"│  Tap 🔇 Leave Voice Chat to remove them.\n│\n"+
					"╰─❰ — ❱",
				joined, joined,
			)
		}
		if len(playAccountErrors) > 0 {
			summary := manager.SummarizeErrors(playAccountErrors)
			// Trim the frame footer and reattach it around the error block.
			result = strings.TrimSuffix(result, "╰─❰ — ❱")
			result += "╰─❰ ⚠️ See error summary below ❱\n\n"
			result += manager.FormatErrorSummary(summary, "<b>Errors:</b>")
		}
		if prog != nil {
			prog.Edit(result, &telegram.SendOptions{ParseMode: telegram.HTML})
		} else {
			c.SendMessage(userID, result, &telegram.SendOptions{ParseMode: telegram.HTML})
		}
		return
	}

	if joined == 0 {
		msg := "╭─❰ ❌ ᴘʟᴀʏʙᴀᴄᴋ ꜰᴀɪʟᴇᴅ ❱\n│\n" +
			"│  No client could join the voice chat.\n│\n" +
			"╰─❰ ⚠️ See error summary below ❱"
		if len(playAccountErrors) > 0 {
			summary := manager.SummarizeErrors(playAccountErrors)
			msg += "\n\n" + manager.FormatErrorSummary(summary, "<b>Errors:</b>")
		}
		if prog != nil {
			prog.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML})
		} else {
			c.SendMessage(userID, msg, &telegram.SendOptions{ParseMode: telegram.HTML})
		}
		return
	}

	// Remember who started playback so the playback-end notification goes to
	// them (not blindly to the owner/grantor context).
	rememberPlayStarter(ownerID, chatIDNum, userID)

	var msg string
	var kb *telegram.KeyboardBuilder
	if len(playAccountErrors) > 0 {
		summary := manager.SummarizeErrors(playAccountErrors)
		msg, kb = buildChatControlPanelNote(ownerID, chatIDNum, panelHeaderNowPlaying,
			manager.FormatErrorSummary(summary, "<b>Errors:</b>"))
	} else {
		msg, kb = buildChatControlPanel(ownerID, chatIDNum, panelHeaderNowPlaying)
	}
	opts := &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}
	if prog != nil {
		prog.Edit(msg, opts)
	} else {
		c.SendMessage(userID, msg, opts)
	}
}

func applyPlayResults(results []manager.JoinVoiceChatResult) (joined int, hardErr string, accountErrors []manager.AccountError) {
	for _, r := range results {
		switch {
		case r.NoActiveGroupCall:
			return 0, "╭─❰ ❌ ɴᴏ ᴀᴄᴛɪᴠᴇ ᴄᴀʟʟ ❱\n│\n" +
				"│  No active voice chat was found in that\n" +
				"│  channel.\n│\n" +
				"│  Start a voice chat there first, then try\n" +
				"│  again.\n│\n" +
				"╰─❰ — ❱", nil
		case r.WrongPeerType:
			return 0, "╭─❰ ❌ ᴡʀᴏɴɢ ᴘᴇᴇʀ ᴛʏᴘᴇ ❱\n│\n" +
				"│  That looks like a user account, not a\n" +
				"│  group or channel.\n│\n" +
				"│  Voice chats are only available in groups\n" +
				"│  and channels.\n│\n" +
				"╰─❰ — ❱", nil
		case r.Err != nil:
			if r.Err == context.Canceled {
				continue
			}
			accountErrors = append(accountErrors, manager.AccountError{AccountID: r.AccountID, Err: r.Err})
			sendTraceback(fmt.Sprintf("Player error (account %d): %v", r.AccountID, r.Err))
		default:
			joined++
		}
	}
	return joined, "", accountErrors
}

func handlePlayerCallback(cb *telegram.CallbackQuery) error {
	data := cb.DataString()
	if !strings.HasPrefix(data, "player:") {
		return nil
	}

	userID := cb.GetSenderID()
	ownerID := effectiveOwnerID(userID)

	switch data {
	case "player:play":
		_, _ = cb.Answer("📥 Send a username or Chat ID first.")
		startPlayFlow(userID, ownerID)
		return nil

	case "player:list":
		_, _ = cb.Answer("")
		showPlaylist(cb, ownerID)
		return nil

	case "player:main":
		_, _ = cb.Answer("")
		showPlayerMenu(cb)
		return nil

	case "player:menu":
		_, _ = cb.Answer("")
		_, err := c.SendMessage(userID,
			"╭─❰ 🏠 ᴍᴀɪɴ ᴍᴇɴᴜ ❱\n│\n"+
				"│  Choose an option below.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})
		return err
	}

	if id, ok := chatIDFromData(data, "player:view:"); ok {
		_, _ = cb.Answer("")
		text, kb := buildChatControlPanel(ownerID, id, panelHeaderNowPlaying)
		_, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
		return err
	}

	if id, ok := chatIDFromData(data, "player:pause:"); ok {
		return refreshChatControls(cb, ownerID, id, playerErrToast("⏸ Paused.", cm.PauseChat(ownerID, id)))
	}

	if id, ok := chatIDFromData(data, "player:resume:"); ok {
		return refreshChatControls(cb, ownerID, id, playerErrToast("▶️ Resumed.", cm.ResumeChat(ownerID, id)))
	}

	if id, ok := chatIDFromData(data, "player:mute:"); ok {
		return refreshChatControls(cb, ownerID, id, playerErrToast("🔇 Muted.", cm.MuteChat(ownerID, id)))
	}

	if id, ok := chatIDFromData(data, "player:unmute:"); ok {
		return refreshChatControls(cb, ownerID, id, playerErrToast("🔊 Unmuted.", cm.UnmuteChat(ownerID, id)))
	}

	if id, ok := chatIDFromData(data, "player:seek:back:"); ok {
		target := uint64(0)
		if st, found := cm.StatusChat(ownerID, id); found && st.PositionMs > 10000 {
			target = st.PositionMs - 10000
		}
		return refreshChatControls(cb, ownerID, id, playerErrToast("⏪ -10s.", cm.SeekChat(ownerID, id, target)))
	}

	if id, ok := chatIDFromData(data, "player:seek:fwd:"); ok {
		target := uint64(0)
		if st, found := cm.StatusChat(ownerID, id); found {
			target = st.PositionMs + 10000
			if st.DurationMs > 0 && target > st.DurationMs {
				target = st.DurationMs
			}
		}
		return refreshChatControls(cb, ownerID, id, playerErrToast("⏩ +10s.", cm.SeekChat(ownerID, id, target)))
	}

	if id, ok := chatIDFromData(data, "player:stop:"); ok {
		return stopChat(cb, ownerID, id)
	}

	if id, ok := chatIDFromData(data, "player:replay:"); ok {
		replayMedia(cb, userID, ownerID, id)
		return nil
	}

	if id, ok := chatIDFromData(data, "player:loop:"); ok {
		startLoopFlow(cb, userID, ownerID, id)
		return nil
	}

	if id, ok := chatIDFromData(data, "player:another:"); ok {
		_, _ = cb.Answer("📥 Send a media file to play.")
		startPlayAnother(userID, ownerID, id)
		return nil
	}

	if id, ok := chatIDFromData(data, "player:back:"); ok {
		_, _ = cb.Answer("")
		ps.cancel(userID)
		returnBackFromLoop(cb, ownerID, id)
		return nil
	}

	_, err := cb.Answer("")
	return err
}

func chatIDFromData(data, prefix string) (int64, bool) {
	rest := strings.TrimPrefix(data, prefix)
	if rest == data {
		return 0, false
	}
	id, err := strconv.ParseInt(rest, 10, 64)
	if err != nil {
		return 0, false
	}
	return id, true
}

func refreshChatControls(cb *telegram.CallbackQuery, ownerID, chatIDNum int64, toast string) error {
	text, kb := buildChatControlPanel(ownerID, chatIDNum, panelHeaderNowPlaying)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}
	_, err := cb.Answer(toast)
	return err
}

func playerErrToast(action string, errs []error) string {
	if len(errs) == 0 {
		return action
	}
	return fmt.Sprintf("⚠️ %s %d client(s) failed.", action, len(errs))
}

func showPlaylist(cb *telegram.CallbackQuery, ownerID int64) {
	entries := cm.Playlist(ownerID)
	if len(entries) == 0 {
		kb := telegram.NewKeyboard()
		kb.AddRow(dataBtn("🔙 Back", "player:main"))
		_, _ = cb.Edit(
			"╭─❰ 🎵 ᴘʟᴀʏʟɪꜱᴛ ❱\n│\n"+
				"│  No song is playing right now.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
		return
	}

	var sb strings.Builder
	sb.WriteString("╭─❰ 🎵 ᴘʟᴀʏʟɪꜱᴛ ❱\n│\n")
	sb.WriteString(fmt.Sprintf("│  <b>%d</b> chat(s) with active playback:\n│\n", len(entries)))
	kb := telegram.NewKeyboard()
	for i, e := range entries {
		title, err := cm.ChatTitle(ownerID, e.ChatIDNum)
		if err != nil || title == "" {
			title = fmt.Sprintf("chat %d", e.ChatIDNum)
		}
		title = truncateTitle(title)
		sb.WriteString(fmt.Sprintf("│  %d.  <b>%s</b>\n", i+1, escapeHTML(title)))
		kb.AddRow(dataBtn("🎵 "+title, fmt.Sprintf("player:view:%d", e.ChatIDNum)))
	}
	sb.WriteString("│\n╰─❰ ✨ Tap a chat to open controls ❱")
	kb.AddRow(dataBtn("🔙 Back", "player:main"))
	_, _ = cb.Edit(sb.String(), &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func truncateTitle(s string) string {
	const max = 18
	runes := []rune(s)
	if len(runes) <= max {
		return s
	}
	return string(runes[:max-1]) + "…"
}

// buildChatControlPanel renders the per-chat playback status and inline controls.
// header is the wordmark shown inside the frame bar (e.g. "Now Playing").
func buildChatControlPanel(ownerID, chatIDNum int64, header string) (string, *telegram.KeyboardBuilder) {
	return buildChatControlPanelNote(ownerID, chatIDNum, header, "")
}

// buildChatControlPanelNote is buildChatControlPanel with an optional extra
// HTML block inserted between the status rows and the frame footer (used to
// append an error summary without string surgery on the finished message —
// the old TrimSuffix approach broke whenever the no-status variant rendered,
// leaving a double footer).
func buildChatControlPanelNote(ownerID, chatIDNum int64, header, noteHTML string) (string, *telegram.KeyboardBuilder) {
	title, err := cm.ChatTitle(ownerID, chatIDNum)
	if err != nil || title == "" {
		title = fmt.Sprintf("chat %d", chatIDNum)
	}

	st, ok := cm.StatusChat(ownerID, chatIDNum)
	if !ok {
		kb := telegram.NewKeyboard()
		kb.AddRow(dataBtn("🔙 Back", "player:list"))
		if noteHTML != "" {
			return fmt.Sprintf(
				"╭─❰ %s ❱\n│\n"+
					"│  📢  <b>Chat</b>  ›  %s\n│\n"+
					"╰─❰ ⚠️ See error summary below ❱\n\n%s",
				header, escapeHTML(title), noteHTML,
			), kb
		}
		return fmt.Sprintf(
			"╭─❰ %s ❱\n│\n"+
				"│  📢  <b>Chat</b>  ›  %s\n│\n"+
				"╰─❰ ⏹ Nothing is playing here ❱",
			header, escapeHTML(title),
		), kb
	}

	stateIcon, stateText := "▶️", "Playing"
	switch {
	case st.Ended:
		stateIcon, stateText = "⏹", "Ended"
	case st.Paused:
		stateIcon, stateText = "⏸", "Paused"
	}

	muteIcon, muteText := "🔊", "Unmuted"
	if st.Muted {
		muteIcon, muteText = "🔇", "Muted"
	}

	timeText := formatPlayerTime(st.PositionMs)
	if st.DurationMs > 0 {
		timeText += " / " + formatPlayerTime(st.DurationMs)
	}

	footer := "╰─❰ ⚡ Controls below ❱"
	if noteHTML != "" {
		footer = "╰─❰ ⚠️ See error summary below ❱\n\n" + noteHTML
	}

	text := fmt.Sprintf(
		"╭─❰ %s ❱\n│\n"+
			"│  📢  <b>Chat</b>      ›  %s\n"+
			"│  %s  <b>Status</b>    ›  %s\n"+
			"│  %s  <b>Mic</b>       ›  %s\n"+
			"│  ⏱  <b>Time</b>      ›  <code>%s</code>\n│\n"+
			"%s",
		header, escapeHTML(title), stateIcon, stateText, muteIcon, muteText, timeText, footer,
	)
	return text, buildChatControlKB(chatIDNum, st)
}

func buildChatControlKB(chatIDNum int64, st manager.PlayerState) *telegram.KeyboardBuilder {
	kb := telegram.NewKeyboard()

	pauseBtn := dataBtn("⏸ Pause", fmt.Sprintf("player:pause:%d", chatIDNum))
	if st.Paused {
		pauseBtn = dataBtn("▶️ Resume", fmt.Sprintf("player:resume:%d", chatIDNum))
	}
	muteBtn := dataBtn("🔇 Mute", fmt.Sprintf("player:mute:%d", chatIDNum))
	if st.Muted {
		muteBtn = dataBtn("🔊 Unmute", fmt.Sprintf("player:unmute:%d", chatIDNum))
	}

	kb.AddRow(pauseBtn, muteBtn).AddRow(
		dataBtn("⏪ -10s", fmt.Sprintf("player:seek:back:%d", chatIDNum)),
		dataBtn("⏩ +10s", fmt.Sprintf("player:seek:fwd:%d", chatIDNum)),
	).AddRow(
		dataBtn("🛑 Stop", fmt.Sprintf("player:stop:%d", chatIDNum)),
	).AddRow(
		dataBtn("🔙 Back", "player:list"),
		dataBtn("🏠 Main Menu", "player:menu"),
	)
	return kb
}

// buildStopScreen renders the post-stop menu with Replay, Loop and Play Another.
func buildStopScreen(ownerID, chatIDNum int64, header string) (string, *telegram.KeyboardBuilder) {
	title, err := cm.ChatTitle(ownerID, chatIDNum)
	if err != nil || title == "" {
		title = fmt.Sprintf("chat %d", chatIDNum)
	}

	text := fmt.Sprintf(
		"╭─❰ %s ❱\n│\n"+
			"│  📢  <b>Chat</b>  ›  %s\n│\n"+
			"│  What would you like to do next?\n│\n"+
			"╰─❰ ✨ Choose an action below ❱",
		header, escapeHTML(title),
	)

	kb := telegram.NewKeyboard()
	kb.AddRow(
		dataBtn("↩️ Replay", fmt.Sprintf("player:replay:%d", chatIDNum)),
		dataBtn("🔂 Loop", fmt.Sprintf("player:loop:%d", chatIDNum)),
	).AddRow(
		dataBtn("▶️ Play Another", fmt.Sprintf("player:another:%d", chatIDNum)),
	).AddRow(
		dataBtn("🔙 Player Menu", "player:main"),
		dataBtn("🏠 Main Menu", "player:menu"),
	)
	return text, kb
}

func stopChat(cb *telegram.CallbackQuery, ownerID, chatIDNum int64) error {
	errs := cm.StopChat(ownerID, chatIDNum)
	toast := "⏹ Stopped."
	if len(errs) > 0 {
		toast = "⚠️ Some clients failed to stop."
	}
	// Manual stop: no playback-end notification should fire for this chat.
	takePlayStarter(ownerID, chatIDNum)

	text, kb := buildStopScreen(ownerID, chatIDNum, panelHeaderStopped)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}
	_, err := cb.Answer(toast)
	return err
}

func replayMedia(cb *telegram.CallbackQuery, userID, ownerID, chatIDNum int64) {
	_, _ = cb.Answer("🔄 Replaying...")

	results, err := cm.ReplayMedia(ownerID, chatIDNum)
	if err != nil {
		msg := fmt.Sprintf(
			"╭─❰ ❌ ʀᴇᴘʟᴀʏ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  %s\n│\n"+
				"╰─❰ — ❱",
			escapeHTML(err.Error()),
		)
		if _, e := cb.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML}); e == nil {
			return
		}
		c.SendMessage(userID, msg, &telegram.SendOptions{ParseMode: telegram.HTML})
		return
	}

	joined, hardErr, replayAccountErrors := applyPlayResults(results)
	if hardErr != "" {
		_, _ = cb.Edit(hardErr, &telegram.SendOptions{ParseMode: telegram.HTML})
		return
	}
	if joined == 0 {
		msg := "╭─❰ ❌ ʀᴇᴘʟᴀʏ ꜰᴀɪʟᴇᴅ ❱\n│\n" +
			"│  No client could join the voice chat.\n│\n" +
			"╰─❰ ⚠️ See error summary below ❱"
		if len(replayAccountErrors) > 0 {
			summary := manager.SummarizeErrors(replayAccountErrors)
			msg += "\n\n" + manager.FormatErrorSummary(summary, "<b>Errors:</b>")
		}
		_, _ = cb.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML})
		return
	}

	// Same starter-remembering as a fresh play: the user tapping Replay gets
	// the playback-end notification.
	rememberPlayStarter(ownerID, chatIDNum, userID)

	var msg string
	var kb *telegram.KeyboardBuilder
	if len(replayAccountErrors) > 0 {
		summary := manager.SummarizeErrors(replayAccountErrors)
		msg, kb = buildChatControlPanelNote(ownerID, chatIDNum, panelHeaderNowPlaying,
			manager.FormatErrorSummary(summary, "<b>Errors:</b>"))
	} else {
		msg, kb = buildChatControlPanel(ownerID, chatIDNum, panelHeaderNowPlaying)
	}
	_, _ = cb.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func startPlayAnother(userID, ownerID, chatIDNum int64) {
	if cm.Count(ownerID) == 0 {
		c.SendMessage(userID, noClientsMsg(userID), panelReplyOpts(userID))
		return
	}

	if existing := ps.current(userID); existing != "" {
		kb := telegram.NewKeyboard()
		kb.AddRow(styledText(BtnBackToMenu))
		c.SendMessage(userID,
			busyMsg(existing),
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)})
		return
	}

	ctx, ok := ps.tryStart(userID, "Player")
	if !ok {
		return
	}
	cg.SetListening(userID)

	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnBackToMenu))

	_, err := c.SendMessage(userID,
		"╭─❰ 🎵 ᴘʟᴀʏ ᴀɴᴏᴛʜᴇʀ ❱\n│\n"+
			"│  Send the audio or video file to play\n"+
			"│  in the same chat.\n│\n"+
			"╰─❰ ⌨️ Awaiting your file (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)
	if err != nil {
		ps.done(userID)
		return
	}

	go playMediaForChatStep(ctx, userID, ownerID, chatIDNum, 1)
}

func startLoopFlow(cb *telegram.CallbackQuery, userID, ownerID, chatIDNum int64) {
	if existing := ps.current(userID); existing != "" {
		_, _ = cb.Answer("⚙️ Another process is running.", &telegram.CallbackOptions{Alert: true})
		return
	}

	ctx, ok := ps.tryStart(userID, "Player Loop")
	if !ok {
		_, _ = cb.Answer("⚙️ Another process is running.", &telegram.CallbackOptions{Alert: true})
		return
	}
	cg.SetListening(userID)

	_, _ = cb.Answer("🔂 Set loop count.")

	kb := telegram.NewKeyboard()
	kb.AddRow(dataBtn("🔙 Back", fmt.Sprintf("player:back:%d", chatIDNum)))
	_, _ = cb.Edit(
		"╭─❰ 🔂 ꜱᴇᴛ ʟᴏᴏᴘ ᴄᴏᴜɴᴛ ❱\n│\n"+
			"│  How many times should this song repeat\n"+
			"│  after it ends?\n│\n"+
			"│  •  Send a whole number:\n"+
			"│       <code>1</code>, <code>2</code>, <code>5</code>, <code>10</code>...\n"+
			"│  •  Send <code>0</code> to disable loop.\n│\n"+
			"╰─❰ ⌨️ Awaiting count (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()},
	)

	go loopInputStep(ctx, userID, ownerID, chatIDNum, 1)
}

func loopInputStep(ctx context.Context, userID, ownerID, chatIDNum int64, attempt int) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in loopInputStep: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ ᴛɪᴍᴇᴅ ᴏᴜᴛ ❱\n│\n"+
					"│  No count received.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
			)
		}
		return
	}

	if ctx.Err() != nil {
		return
	}

	n, err := strconv.Atoi(strings.TrimSpace(msgs[0].Text()))
	if err != nil || n < 0 {
		if attempt < playMaxRetry {
			c.SendMessage(userID,
				fmt.Sprintf(
					"╭─❰ ❌ ɪɴᴠᴀʟɪᴅ ɴᴜᴍʙᴇʀ ❱\n│\n"+
						"│  Send a whole number like <code>1</code>,\n"+
						"│  <code>2</code> or <code>10</code> (or <code>0</code> to disable).\n│\n"+
						"│  🔄 Attempt %d/%d — <b>%d</b> left\n│\n"+
						"╰─❰ — ❱",
					attempt, playMaxRetry, playMaxRetry-attempt,
				),
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
			cg.SetListening(userID)
			go loopInputStep(ctx, userID, ownerID, chatIDNum, attempt+1)
			return
		}
		c.SendMessage(userID,
			"╭─❰ 🚫 ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴇᴍᴘᴛꜱ ❱\n│\n"+
				"│  Tap 🎵 Player to start over.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return
	}

	if err := cm.SetLoop(ownerID, chatIDNum, n); err != nil {
		c.SendMessage(userID,
			fmt.Sprintf(
				"╭─❰ ❌ ꜱᴇᴛ ʟᴏᴏᴘ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
					"│  %s\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(err.Error()),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML})
		return
	}

	kb := telegram.NewKeyboard()
	kb.AddRow(dataBtn("🔙 Back", fmt.Sprintf("player:back:%d", chatIDNum)))
	var msg string
	if n == 0 {
		msg = "╭─❰ ✅ ʟᴏᴏᴘ ᴅɪꜱᴀʙʟᴇᴅ ❱\n│\n" +
			"│  Song will play once and stop.\n│\n" +
			"╰─❰ — ❱"
	} else {
		msg = fmt.Sprintf(
			"╭─❰ ✅ ʟᴏᴏᴘ ꜱᴇᴛ ❱\n│\n"+
				"│  🔁  <b>Repeat count</b>  ›  %d\n│\n"+
				"│  The song will loop after it ends.\n│\n"+
				"╰─❰ — ❱",
			n,
		)
	}
	c.SendMessage(userID, msg, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func returnBackFromLoop(cb *telegram.CallbackQuery, ownerID, chatIDNum int64) {
	if _, ok := cm.StatusChat(ownerID, chatIDNum); ok {
		text, kb := buildChatControlPanel(ownerID, chatIDNum, panelHeaderNowPlaying)
		_, _ = cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
		return
	}
	text, kb := buildStopScreen(ownerID, chatIDNum, panelHeaderStopped)
	_, _ = cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func notifyPlayerPlaybackEnd(ownerID, chatIDNum int64) {
	if cm.Count(ownerID) == 0 {
		return
	}
	// The user who started THIS chat's playback gets the finished screen —
	// in a delegated context that is the delegate, not the grantor.
	target := takePlayStarter(ownerID, chatIDNum)
	if target == 0 {
		target = ownerID
	}
	text, kb := buildStopScreen(ownerID, chatIDNum, panelHeaderFinished)
	c.SendMessage(target, text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func formatPlayerTime(ms uint64) string {
	sec := ms / 1000
	h := sec / 3600
	m := (sec % 3600) / 60
	s := sec % 60
	if h > 0 {
		return fmt.Sprintf("%d:%02d:%02d", h, m, s)
	}
	return fmt.Sprintf("%02d:%02d", m, s)
}

func probeMediaDuration(filePath string) uint64 {
	out, err := exec.Command("ffprobe", "-v", "error",
		"-show_entries", "format=duration",
		"-of", "default=noprint_wrappers=1:nokey=1", filePath).Output()
	if err != nil {
		return 0
	}
	f, err := strconv.ParseFloat(strings.TrimSpace(string(out)), 64)
	if err != nil || f <= 0 {
		return 0
	}
	return uint64(f * 1000)
}

func detectPlayMedia(m *telegram.NewMessage) (isVideo bool, mime string, err error) {
	if !m.IsMedia() {
		return false, "", fmt.Errorf("no media found in message")
	}

	if video := m.Video(); video != nil {
		return true, video.MimeType, nil
	}

	if audio := m.Audio(); audio != nil {
		return false, audio.MimeType, nil
	}

	if doc := m.Document(); doc != nil {
		for _, attr := range doc.Attributes {
			if _, ok := attr.(*telegram.DocumentAttributeAnimated); ok {
				return false, "", fmt.Errorf("unsupported file: send an audio or video file")
			}
			if _, ok := attr.(*telegram.DocumentAttributeSticker); ok {
				return false, "", fmt.Errorf("unsupported file: send an audio or video file")
			}
		}

		ext := strings.ToLower(filepath.Ext(docFileName(doc)))
		if isPlayableAudioExt(ext) || isPlayableVideoExt(ext) || isPlayableMime(doc.MimeType) {
			return isPlayableVideoExt(ext) || strings.HasPrefix(strings.ToLower(doc.MimeType), "video/"), doc.MimeType, nil
		}
	}

	return false, "", fmt.Errorf("unsupported file: send an audio or video file")
}

func docFileName(doc *telegram.DocumentObj) string {
	for _, attr := range doc.Attributes {
		if f, ok := attr.(*telegram.DocumentAttributeFilename); ok && f.FileName != "" {
			return f.FileName
		}
	}
	return ""
}

func isPlayableAudioExt(ext string) bool {
	switch ext {
	case ".mp3", ".ogg", ".oga", ".opus", ".flac", ".wav", ".m4a", ".aac", ".wma", ".mid", ".amr", ".aiff", ".ape":
		return true
	}
	return false
}

func isPlayableVideoExt(ext string) bool {
	switch ext {
	case ".mp4", ".mkv", ".webm", ".avi", ".mov", ".m4v", ".flv", ".wmv", ".ts", ".3gp":
		return true
	}
	return false
}

func isPlayableMime(mime string) bool {
	lower := strings.ToLower(mime)
	return strings.HasPrefix(lower, "audio/") || strings.HasPrefix(lower, "video/")
}

func downloadPlayMedia(ctx context.Context, m *telegram.NewMessage) (string, error) {
	if doc := m.Document(); doc != nil && doc.Size > maxPlayMediaBytes {
		return "", fmt.Errorf("file too large (max %d MB)", maxPlayMediaBytes>>20)
	}
	// Unique directory per download: two users sending "song.mp3" can no
	// longer overwrite each other's file.
	dir := filepath.Join(playMediaDir, fmt.Sprintf("%d_%d", m.SenderID(), time.Now().UnixNano()))
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return m.Download(&telegram.DownloadOptions{
		FileName: dir + string(os.PathSeparator),
		Ctx:      ctx,
	})
}

const maxPlayMediaBytes = 500 << 20
