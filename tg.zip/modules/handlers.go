package modules

import (
	"context"
	"fmt"
	"os"
	"runtime/debug"
	"strings"
	"unicode"

	"tgmultibot/config"
	"tgmultibot/manager"

	"github.com/amarnathcjd/gogram/telegram"
)

var (
	c     *telegram.Client
	cm    *manager.ClientManager
	ropts = telegram.BuildReplyOptions{ResizeKeyboard: true}
)

// ── Button text constants (handler matching ke liye) ──
const (
	BtnAddClient       = "➕ ᴀᴅᴅ ᴄʟɪᴇɴᴛ"
	BtnAddByPhone      = "📱 ᴀᴅᴅ ʙʏ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ"
	BtnUploadSession   = "📤 ᴜᴘʟᴏᴀᴅ ꜱᴇꜱꜱɪᴏɴ"
	BtnAddClientBack   = "🔙 ʙᴀᴄᴋ"
	BtnAddClientCancel = "🚫 ᴄᴀɴᴄᴇʟ"
	BtnMyClients       = "📋 ᴍʏ ᴄʟɪᴇɴᴛꜱ"
	BtnReact           = "❤️ ꜱᴇɴᴅ ʀᴇᴀᴄᴛɪᴏɴ"
	BtnJoinChannel     = "🔗 ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ"
	BtnJoinVoiceChat   = "🎙 ᴊᴏɪɴ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ"
	BtnLeaveVoiceChat  = "🔇 ʟᴇᴀᴠᴇ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ"
	BtnPlayMedia       = "🎵 ᴘʟᴀʏᴇʀ"
	BtnPanelList       = "📋 ʟɪꜱᴛ ᴄʜᴀᴛꜱ"
	BtnPanelAdd        = "➕ ᴀᴅᴅ ᴄʜᴀᴛ"
	BtnAutoReact       = "🔁 ᴀᴜᴛᴏ ʀᴇᴀᴄᴛ"
	BtnAutoView        = "👁 ᴀᴜᴛᴏ ᴠɪᴇᴡ"
	BtnBackToMenu      = "🔙 ʙᴀᴄᴋ ᴛᴏ ᴍᴇɴᴜ"
	BtnSwitchAccess    = "🔀 ꜱᴡɪᴛᴄʜ ᴀᴄᴄᴇꜱꜱ"

	// ── Sub-menu entry buttons (main menu ko chhota rakhne ke liye) ──
	BtnAutomation = "🤖 ᴀᴜᴛᴏᴍᴀᴛɪᴏɴ"
	BtnSystem     = "📊 ꜱʏꜱᴛᴇᴍ"

	// ── System panel buttons (parity with the reference panels) ──
	BtnUptime     = "⏱ ᴜᴘᴛɪᴍᴇ"
	BtnPing       = "🏓 ᴘɪɴɢ"
	BtnStatus     = "📊 ꜱᴛᴀᴛᴜꜱ"
	BtnMyInfo     = "👤 ᴍʏ ɪɴꜰᴏ"
	BtnSmsInbox   = "📩 ꜱᴍꜱ ɪɴʙᴏx"
	BtnExportZip  = "📤 ᴇxᴘᴏʀᴛ ᴢɪᴘ"
	BtnImportZip  = "📦 ɪᴍᴘᴏʀᴛ ᴢɪᴘ"
	BtnAutoCall   = "📞 ᴀᴜᴛᴏ ᴄᴀʟʟ"
	BtnClearAuto  = "🧹 ᴄʟᴇᴀʀ ᴍʏ ᴀᴜᴛᴏ"
	BtnRestartAcc = "🔄 ʀᴇꜱᴛᴀʀᴛ ᴀᴄᴄᴏᴜɴᴛꜱ"

	// Access-related constants. Single source of truth is authorized.go —
	// do NOT redeclare them here (duplicate const = compile error).
)

const handlerGroup = 1

// ── Colour styles ──
const (
	ClrSuccess = "success" // green
	ClrDanger  = "danger"  // red
	ClrPrimary = "primary" // blue
)

// styleOf har reply-keyboard button ke liye native colour decide karta hai.
//
//	🟢 Success = positive / start / add      🔴 Danger = stop / remove / clear
//	🔵 Primary = navigation / info / menu
func styleOf(text string) string {
	switch text {
	case BtnAddClient, BtnAddByPhone, BtnUploadSession,
		BtnJoinChannel, BtnJoinVoiceChat,
		BtnAutoCall, BtnExportZip, BtnImportZip,
		BtnGetToken, BtnPanelAdd:
		return ClrSuccess

	case BtnAddClientCancel, BtnLeaveVoiceChat, BtnClearAuto:
		return ClrDanger

	case BtnMyClients, BtnPanelList,
		BtnAutoReact, BtnAutoView, BtnReact,
		BtnPlayMedia, BtnSwitchAccess,
		BtnUptime, BtnPing, BtnStatus, BtnMyInfo,
		BtnSmsInbox, BtnRestartAcc,
		BtnAutomation, BtnSystem,
		BtnAccess, BtnEnterToken, BtnMyDelegates,
		BtnBackToMenu, BtnBackToAccess, BtnAddClientBack:
		return ClrPrimary

	default:
		return styleByLabel(text)
	}
}

// styleByLabel label ke pehle shabd se colour nikalta hai — isse har
// inline/reply button ko automatically colour milta hai, chahe naya button
// kisi constant me ho ya na ho.
func styleByLabel(label string) string {
	w := firstWord(label)
	switch w {
	case "":
		return ""
	case "yes", "accept", "play", "resume", "unmute", "add", "get",
		"request", "replay", "another", "confirm", "approve", "start", "save":
		return ClrSuccess
	case "no", "cancel", "remove", "stop", "reject", "terminate", "mute",
		"clear", "delete", "leave", "disapprove":
		return ClrDanger
	default:
		return ClrPrimary
	}
}

// firstWord leading emoji / symbols hata kar pehla lowercase shabd deta hai.
func firstWord(s string) string {
	var b strings.Builder
	started := false
	for _, r := range s {
		isWord := unicode.IsLetter(r) || (started && unicode.IsDigit(r))
		if !started {
			if unicode.IsLetter(r) {
				started = true
				b.WriteRune(unicode.ToLower(r))
			}
			continue
		}
		if !isWord {
			break
		}
		b.WriteRune(unicode.ToLower(r))
	}
	return b.String()
}

// styledText reply-keyboard button banata hai aur native colour lagata hai.
func styledText(text string) *telegram.KeyboardButtonObj {
	b := telegram.Button.Text(text)
	switch styleOf(text) {
	case ClrSuccess:
		return b.Success()
	case ClrDanger:
		return b.Danger()
	case ClrPrimary:
		return b.Primary()
	}
	return b
}

// dataBtn inline callback button banata hai. Colour label se auto-detect hota
// hai; "…:noop" placeholder buttons neutral rehte hain.
func dataBtn(text, data string) *telegram.KeyboardButtonCallback {
	b := telegram.Button.Data(text, data)
	if strings.HasSuffix(data, ":noop") {
		return b
	}
	return applyStyleInline(b, styleByLabel(text))
}

// applyStyleInline inline callback button par native colour lagata hai.
// Note: KeyboardButtonStyle gogram ke TL layer ka feature hai — jo clients
// ise support nahi karte wo ise ignore karte hain, behaviour same rehta hai.
func applyStyleInline(btn *telegram.KeyboardButtonCallback, style string) *telegram.KeyboardButtonCallback {
	if btn == nil {
		return nil
	}
	switch style {
	case ClrSuccess:
		return btn.Success()
	case ClrDanger:
		return btn.Danger()
	case ClrPrimary:
		return btn.Primary()
	}
	return btn
}

func Load(client *telegram.Client, mgr *manager.ClientManager) error {
	c = client
	cm = mgr

	// Remove media left over from a previous run (crash / restart).
	_ = os.RemoveAll(playMediaDir)

	cm.SetOnPlaybackEnd(func(ownerID int64, chatIDNum int64) {
		go notifyPlayerPlaybackEnd(ownerID, chatIDNum)
	})

	// Register the SMS-inbox + auto-call hooks on every live userbot
	// connection — including the accounts restored from the database AFTER
	// this Load call (RestoreFromDB fires SetOnClientAdded for each).
	cm.SetOnClientAdded(registerClientHooks)
	cm.EachClient(registerClientHooks)

	// Media collector runs before every other handler so uploaded files and
	// albums reach the active conversation listener (OTP, session upload,
	// panel add) instead of being dropped as unhandled messages.
	c.On(telegram.OnMessage, wrap(handleMediaCollector)).SetGroup(handlerGroup)

	c.On("message:/start", wrap(handleStart)).SetGroup(handlerGroup)
	c.On("message:/cancel", wrap(handleCancel)).SetGroup(handlerGroup)
	c.On("message:/help", wrap(handleHelp)).SetGroup(handlerGroup)
	c.On("message:/approved", ownerWrap(handleApprovedUsers)).SetGroup(handlerGroup)
	c.On("message:/approve", ownerWrap(handleApproveUser)).SetGroup(handlerGroup)
	c.On("message:/disapprove", ownerWrap(handleDisapproveUser)).SetGroup(handlerGroup)

	c.On("message:"+BtnAddClient, wrap(handleAddClientPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAddByPhone, wrap(handleAddByPhonePrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnUploadSession, wrap(handleUploadSessionPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAddClientCancel, wrap(handleAddClientCancel)).SetGroup(handlerGroup)
	c.On("message:"+BtnAddClientBack, wrap(handleAddClientBack)).SetGroup(handlerGroup)
	c.On("message:"+BtnMyClients, wrap(handleMyClients)).SetGroup(handlerGroup)
	c.On("message:"+BtnReact, wrap(handleReactPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnJoinChannel, wrap(handleJoinChannelPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnJoinVoiceChat, wrap(handleJoinVoiceChatPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnLeaveVoiceChat, wrap(handleLeaveVoiceChat)).SetGroup(handlerGroup)
	c.On("message:"+BtnPlayMedia, wrap(handlePlayerPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnBackToMenu, wrap(handleStart)).SetGroup(handlerGroup)
	c.On("message:"+BtnAutomation, wrap(handleAutomationMenu)).SetGroup(handlerGroup)
	c.On("message:"+BtnSystem, wrap(handleSystemMenu)).SetGroup(handlerGroup)

	c.On("message:"+BtnAutoReact, wrap(handleAutoReactPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAutoView, wrap(handleAutoViewPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAutoCall, wrap(handleAutoCallPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnPanelList, wrap(handlePanelListPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnPanelAdd, wrap(handlePanelAddPrompt)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleAutoChatCallback)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleClientCallback)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handlePlayerCallback)).SetGroup(handlerGroup)

	// ── System panel ──
	c.On("message:"+BtnUptime, wrap(handleUptime)).SetGroup(handlerGroup)
	c.On("message:"+BtnPing, wrap(handlePing)).SetGroup(handlerGroup)
	c.On("message:"+BtnStatus, wrap(handleStatus)).SetGroup(handlerGroup)
	c.On("message:"+BtnMyInfo, wrap(handleMyInfo)).SetGroup(handlerGroup)
	c.On("message:"+BtnSmsInbox, wrap(handleSMSInbox)).SetGroup(handlerGroup)
	c.On("message:"+BtnExportZip, wrap(handleExportZip)).SetGroup(handlerGroup)
	c.On("message:"+BtnImportZip, wrap(handleImportZip)).SetGroup(handlerGroup)
	c.On("message:"+BtnClearAuto, wrap(handleClearMyAuto)).SetGroup(handlerGroup)
	c.On("message:"+BtnRestartAcc, wrap(handleRestartAccounts)).SetGroup(handlerGroup)

	c.On("message:"+BtnAccess, wrap(handleAccessPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnGetToken, wrap(handleGetToken)).SetGroup(handlerGroup)
	c.On("message:"+BtnEnterToken, wrap(handleEnterTokenPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnMyDelegates, wrap(handleMyDelegates)).SetGroup(handlerGroup)
	c.On("message:"+BtnBackToAccess, wrap(handleAccessPrompt)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleAccessCallback)).SetGroup(handlerGroup)

	c.On("message:"+BtnSwitchAccess, wrap(handleSwitchAccess)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleSwitchAccessCallback)).SetGroup(handlerGroup)

	registerCommandAliases()

	return nil
}

// registerCommandAliases wires slash commands to the keyboard-button handlers,
// so the bot stays usable even when the reply keyboard is hidden. /broadcast
// is the owner-only mass-messaging tool.
func registerCommandAliases() {
	aliases := []struct {
		cmd string
		fn  func(*telegram.NewMessage) error
	}{
		{"/menu", handleStart},
		{"/clients", handleMyClients},
		{"/react", handleReactPrompt},
		{"/join", handleJoinChannelPrompt},
		{"/voice", handleJoinVoiceChatPrompt},
		{"/leave", handleLeaveVoiceChat},
		{"/player", handlePlayerPrompt},
		{"/autoreact", handleAutoReactPrompt},
		{"/autoview", handleAutoViewPrompt},
		{"/autocall", handleAutoCallPrompt},
		{"/inbox", handleSMSInbox},
		{"/export", handleExportZip},
		{"/import", handleImportZip},
		{"/automation", handleAutomationMenu},
		{"/system", handleSystemMenu},
		{"/clearauto", handleClearMyAuto},
		{"/restart", handleRestartAccounts},
		{"/uptime", handleUptime},
		{"/ping", handlePing},
		{"/status", handleStatus},
		{"/me", handleMyInfo},
		{"/access", handleAccessPrompt},
		{"/switch", handleSwitchAccess},
	}
	for _, a := range aliases {
		c.On("message:"+a.cmd, wrap(a.fn)).SetGroup(handlerGroup)
	}
	c.On("message:/broadcast", ownerWrap(handleBroadcast)).SetGroup(handlerGroup)
}

func handleCancel(m *telegram.NewMessage) error {
	userID := m.SenderID()
	name := ps.current(userID)
	if name == "" {
		_, err := m.Reply(
			"╭─❰ ℹ️ ɴᴏ ᴀᴄᴛɪᴠᴇ ᴘʀᴏᴄᴇꜱꜱ ❱\n│\n"+
				"│  ✦ ɴᴏᴛʜɪɴɢ ɪꜱ ʀᴜɴɴɪɴɢ ʀɪɢʜᴛ ɴᴏᴡ\n│\n"+
				"╰─❰ ✨ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ps.cancel(userID)

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ 🚫 ᴄᴀɴᴄᴇʟʟᴇᴅ ❱\n│\n"+
				"│  ▸ ᴘʀᴏᴄᴇꜱꜱ:  <code>%s</code>\n│\n"+
				"╰─❰ 🏠 ʙᴀᴄᴋ ᴛᴏ ᴛʜᴇ ᴍᴀɪɴ ᴍᴇɴᴜ ❱",
			escapeHTML(name),
		),
		panelReplyOpts(userID),
	)
	return err
}

func guardProcess(m *telegram.NewMessage, name string) (context.Context, bool) {
	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnBackToMenu))
	return guardProcessWithKeyboard(m, name, kb)
}

func guardProcessWithKeyboard(
	m *telegram.NewMessage,
	name string,
	kb *telegram.KeyboardBuilder,
) (context.Context, bool) {
	userID := m.SenderID()
	if existing := ps.current(userID); existing != "" {
		m.Reply(
			busyMsg(existing),
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
		)
		return nil, false
	}
	ctx, ok := ps.tryStart(userID, name)
	return ctx, ok
}

// wrap guards a *message* handler: only private chats, only authorized users,
// always panic-safe, always traceback-logged. telegram.ErrEndGroup is treated
// as a normal short-circuit (used by sendUnauthorizedPrompt and similar) and
// is not logged as an error.
func wrap(fn func(*telegram.NewMessage) error) func(*telegram.NewMessage) error {
	return func(m *telegram.NewMessage) (err error) {
		if !m.IsPrivate() {
			return nil
		}
		defer func() {
			if r := recover(); r != nil {
				sendTraceback(fmt.Sprintf("panic in handler: %v\n%s", r, debug.Stack()))
				err = fmt.Errorf("panic: %v", r)
			}
		}()

		if !isAuthorizedOrOwner(m.SenderID()) {
			return sendUnauthorizedPrompt(m)
		}

		if err = fn(m); err != nil && err != telegram.ErrEndGroup {
			sendTraceback(fmt.Sprintf("error in handler: %v\n%s", err, debug.Stack()))
		}
		return
	}
}

// wrapCb guards a *callback* handler: only private chats, only authorized
// users (except the access-request button, which unauthorized users must be
// able to tap), always panic-safe, always traceback-logged.
func wrapCb(fn func(*telegram.CallbackQuery) error) func(*telegram.CallbackQuery) error {
	return func(cb *telegram.CallbackQuery) (err error) {
		if !cb.IsPrivate() {
			return nil
		}
		defer func() {
			if r := recover(); r != nil {
				sendTraceback(fmt.Sprintf("panic in callback: %v\n%s", r, debug.Stack()))
				err = fmt.Errorf("panic: %v", r)
			}
		}()

		if !isUnauthorizedAccessRequestCallback(cb.DataString()) && !isAuthorizedOrOwner(cb.GetSenderID()) {
			_, err = cb.Answer("🚫 ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ʙᴏᴛ", &telegram.CallbackOptions{Alert: true})
			return
		}

		if err = fn(cb); err != nil {
			sendTraceback(fmt.Sprintf("error in callback: %v\n%s", err, debug.Stack()))
		}
		return
	}
}

// sendTraceback posts a formatted traceback to the configured logger chat.
// The body is HTML-escaped — stack traces routinely contain `<`, `>`, and `&`
// (from generic type names like `map[string]*foo`), and raw `<pre>` blocks
// would otherwise swallow or misrender them.
func sendTraceback(text string) {
	if config.LoggerID == 0 {
		return
	}
	c.SendMessage(
		config.LoggerID,
		"╭─❰ ❌ ᴇʀʀᴏʀ ᴛʀᴀᴄᴇʙᴀᴄᴋ ❱\n\n<pre>"+escapeHTML(text)+"</pre>",
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)
}