package modules

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"tgmultibot/manager"

	"github.com/amarnathcjd/gogram/telegram"
)

func handleJoinVoiceChatPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(
			"╭─❰ ❌ 𝗡𝗢 𝗖𝗟𝗜𝗘𝗡𝗧𝗦 ❱\n│\n"+
				"│  Add a client before joining a voice chat.\n│\n"+
				"╰─❰ ➕ Tap Add Client first ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ctx, ok := guardProcess(m, "Join Voice Chat")
	if !ok {
		return nil
	}
	cg.SetListening(userID)

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))

	_, err := m.Reply(
		"╭─❰ 🎙 𝗝𝗢𝗜𝗡 𝗩𝗢𝗜𝗖𝗘 𝗖𝗛𝗔𝗧 ❱\n│\n"+
			"│  Send a username or Chat ID.\n│\n"+
			"│  🌐  <b>Public</b>   ›  <code>@username</code>\n"+
			"│  🔒  <b>Private</b>  ›  <code>-1001234567890</code>\n"+
			"│                  or  <code>t.me/c/1234567890</code>\n│\n"+
			"│  ⚠️  For private groups/channels:\n"+
			"│      use <b>🔗 Join Channel</b> first,\n"+
			"│      then come back with the Chat ID.\n│\n"+
			"│  ⚠️  Invite links (<code>t.me/+...</code>) are\n"+
			"│      not supported here.\n│\n"+
			"╰─❰ ⌨️ Awaiting your link (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)
	if err != nil {
		ps.done(userID)
		return err
	}

	go vcLinkStep(ctx, userID, ownerID)
	return nil
}

func vcLinkStep(ctx context.Context, userID, ownerID int64) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in vcLinkStep: %v", r))
			ps.done(userID)
			cg.StopListening(userID)
		}
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ 𝗧𝗜𝗠𝗘𝗗 𝗢𝗨𝗧 ❱\n│\n"+
					"│  Tap <b>🎙 Join Voice Chat</b> to try again.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: telegram.Button.Clear()},
			)
		}
		ps.done(userID)
		cg.StopListening(userID)
		return
	}

	if ctx.Err() != nil {
		cg.StopListening(userID)
		return
	}

	text := strings.TrimSpace(msgs[0].Text())
	if text == "" {
		c.SendMessage(userID,
			"╭─❰ 📎 𝗧𝗘𝗫𝗧 𝗢𝗡𝗟𝗬 ❱\n│\n"+
				"│  Send a username or Chat ID,\n"+
				"│  not a file.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		ps.done(userID)
		cg.StopListening(userID)
		return
	}

	chatID, err := resolveVCPeer(text)
	if err != nil {
		c.SendMessage(userID,
			fmt.Sprintf(
				"╭─❰ ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗣𝗘𝗘𝗥 ❱\n│\n"+
					"│  %s\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(err.Error()),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		ps.done(userID)
		cg.StopListening(userID)
		return
	}

	cg.SetListening(userID)
	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))

	c.SendMessage(userID,
		"╭─❰ ⏱ 𝗗𝗨𝗥𝗔𝗧𝗜𝗢𝗡 ❱\n│\n"+
			"│  How long should clients stay in the\n"+
			"│  voice chat?\n│\n"+
			"│  Send duration in <b>seconds</b>.\n"+
			"│  Send <code>0</code> to stay indefinitely.\n│\n"+
			"│  Examples:\n"+
			"│    <code>300</code>   = 5 minutes\n"+
			"│    <code>3600</code>  = 1 hour\n"+
			"│    <code>0</code>     = forever\n│\n"+
			"╰─❰ ⌨️ Awaiting duration (send /cancel) ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)

	go vcDurationStep(ctx, userID, ownerID, chatID)
}

func vcDurationStep(ctx context.Context, userID, ownerID int64, chatID any) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in vcDurationStep: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ 𝗧𝗜𝗠𝗘𝗗 𝗢𝗨𝗧 ❱\n│\n"+
					"│  Tap <b>🎙 Join Voice Chat</b> to try again.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: telegram.Button.Clear()},
			)
		}
		return
	}

	if ctx.Err() != nil {
		return
	}

	text := strings.TrimSpace(msgs[0].Text())
	idleSec := 0
	if text != "0" && text != "" {
		n, err := strconv.Atoi(text)
		if err != nil || n < 0 {
			c.SendMessage(userID,
				"╭─❰ ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗗𝗨𝗥𝗔𝗧𝗜𝗢𝗡 ❱\n│\n"+
					"│  Send seconds (e.g. <code>300</code>)\n"+
					"│  or <code>0</code> for indefinite.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML},
			)
			return
		}
		idleSec = n
	}

	if ctx.Err() != nil {
		return
	}

	total := cm.Count(ownerID)
	prog, _ := c.SendMessage(userID,
		fmt.Sprintf(
			"╭─❰ ⏳ 𝗝𝗢𝗜𝗡𝗜𝗡𝗚 𝗩𝗢𝗜𝗖𝗘 ❱\n│\n"+
				"│  Trying with <b>%d</b> client(s)...\n│\n"+
				"╰─❰ — ❱",
			total,
		),
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)

	results := cm.JoinVoiceChat(ctx, ownerID, chatID, idleSec)

	joined, failed := 0, 0
	var accountErrors []manager.AccountError
	for _, r := range results {
		if r.NoActiveGroupCall {
			msg := "╭─❰ ❌ 𝗡𝗢 𝗔𝗖𝗧𝗜𝗩𝗘 𝗖𝗔𝗟𝗟 ❱\n│\n" +
				"│  No active voice chat was found\n" +
				"│  in that channel.\n│\n" +
				"│  Start a voice chat there first,\n" +
				"│  then try again.\n│\n" +
				"╰─❰ — ❱"
			if prog != nil {
				prog.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML})
			} else {
				c.SendMessage(userID, msg, &telegram.SendOptions{ParseMode: telegram.HTML})
			}
			return
		}

		if r.WrongPeerType {
			msg := "╭─❰ ❌ 𝗪𝗥𝗢𝗡𝗚 𝗣𝗘𝗘𝗥 𝗧𝗬𝗣𝗘 ❱\n│\n" +
				"│  That looks like a user account, not\n" +
				"│  a group or channel.\n│\n" +
				"│  Voice chats are only available in\n" +
				"│  groups and channels.\n│\n" +
				"╰─❰ — ❱"
			if prog != nil {
				prog.Edit(msg, &telegram.SendOptions{ParseMode: telegram.HTML})
			} else {
				c.SendMessage(userID, msg, &telegram.SendOptions{ParseMode: telegram.HTML})
			}
			return
		}

		if r.Err != nil {
			if r.Err == context.Canceled {
				continue
			}
			failed++
			accountErrors = append(accountErrors, manager.AccountError{AccountID: r.AccountID, Err: r.Err})
			sendTraceback(fmt.Sprintf("JoinVoiceChat error for user %d, account %d: %v", userID, r.AccountID, r.Err))
		} else {
			joined++
		}
	}

	durationStr := "indefinitely"
	if idleSec > 0 {
		durationStr = formatDuration(idleSec)
	}

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnLeaveVoiceChat))
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))
	opts := &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)}

	if ctx.Err() != nil {
		var result string
		if joined == 0 {
			result = "╭─❰ 🚫 𝗖𝗔𝗡𝗖𝗘𝗟𝗟𝗘𝗗 ❱\n│\n" +
				"│  No clients had joined yet.\n│\n" +
				"╰─❰ — ❱"
		} else {
			result = fmt.Sprintf(
				"╭─❰ 🚫 𝗖𝗔𝗡𝗖𝗘𝗟𝗟𝗘𝗗 𝗠𝗜𝗗-𝗝𝗢𝗜𝗡 ❱\n│\n"+
					"│  ✅  <b>Already joined</b>         ›  %d\n"+
					"│  ⏭  <b>Skipped (not started)</b>  ›  %d\n│\n"+
					"│  ⚠️  Those %d client(s) are still in\n"+
					"│      the voice chat.\n"+
					"│      Tap <b>🔇 Leave Voice Chat</b> to remove.\n│\n",
				joined, total-joined-failed, joined,
			)
		}
		if len(accountErrors) > 0 {
			summary := manager.SummarizeErrors(accountErrors)
			if joined == 0 {
				result = strings.TrimSuffix(result, "╰─❰ — ❱")
				result += "╰─❰ ⚠️ See error summary below ❱\n\n"
			} else {
				result += "╰─❰ ⚠️ See error summary below ❱\n\n"
			}
			result += manager.FormatErrorSummary(summary, "<b>Errors:</b>")
		} else if joined > 0 {
			result = strings.TrimSuffix(result, "\n│\n") + "\n│\n╰─❰ — ❱"
		}
		if prog != nil {
			prog.Edit(result, opts)
		} else {
			c.SendMessage(userID, result, opts)
		}
		return
	}

	var result string
	if len(accountErrors) > 0 {
		result = fmt.Sprintf(
			"╭─❰ ✅ 𝗝𝗢𝗜𝗡 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘 ❱\n│\n"+
				"│  🎙  <b>Joined</b>     ›  %d\n"+
				"│  ❌  <b>Failed</b>     ›  %d\n"+
				"│  ⏱  <b>Duration</b>   ›  %s\n│\n",
			joined, failed, durationStr,
		)
	} else {
		result = fmt.Sprintf(
			"╭─❰ ✅ 𝗝𝗢𝗜𝗡 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘 ❱\n│\n"+
				"│  🎙  <b>Joined</b>     ›  %d\n"+
				"│  ❌  <b>Failed</b>     ›  %d\n"+
				"│  ⏱  <b>Duration</b>   ›  %s\n│\n",
			joined, failed, durationStr,
		)
	}

	if len(accountErrors) > 0 {
		summary := manager.SummarizeErrors(accountErrors)
		result += "╰─❰ ⚠️ See error summary below ❱\n\n" +
			manager.FormatErrorSummary(summary, "<b>Errors:</b>")
	} else {
		result += "╰─❰ ✨ Clients are live in the call ❱"
	}

	if prog != nil {
		prog.Edit(result, opts)
	} else {
		c.SendMessage(userID, result, opts)
	}
}

func handleLeaveVoiceChat(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	active := cm.ActiveVoiceChats(ownerID)
	if len(active) == 0 {
		_, err := m.Reply(
			"╭─❰ ℹ️ 𝗡𝗢 𝗔𝗖𝗧𝗜𝗩𝗘 𝗖𝗔𝗟𝗟𝗦 ❱\n│\n"+
				"│  No clients are currently in a voice\n"+
				"│  chat.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	errs := cm.LeaveVoiceChat(ownerID)
	left := len(active) - len(errs)

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf(
		"╭─❰ 🔇 𝗟𝗘𝗙𝗧 𝗩𝗢𝗜𝗖𝗘 𝗖𝗛𝗔𝗧 ❱\n│\n"+
			"│  ✅  <b>Left</b>    ›  %d\n"+
			"│  ❌  <b>Failed</b>  ›  %d\n│\n",
		left, len(errs),
	))

	if len(errs) > 0 {
		var accountErrors []manager.AccountError
		for _, e := range errs {
			accountErrors = append(accountErrors, manager.AccountError{AccountID: 0, Err: e})
		}
		summary := manager.SummarizeErrors(accountErrors)
		sb.WriteString("╰─❰ ⚠️ See error summary below ❱\n\n")
		sb.WriteString(manager.FormatErrorSummary(summary, "<b>Errors:</b>"))
	} else {
		sb.WriteString("╰─❰ ✨ All clients left cleanly ❱")
	}

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))
	_, err := m.Reply(sb.String(), &telegram.SendOptions{
		ParseMode:   telegram.HTML,
		ReplyMarkup: kb.BuildReply(ropts),
	})
	return err
}

func resolveVCPeer(input string) (any, error) {
	input = strings.TrimSpace(input)
	clean := input
	clean = strings.TrimPrefix(clean, "https://")
	clean = strings.TrimPrefix(clean, "http://")
	clean = strings.TrimPrefix(clean, "t.me/")
	clean = strings.Trim(clean, "/")

	lower := strings.ToLower(clean)
	if strings.HasPrefix(clean, "+") || strings.HasPrefix(lower, "joinchat/") {
		return nil, fmt.Errorf(
			"invite links aren't supported here — use 🔗 Join Channel first, " +
				"then come back with the Chat ID (e.g. -1001234567890)",
		)
	}

	if strings.HasPrefix(clean, "c/") {
		rest := strings.SplitN(strings.TrimPrefix(clean, "c/"), "/", 2)[0]
		var bareID int64
		if _, err := fmt.Sscanf(rest, "%d", &bareID); err != nil {
			return nil, fmt.Errorf("invalid channel id in link")
		}
		return chanIDToPeer(bareID), nil
	}

	if strings.HasPrefix(clean, "@") {
		return strings.TrimPrefix(clean, "@"), nil
	}

	if id, err := strconv.ParseInt(clean, 10, 64); err == nil {
		return id, nil
	}

	return clean, nil
}

func formatDuration(sec int) string {
	if sec < 60 {
		return fmt.Sprintf("%d second(s)", sec)
	}
	if sec < 3600 {
		return fmt.Sprintf("%d minute(s)", sec/60)
	}
	return fmt.Sprintf("%dh %dm", sec/3600, (sec%3600)/60)
}