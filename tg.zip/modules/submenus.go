package modules

import (
	"github.com/amarnathcjd/gogram/telegram"
)

// ── Sub-menus ───────────────────────────────────────────────────────────────
// Main keyboard ko chhota rakhne ke liye related buttons do sub-menus me
// group hain. Andar ke buttons ke handlers global hain (handlers.go), isliye
// koi naya logic nahi chahiye — sirf naya keyboard.

func automationMenuKB() telegram.ReplyMarkup {
	kb := telegram.NewKeyboard()
	kb.AddRow(
		styledText(BtnAutoReact),
		styledText(BtnAutoView),
	).AddRow(
		styledText(BtnAutoCall),
		styledText(BtnClearAuto),
	).AddRow(
		styledText(BtnBackToMenu),
	)
	return kb.BuildReply(ropts)
}

func systemMenuKB() telegram.ReplyMarkup {
	kb := telegram.NewKeyboard()
	kb.AddRow(
		styledText(BtnStatus),
		styledText(BtnMyInfo),
	).AddRow(
		styledText(BtnPing),
		styledText(BtnUptime),
	).AddRow(
		styledText(BtnExportZip),
		styledText(BtnImportZip),
	).AddRow(
		styledText(BtnRestartAcc),
	).AddRow(
		styledText(BtnBackToMenu),
	)
	return kb.BuildReply(ropts)
}

// 🤖 Automation
func handleAutomationMenu(m *telegram.NewMessage) error {
	_, err := m.Reply(
		"╭─❰ 🤖 ᴀᴜᴛᴏᴍᴀᴛɪᴏɴ ❱\n│\n"+
			"│  🔁  <b>Auto React</b>  ›  react on new posts\n"+
			"│  👁  <b>Auto View</b>   ›  view new posts\n"+
			"│  📞  <b>Auto Call</b>   ›  auto voice-chat join\n"+
			"│  🧹  <b>Clear My Auto</b> ›  stop everything\n│\n"+
			"╰─❰ ✨ Choose an option below ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: automationMenuKB()},
	)
	return err
}

// 📊 System
func handleSystemMenu(m *telegram.NewMessage) error {
	_, err := m.Reply(
		"╭─❰ 📊 ꜱʏꜱᴛᴇᴍ ❱\n│\n"+
			"│  📊  <b>Status</b>   ›  live overview\n"+
			"│  👤  <b>My Info</b>  ›  your account & context\n"+
			"│  🏓  <b>Ping</b> · ⏱ <b>Uptime</b>  ›  health\n"+
			"│  📤  <b>Export</b> · 📦 <b>Import</b>  ›  sessions\n"+
			"│  🔄  <b>Restart</b>  ›  reconnect accounts\n│\n"+
			"╰─❰ ✨ Choose an option below ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: systemMenuKB()},
	)
	return err
}
