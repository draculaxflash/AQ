package modules

import (
	"fmt"
	"strings"
	"sync"

	"tgmultibot/config"
	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

var (
	accessCtxMu sync.RWMutex
	accessCtx   = map[int64]int64{} // userID -> grantorID they're acting as (0/absent = personal)
)

func effectiveOwnerID(userID int64) int64 {
	accessCtxMu.RLock()
	id := accessCtx[userID]
	accessCtxMu.RUnlock()
	if id == 0 {
		return userID
	}
	// Re-validate the delegation on EVERY use, so a revoked delegate loses
	// access immediately.
	for _, g := range database.GrantorsFor(userID) {
		if g == id {
			return id
		}
	}
	clearUserCtx(userID)
	return userID
}

func setAccessCtx(userID, ownerID int64) {
	accessCtxMu.Lock()
	if ownerID == 0 || ownerID == userID {
		delete(accessCtx, userID)
	} else {
		accessCtx[userID] = ownerID
	}
	accessCtxMu.Unlock()
}

func isPersonalCtx(userID int64) bool {
	return effectiveOwnerID(userID) == userID
}

// clearDelegateCtx resets every delegate currently acting as grantorID back to
// personal context — called when a grantor revokes a delegate's access.
func clearDelegateCtx(grantorID int64) {
	accessCtxMu.Lock()
	for userID, gid := range accessCtx {
		if gid == grantorID {
			delete(accessCtx, userID)
		}
	}
	accessCtxMu.Unlock()
}

// clearUserCtx resets a single user back to personal context.
func clearUserCtx(userID int64) {
	accessCtxMu.Lock()
	delete(accessCtx, userID)
	accessCtxMu.Unlock()
}

// buildMenuKB builds the contextual reply keyboard for a user.
// Add Client is hidden in non-personal context.
func buildMenuKB(userID int64) telegram.ReplyMarkup {
	personal := isPersonalCtx(userID)
	isOwner := config.Owner != nil && userID == config.Owner.ID

	kb := telegram.NewKeyboard()
	if personal || isOwner {
		kb.AddRow(
			styledText(BtnAddClient),
			styledText(BtnMyClients),
		)
	} else {
		kb.AddRow(styledText(BtnMyClients))
	}
	kb.AddRow(
		styledText(BtnReact),
		styledText(BtnJoinChannel),
	).AddRow(
		styledText(BtnJoinVoiceChat),
		styledText(BtnLeaveVoiceChat),
	).AddRow(
		styledText(BtnPlayMedia),
		styledText(BtnSmsInbox),
	).AddRow(
		styledText(BtnAutomation),
		styledText(BtnSystem),
	).AddRow(
		styledText(BtnAccess),
		styledText(BtnSwitchAccess),
	)
	return kb.BuildReply(ropts)
}

func handleSwitchAccess(m *telegram.NewMessage) error {
	userID := m.SenderID()
	text, kb := buildSwitchAccessMsg(userID)
	_, err := m.Reply(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
	return err
}

func buildSwitchAccessMsg(userID int64) (string, *telegram.KeyboardBuilder) {
	grantors := database.GrantorsFor(userID)
	current := effectiveOwnerID(userID)

	kb := telegram.NewKeyboard()

	// Personal Button (Green if active, Blue otherwise)
	personalLabel := "👤 Personal"
	personalStyle := ClrPrimary
	if current == userID {
		personalLabel = "✅ " + personalLabel
		personalStyle = ClrSuccess
	}
	btnPersonal := applyStyleInline(dataBtn(personalLabel, "swacc:personal"), personalStyle)
	kb.AddRow(btnPersonal)

	// Delegated Buttons (Green if active, Blue otherwise)
	for _, grantorID := range grantors {
		label := grantorLabel(grantorID)
		btnStyle := ClrPrimary
		if current == grantorID {
			label = "✅ " + label
			btnStyle = ClrSuccess
		}
		btnDelegated := applyStyleInline(dataBtn(label, fmt.Sprintf("swacc:use:%d", grantorID)), btnStyle)
		kb.AddRow(btnDelegated)
	}

	var currentDisplay string
	if current == userID {
		currentDisplay = "👤 <b>Personal</b>"
	} else {
		currentDisplay = escapeHTML(grantorLabel(current))
	}

	var body strings.Builder
	body.WriteString("│  👤  <b>Personal</b>\n")
	body.WriteString("│      Your own clients\n│\n")
	if len(grantors) > 0 {
		body.WriteString(fmt.Sprintf("│  🔑  <b>Delegated</b>  —  <b>%d</b> available\n", len(grantors)))
	} else {
		body.WriteString("│  🔑  <b>Delegated</b>\n")
	}
	body.WriteString("│      Act as someone else's clients\n│\n")
	body.WriteString("│  <b>Active:</b>  ")
	body.WriteString(currentDisplay)
	body.WriteString("\n│\n")

	text := "╭─❰ 🔄 ꜱᴡɪᴛᴄʜ ᴀᴄᴄᴇꜱꜱ ❱\n│\n" + body.String() + "╰─❰ ✨ Choose a context below ❱"
	return text, kb
}

func grantorLabel(grantorID int64) string {
	user, err := c.GetUser(grantorID)
	if err != nil || user == nil {
		return fmt.Sprintf("🔑 ID %d", grantorID)
	}
	if user.Username != "" {
		return "🔑 @" + user.Username
	}
	if user.FirstName != "" {
		return "🔑 " + user.FirstName
	}
	return fmt.Sprintf("🔑 ID %d", grantorID)
}

func handleSwitchAccessCallback(cb *telegram.CallbackQuery) error {
	data := cb.DataString()
	userID := cb.GetSenderID()

	switch {
	case data == "swacc:personal":
		setAccessCtx(userID, userID)
		return refreshSwitchMsg(cb, userID, "✅ Switched to Personal.")

	case strings.HasPrefix(data, "swacc:use:"):
		var grantorID int64
		if _, err := fmt.Sscanf(strings.TrimPrefix(data, "swacc:use:"), "%d", &grantorID); err != nil || grantorID == 0 {
			_, err := cb.Answer("Invalid.")
			return err
		}

		valid := false
		for _, g := range database.GrantorsFor(userID) {
			if g == grantorID {
				valid = true
				break
			}
		}
		if !valid {
			_, err := cb.Answer("⚠️ This delegation is no longer active.", &telegram.CallbackOptions{Alert: true})
			return err
		}

		setAccessCtx(userID, grantorID)
		return refreshSwitchMsg(cb, userID, "✅ Switched to "+grantorLabel(grantorID)+".")
	}
	_, err := cb.Answer("")
	return err
}

func refreshSwitchMsg(cb *telegram.CallbackQuery, userID int64, toast string) error {
	text, kb := buildSwitchAccessMsg(userID)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}

	c.SendMessage(userID, buildMainMenuRefreshText(userID),
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})

	_, err := cb.Answer(toast)
	return err
}

// buildMainMenuRefreshText renders the small framed message that accompanies
// the fresh reply keyboard after a context switch.
func buildMainMenuRefreshText(userID int64) string {
	ownerID := effectiveOwnerID(userID)

	var ctxLine string
	if ownerID == userID {
		ctxLine = "👤 <b>Personal</b>"
	} else {
		ctxLine = escapeHTML(grantorLabel(ownerID))
	}

	return "╭─❰ 🏠 ᴍᴀɪɴ ᴍᴇɴᴜ ❱\n│\n" +
		"│  <b>Context:</b>  " + ctxLine + "\n│\n" +
		"╰─❰ ✨ Keyboard updated ❱"
}

// noClientsMsg returns the appropriate "no clients" message depending on
// whether the user is in personal or delegated context.
func noClientsMsg(userID int64) string {
	ownerID := effectiveOwnerID(userID)
	if ownerID == userID {
		return "╭─❰ ❌ ɴᴏ ᴄʟɪᴇɴᴛꜱ ❱\n│\n" +
			"│  Add a client before continuing.\n│\n" +
			"╰─❰ ➕ Tap Add Client first ❱"
	}
	return "╭─❰ ❌ ɴᴏ ᴄʟɪᴇɴᴛꜱ ❱\n│\n" +
		"│  No clients found for:\n" +
		"│  " + escapeHTML(grantorLabel(ownerID)) + "\n│\n" +
		"╰─❰ — ❱"
}
