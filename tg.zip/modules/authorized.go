package modules

import (
	"fmt"
	"strings"
	"sync"
	"time"

	"tgmultibot/config"
	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

const (
	BtnAccess       = "🔑 Access"
	BtnGetToken     = "🎟 Get Access Token"
	BtnEnterToken   = "📥 Enter Access Token"
	BtnMyDelegates  = "👥 Who's Using My Token"
	BtnBackToAccess = "🔙 Back to Access"

	btnRequestAccessInline = "📨 Request Bot Access"
)

var accessPanelKB = telegram.NewKeyboard().AddRow(
	styledText(BtnGetToken),
).AddRow(
	styledText(BtnEnterToken),
).AddRow(
	styledText(BtnMyDelegates),
).AddRow(
	styledText(BtnBackToMenu),
).BuildReply(ropts)

func isAuthorizedOrOwner(userID int64) bool {
	if config.Owner != nil && userID == config.Owner.ID {
		return true
	}
	ok, err := database.IsAuthorized(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("isAuthorizedOrOwner: IsAuthorized(%d): %v", userID, err))
		return false
	}
	return ok
}

func isDelegateOnly(userID int64) bool {
	if config.Owner != nil && userID == config.Owner.ID {
		return false
	}
	authed, err := database.ListAuthorizedUsers()
	if err == nil && contains64(authed, userID) {
		return false
	}
	return database.IsDelegate(userID)
}

func contains64(s []int64, v int64) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}

func isUnauthorizedAccessRequestCallback(data string) bool {
	return strings.HasPrefix(data, "accreq:send:")
}

var (
	unauthPromptMu   sync.Mutex
	unauthPromptLast = map[int64]time.Time{}
)

func sendUnauthorizedPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()

	// Rate limit: at most one prompt per user per minute (anti-spam).
	unauthPromptMu.Lock()
	if t, ok := unauthPromptLast[userID]; ok && time.Since(t) < time.Minute {
		unauthPromptMu.Unlock()
		return telegram.ErrEndGroup
	}
	unauthPromptLast[userID] = time.Now()
	unauthPromptMu.Unlock()
	kb := telegram.NewKeyboard()
	kb.AddRow(dataBtn(btnRequestAccessInline, fmt.Sprintf("accreq:send:%d", userID)))

	_, _ = m.Reply(
		"╭─❰ 🚫 ᴀᴄᴄᴇꜱꜱ ᴅᴇɴɪᴇᴅ ❱\n│\n"+
			"│  You are not authorized to use this bot.\n│\n"+
			"│  Tap the button below to send a request\n"+
			"│  for approval to the bot owner.\n│\n"+
			"╰─❰ 🔑 Request access below ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()},
	)
	return telegram.ErrEndGroup
}
