package modules

import (
	"bytes"
	"context"
	"fmt"
	"regexp"
	"strings"
	"sync"
	"time"

	"tgmultibot/config"
	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

var htmlSend = &telegram.SendOptions{ParseMode: telegram.HTML}

func accessPanelOpts() *telegram.SendOptions {
	return &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: accessPanelKB}
}

func regenKeyboard() *telegram.KeyboardBuilder {
	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Data("🔄 Regenerate Token", "actok:regenask"))
	return kb
}

var accessTokenFormatRE = regexp.MustCompile(`^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$`)

func normalizeAccessToken(raw string) (string, bool) {
	token := strings.ToUpper(strings.TrimSpace(raw))
	return token, accessTokenFormatRE.MatchString(token)
}

var accessBackKB = telegram.NewKeyboard().AddRow(
	telegram.Button.Text(BtnBackToAccess),
).BuildReply(ropts)

type pendingAccessRequest struct {
	kind string
	at   time.Time
}

var (
	pendingAccessMu       sync.Mutex
	pendingAccessRequests = map[int64]pendingAccessRequest{}
)

func rememberPendingAccessRequest(userID int64, pending pendingAccessRequest) bool {
	pendingAccessMu.Lock()
	defer pendingAccessMu.Unlock()
	// A request older than 24h is considered abandoned and may be replaced.
	if p, exists := pendingAccessRequests[userID]; exists && time.Since(p.at) < 24*time.Hour {
		return false
	}
	pending.at = time.Now()
	pendingAccessRequests[userID] = pending
	return true
}

func clearPendingAccessRequest(userID int64) {
	pendingAccessMu.Lock()
	delete(pendingAccessRequests, userID)
	pendingAccessMu.Unlock()
}

type pendingRejection struct {
	targetUserID int64
	grantorID    int64
}

var (
	rejectMu      sync.Mutex
	pendingReject = map[int64]pendingRejection{}
)

func handleAccessPrompt(m *telegram.NewMessage) error {
	_, err := m.Reply(
		"╭─❰ 🔑 𝗔𝗖𝗖𝗘𝗦𝗦 𝗣𝗔𝗡𝗘𝗟 ❱\n│\n"+
			"│  🎟  <b>Get Access Token</b>\n"+
			"│      View your permanent token\n│\n"+
			"│  📥  <b>Enter Access Token</b>\n"+
			"│      Claim access using a token\n│\n"+
			"│  👥  <b>Who's Using My Token</b>\n"+
			"│      Manage delegated access\n│\n"+
			"╰─❰ ✨ Choose an option below ❱",
		accessPanelOpts(),
	)
	return err
}

func handleGetToken(m *telegram.NewMessage) error {
	userID := m.SenderID()

	token, err := database.GetOrCreateAccessToken(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("GetOrCreateAccessToken for user %d: %v", userID, err))
		_, err := m.Reply("❌ <b>Failed to fetch token, please try again.</b>", accessPanelOpts())
		return err
	}

	text := fmt.Sprintf(
		"╭─❰ 🎟 𝗬𝗢𝗨𝗥 𝗧𝗢𝗞𝗘𝗡 ❱\n│\n"+
			"│  <code>%s</code>\n│\n"+
			"╰─❰ ℹ️ Share to grant access ❱",
		token,
	) +
		"\n\nShare this with anyone you want to give access to. They can claim it via " +
		"<b>🔑 Access → 📥 Enter Access Token</b>.\n\n" +
		"⚠️ This token is <b>permanent</b> and <b>multi-use</b> — anyone with it can request " +
		"delegated access to your clients. You approve or reject each request individually.\n\n" +
		"Use <b>🔄 Regenerate Token</b> to invalidate the current one."

	_, err = m.Reply(text, &telegram.SendOptions{
		ParseMode:   telegram.HTML,
		ReplyMarkup: regenKeyboard().Build(),
	})
	return err
}

func handleMyDelegates(m *telegram.NewMessage) error {
	userID := m.SenderID()
	delegates, err := database.ListDelegates(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("ListDelegates for user %d: %v", userID, err))
		_, err := m.Reply("❌ <b>Failed to load delegates, please try again.</b>", accessPanelOpts())
		return err
	}

	text, kb := buildDelegateListPage(delegates)
	_, err = m.Reply(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
	return err
}

func buildDelegateListPage(delegates []int64) (string, *telegram.KeyboardBuilder) {
	kb := telegram.NewKeyboard()

	if len(delegates) == 0 {
		kb.AddRow(telegram.Button.Data("— nobody yet —", "actok:noop"))
		return "╭─❰ 👥 𝗨𝗦𝗜𝗡𝗚 𝗬𝗢𝗨𝗥 𝗧𝗢𝗞𝗘𝗡 ❱\n│\n" +
			"│  Nobody is currently using your accounts\n" +
			"│  via your access token.\n│\n" +
			"╰─❰ 💤 All clear ❱", kb
	}

	var body strings.Builder
	body.WriteString("╭─❰ 👥 𝗨𝗦𝗜𝗡𝗚 𝗬𝗢𝗨𝗥 𝗧𝗢𝗞𝗘𝗡 ❱\n│\n")
	body.WriteString(fmt.Sprintf("│  <b>%d</b> delegate(s) with access:\n", len(delegates)))
	for i, d := range delegates {
		body.WriteString(fmt.Sprintf("│\n│  %d.  <code>%d</code>\n", i+1, d))
		kb.AddRow(telegram.Button.Data(
			fmt.Sprintf("⛔ Terminate #%d", i+1),
			fmt.Sprintf("actok:termask:%d", d),
		))
	}
	body.WriteString("│\n╰─❰ ⚡ Manage below ❱")
	return body.String(), kb
}

func handleEnterTokenPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()

	ctx, ok := guardProcessWithKeyboard(
		m,
		"Enter Access Token",
		telegram.NewKeyboard().AddRow(telegram.Button.Text(BtnBackToAccess)),
	)
	if !ok {
		return nil
	}
	cg.SetListening(userID)

	_, err := m.Reply(
		"╭─❰ 📥 𝗘𝗡𝗧𝗘𝗥 𝗧𝗢𝗞𝗘𝗡 ❱\n│\n"+
			"│  Send the access token you were given.\n│\n"+
			"│  <i>Send /cancel to abort.</i>\n│\n"+
			"╰─❰ ⌨️ Awaiting your token ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: accessBackKB},
	)
	if err != nil {
		ps.done(userID)
		return err
	}

	go enterTokenStep(ctx, userID)
	return nil
}

func enterTokenStep(ctx context.Context, userID int64) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in enterTokenStep: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil {
			c.SendMessage(userID,
				"⏰ <b>Timed out.</b> Tap <b>📥 Enter Access Token</b> to try again.",
				accessPanelOpts(),
			)
		}
		return
	}
	if ctx.Err() != nil {
		return
	}
	if strings.TrimSpace(msgs[0].Text()) == BtnBackToAccess {
		c.SendMessage(userID,
			"╭─❰ 🔑 𝗔𝗖𝗖𝗘𝗦𝗦 𝗣𝗔𝗡𝗘𝗟 ❱\n│\n"+
				"│  Back to the access panel.\n│\n"+
				"╰─❰ ✨ Pick an option ❱",
			accessPanelOpts(),
		)
		return
	}

	token, valid := normalizeAccessToken(msgs[0].Text())
	if !valid {
		c.SendMessage(userID,
			"❌ <b>Invalid token format.</b>\n\nTokens must look like <code>ABCD-EFGH-IJKL-MNOP</code>.",
			accessPanelOpts(),
		)
		return
	}

	grantorID, found, err := database.FindAccessTokenOwner(token)
	if err != nil {
		sendTraceback(fmt.Sprintf("FindAccessTokenOwner for user %d: %v", userID, err))
		c.SendMessage(userID, "❌ <b>Something went wrong, please try again.</b>", accessPanelOpts())
		return
	}
	if !found {
		c.SendMessage(userID, "❌ <b>Invalid token.</b>", accessPanelOpts())
		return
	}
	if grantorID == userID {
		c.SendMessage(userID, "❌ <b>You can't claim your own token.</b>", accessPanelOpts())
		return
	}
	if !rememberPendingAccessRequest(userID, pendingAccessRequest{kind: "token"}) {
		c.SendMessage(userID,
			"⏳ <b>You already have a pending access request.</b>\n\nPlease wait for it to be approved or rejected.",
			accessPanelOpts(),
		)
		return
	}

	c.SendMessage(userID,
		"╭─❰ 📤 𝗥𝗘𝗤𝗨𝗘𝗦𝗧 𝗦𝗘𝗡𝗧 ❱\n│\n"+
			"│  Waiting for the token owner to approve\n"+
			"│  your access request.\n│\n"+
			"╰─❰ 🔔 You'll be notified here ❱",
		accessPanelOpts(),
	)

	sendApprovalCard(
		grantorID,
		userID,
		"🎟 𝗔𝗖𝗖𝗘𝗦𝗦 𝗥𝗘𝗤𝗨𝗘𝗦𝗧",
		fmt.Sprintf("accreq:token:%d:%d", grantorID, userID),
	)
}

func sendApprovalCard(recipientID, targetUserID int64, title, approveDataPrefix string) {
	info, photo := fetchUserCard(targetUserID, title)

	kb := telegram.NewKeyboard()
	kb.AddRow(
		telegram.Button.Data("✅ Accept", approveDataPrefix+":accept"),
		telegram.Button.Data("❌ Reject", approveDataPrefix+":reject"),
	)

	if len(photo) > 0 {
		if _, err := c.SendMedia(recipientID, photo, &telegram.MediaOptions{
			Caption:     info,
			ParseMode:   telegram.HTML,
			ReplyMarkup: kb.Build(),
			FileName:    fmt.Sprintf("profile_%d.jpg", targetUserID),
		}); err == nil {
			return
		} else {
			sendTraceback(fmt.Sprintf("sendApprovalCard photo send failed for %d: %v", targetUserID, err))
		}
	}

	c.SendMessage(recipientID, info, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()})
}

func fetchUserCard(userID int64, title string) (caption string, photoBytes []byte) {
	user, err := c.GetUser(userID)

	name := fmt.Sprintf("ID %d", userID)
	username := "—"

	if err == nil && user != nil {
		full := strings.TrimSpace(user.FirstName + " " + user.LastName)
		if full != "" {
			name = full
		}
		if user.Username != "" {
			username = "@" + user.Username
		}
	}

	caption = fmt.Sprintf(
		"╭─❰ %s ❱\n│\n"+
			"│  👤  <b>Name</b>      ›  %s\n"+
			"│  📛  <b>Username</b>  ›  %s\n"+
			"│  🆔  <b>ID</b>        ›  <code>%d</code>\n"+
			"│\n"+
			"╰─❰ ⚡ Approve or reject below ❱",
		title, escapeHTML(name), escapeHTML(username), userID,
	)

	photos, perr := c.GetProfilePhotos(userID, &telegram.PhotosOptions{Limit: 1})
	if perr != nil || len(photos) == 0 {
		return caption, nil
	}

	var buf bytes.Buffer
	if _, derr := c.DownloadMedia(&photos[0], &telegram.DownloadOptions{Buffer: &buf}); derr == nil {
		photoBytes = buf.Bytes()
	}

	return caption, photoBytes
}

func handleAccessCallback(cb *telegram.CallbackQuery) error {
	data := cb.DataString()
	reviewerID := cb.GetSenderID()

	switch {
	case strings.HasPrefix(data, "accreq:send:"):
		return handleSendAccessRequest(cb, data)

	case strings.HasPrefix(data, "accreq:direct:") && strings.HasSuffix(data, ":accept"):
		return handleDirectAccept(cb, data)

	case strings.HasPrefix(data, "accreq:direct:") && strings.HasSuffix(data, ":reject"):
		return handleDirectRejectAsk(cb, data, reviewerID)

	case strings.HasPrefix(data, "accreq:token:") && strings.HasSuffix(data, ":accept"):
		return handleTokenAccept(cb, data)

	case strings.HasPrefix(data, "accreq:token:") && strings.HasSuffix(data, ":reject"):
		return handleTokenRejectAsk(cb, data, reviewerID)

	case data == "actok:regenask":
		return handleRegenAsk(cb)
	case data == "actok:regen":
		return handleRegenConfirm(cb)
	case data == "actok:regencancel":
		return handleRegenCancel(cb)

	case strings.HasPrefix(data, "actok:termask:"):
		return handleTerminateAsk(cb, data)
	case strings.HasPrefix(data, "actok:term:"):
		return handleTerminateConfirm(cb, data)
	case strings.HasPrefix(data, "actok:termcancel"):
		return handleTerminateCancel(cb)

	case data == "actok:noop":
		_, err := cb.Answer("")
		return err
	}
	return nil
}

func handleRegenAsk(cb *telegram.CallbackQuery) error {
	kb := telegram.NewKeyboard()
	kb.AddRow(
		telegram.Button.Data("✅ Yes, regenerate", "actok:regen"),
		telegram.Button.Data("❌ No", "actok:regencancel"),
	)
	_, err := cb.Edit(
		"╭─❰ ⚠️ 𝗥𝗘𝗚𝗘𝗡𝗘𝗥𝗔𝗧𝗘 𝗧𝗢𝗞𝗘𝗡 ❱\n│\n"+
			"│  Your current token will be <b>invalidated</b>.\n"+
			"│  Anyone who had it will need the new token\n"+
			"│  to request access again.\n│\n"+
			"│  <i>Existing delegates are unaffected.</i>\n│\n"+
			"╰─❰ ❓ Are you sure? ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()},
	)
	return err
}

func handleRegenConfirm(cb *telegram.CallbackQuery) error {
	userID := cb.GetSenderID()

	token, err := database.RegenerateAccessToken(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("RegenerateAccessToken for user %d: %v", userID, err))
		_, err := cb.Answer("Failed to regenerate token, please try again.", &telegram.CallbackOptions{Alert: true})
		return err
	}

	text := fmt.Sprintf(
		"╭─❰ ✅ 𝗧𝗢𝗞𝗘𝗡 𝗥𝗘𝗚𝗘𝗡𝗘𝗥𝗔𝗧𝗘𝗗 ❱\n│\n"+
			"│  <code>%s</code>\n│\n"+
			"╰─❰ ℹ️ Share to grant access ❱",
		token,
	) +
		"\n\nYour old token is now invalid. Share this new one with anyone you want to give access to."

	if _, err := cb.Edit(text, &telegram.SendOptions{
		ParseMode:   telegram.HTML,
		ReplyMarkup: regenKeyboard().Build(),
	}); err != nil {
		return err
	}
	_, err = cb.Answer("Regenerated.")
	return err
}

func handleRegenCancel(cb *telegram.CallbackQuery) error {
	userID := cb.GetSenderID()
	token, err := database.GetOrCreateAccessToken(userID)
	if err != nil {
		_, err := cb.Answer("Failed to load token.", &telegram.CallbackOptions{Alert: true})
		return err
	}

	text := fmt.Sprintf(
		"╭─❰ 🎟 𝗬𝗢𝗨𝗥 𝗧𝗢𝗞𝗘𝗡 ❱\n│\n"+
			"│  <code>%s</code>\n│\n"+
			"╰─❰ ℹ️ Share to grant access ❱",
		token,
	) + "\n\nShare this with anyone you want to give access to."

	if _, err := cb.Edit(text, &telegram.SendOptions{
		ParseMode:   telegram.HTML,
		ReplyMarkup: regenKeyboard().Build(),
	}); err != nil {
		return err
	}
	_, err = cb.Answer("Cancelled.")
	return err
}

func handleTerminateCancel(cb *telegram.CallbackQuery) error {
	userID := cb.GetSenderID()
	delegates, err := database.ListDelegates(userID)
	if err != nil {
		sendTraceback(fmt.Sprintf("ListDelegates for user %d: %v", userID, err))
		_, err := cb.Answer("Failed to load delegates, please try again.", &telegram.CallbackOptions{Alert: true})
		return err
	}
	text, kb := buildDelegateListPage(delegates)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}
	_, err = cb.Answer("Cancelled.")
	return err
}

func handleTerminateAsk(cb *telegram.CallbackQuery, data string) error {
	var delegateID int64
	fmt.Sscanf(strings.TrimPrefix(data, "actok:termask:"), "%d", &delegateID)

	kb := telegram.NewKeyboard()
	kb.AddRow(
		telegram.Button.Data("✅ Yes, terminate", fmt.Sprintf("actok:term:%d", delegateID)),
		telegram.Button.Data("❌ No", "actok:termcancel"),
	)
	_, err := cb.Edit(
		fmt.Sprintf(
			"╭─❰ ⚠️ 𝗧𝗘𝗥𝗠𝗜𝗡𝗔𝗧𝗘 𝗔𝗖𝗖𝗘𝗦𝗦 ❱\n│\n"+
				"│  Remove access for <code>%d</code>?\n│\n"+
				"│  They will immediately lose access\n"+
				"│  to your accounts.\n│\n"+
				"╰─❰ ❓ Are you sure? ❱",
			delegateID,
		),
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()},
	)
	return err
}

func handleTerminateConfirm(cb *telegram.CallbackQuery, data string) error {
	var delegateID int64
	fmt.Sscanf(strings.TrimPrefix(data, "actok:term:"), "%d", &delegateID)
	grantorID := cb.GetSenderID()

	if err := database.RemoveDelegate(grantorID, delegateID); err != nil {
		sendTraceback(fmt.Sprintf("RemoveDelegate(%d,%d): %v", grantorID, delegateID, err))
	} else {
		clearUserCtx(delegateID)
	}
	c.SendMessage(delegateID,
		"⛔ <b>Your access to that account's clients has been terminated by the owner.</b>",
		htmlSend,
	)

	delegates, _ := database.ListDelegates(grantorID)
	text, kb := buildDelegateListPage(delegates)
	if _, err := cb.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.Build()}); err != nil {
		return err
	}
	_, err := cb.Answer("Terminated.")
	return err
}

func handleSendAccessRequest(cb *telegram.CallbackQuery, data string) error {
	var requesterID int64
	fmt.Sscanf(strings.TrimPrefix(data, "accreq:send:"), "%d", &requesterID)
	if requesterID == 0 {
		_, err := cb.Answer("Invalid request.")
		return err
	}
	if cb.GetSenderID() != requesterID {
		_, err := cb.Answer("This request button belongs to another user.", &telegram.CallbackOptions{Alert: true})
		return err
	}
	if isAuthorizedOrOwner(requesterID) {
		_, err := cb.Answer("You're already authorized — send /start.")
		return err
	}
	if config.Owner == nil {
		_, err := cb.Answer("Owner not configured yet, try again later.", &telegram.CallbackOptions{Alert: true})
		return err
	}
	if !rememberPendingAccessRequest(requesterID, pendingAccessRequest{kind: "bot"}) {
		_, err := cb.Answer("You already have a pending access request.", &telegram.CallbackOptions{Alert: true})
		return err
	}

	sendApprovalCard(
		config.Owner.ID,
		requesterID,
		"🔐 𝗕𝗢𝗧 𝗔𝗨𝗧𝗛𝗢𝗥𝗜𝗭𝗔𝗧𝗜𝗢𝗡",
		fmt.Sprintf("accreq:direct:%d", requesterID),
	)

	if _, err := cb.Edit(
		"╭─❰ 📤 𝗥𝗘𝗤𝗨𝗘𝗦𝗧 𝗦𝗘𝗡𝗧 ❱\n│\n"+
			"│  Waiting for the bot owner to approve you.\n│\n"+
			"╰─❰ 🔔 You'll be notified here ❱",
		htmlSend,
	); err != nil {
		clearPendingAccessRequest(requesterID)
		return err
	}
	_, err := cb.Answer("Request sent.")
	return err
}

func handleDirectAccept(cb *telegram.CallbackQuery, data string) error {
	rest := strings.TrimSuffix(strings.TrimPrefix(data, "accreq:direct:"), ":accept")
	var targetUserID int64
	fmt.Sscanf(rest, "%d", &targetUserID)
	if targetUserID == 0 {
		_, err := cb.Answer("Invalid request.")
		return err
	}
	if config.Owner == nil || cb.GetSenderID() != config.Owner.ID {
		_, err := cb.Answer("Only the bot owner can approve this.", &telegram.CallbackOptions{Alert: true})
		return err
	}

	if err := database.AddAuthorizedUser(targetUserID); err != nil {
		sendTraceback(fmt.Sprintf("AddAuthorizedUser(%d): %v", targetUserID, err))
		_, err := cb.Answer("Failed to approve, try again.")
		return err
	}

	finalizeApprovalCard(cb, true, "")
	notifyApprovalResult(targetUserID, true, "")
	clearPendingAccessRequest(targetUserID)
	_, err := cb.Answer("Approved.")
	return err
}

func handleDirectRejectAsk(cb *telegram.CallbackQuery, data string, reviewerID int64) error {
	rest := strings.TrimSuffix(strings.TrimPrefix(data, "accreq:direct:"), ":reject")
	var targetUserID int64
	fmt.Sscanf(rest, "%d", &targetUserID)
	if targetUserID == 0 {
		_, err := cb.Answer("Invalid request.")
		return err
	}
	if config.Owner == nil || cb.GetSenderID() != config.Owner.ID {
		_, err := cb.Answer("Only the bot owner can reject this.", &telegram.CallbackOptions{Alert: true})
		return err
	}
	return beginRejectFlow(cb, reviewerID, pendingRejection{targetUserID: targetUserID})
}

func handleTokenAccept(cb *telegram.CallbackQuery, data string) error {
	grantorID, targetUserID, ok := parseTokenCallback(data, ":accept")
	if !ok {
		_, err := cb.Answer("Invalid request.")
		return err
	}
	if cb.GetSenderID() != grantorID {
		_, err := cb.Answer("Only the token owner can approve this.", &telegram.CallbackOptions{Alert: true})
		return err
	}

	if err := database.AddDelegate(grantorID, targetUserID); err != nil {
		sendTraceback(fmt.Sprintf("AddDelegate(%d,%d): %v", grantorID, targetUserID, err))
		_, err := cb.Answer("Failed to approve, try again.")
		return err
	}

	finalizeApprovalCard(cb, true, "")
	notifyApprovalResult(targetUserID, true, "")
	clearPendingAccessRequest(targetUserID)
	_, err := cb.Answer("Approved.")
	return err
}

func handleTokenRejectAsk(cb *telegram.CallbackQuery, data string, reviewerID int64) error {
	grantorID, targetUserID, ok := parseTokenCallback(data, ":reject")
	if !ok {
		_, err := cb.Answer("Invalid request.")
		return err
	}
	if cb.GetSenderID() != grantorID {
		_, err := cb.Answer("Only the token owner can reject this.", &telegram.CallbackOptions{Alert: true})
		return err
	}
	return beginRejectFlow(cb, reviewerID, pendingRejection{targetUserID: targetUserID, grantorID: grantorID})
}

func beginRejectFlow(cb *telegram.CallbackQuery, reviewerID int64, pend pendingRejection) error {
	if !askForRejectionReason(reviewerID, pend) {
		// Reviewer is busy in another conversation: reject right away
		// without a reason instead of hijacking that conversation.
		finalizeApprovalCard(cb, false, "")
		_, err := cb.Answer("Rejected.")
		return err
	}
	if _, err := cb.Edit(
		"╭─❰ ❓ 𝗥𝗘𝗝𝗘𝗖𝗧𝗜𝗢𝗡 𝗥𝗘𝗔𝗦𝗢𝗡 ❱\n│\n"+
			"│  Reply with a reason for rejecting this request.\n"+
			"│  Send <code>-</code> for no reason.\n│\n"+
			"╰─❰ ✍️ Awaiting your reply ❱",
		htmlSend,
	); err != nil {
		return err
	}
	_, err := cb.Answer("")
	return err
}

func parseTokenCallback(data, suffix string) (grantorID, targetUserID int64, ok bool) {
	rest := strings.TrimSuffix(strings.TrimPrefix(data, "accreq:token:"), suffix)
	parts := strings.SplitN(rest, ":", 2)
	if len(parts) != 2 {
		return 0, 0, false
	}
	if _, err := fmt.Sscanf(parts[0], "%d", &grantorID); err != nil {
		return 0, 0, false
	}
	if _, err := fmt.Sscanf(parts[1], "%d", &targetUserID); err != nil {
		return 0, 0, false
	}
	return grantorID, targetUserID, grantorID != 0 && targetUserID != 0
}

func finalizeApprovalCard(cb *telegram.CallbackQuery, accepted bool, reason string) {
	var verdict string
	if accepted {
		verdict = "╭─❰ ✅ 𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗 ❱\n│\n" +
			"│  Access has been granted.\n│\n" +
			"╰─❰ ✨ All set ❱"
	} else {
		verdict = "╭─❰ ❌ 𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗 ❱\n│\n" +
			"│  This request has been declined."
		if reason != "" {
			verdict += fmt.Sprintf("\n│\n│  <b>Reason:</b> %s", escapeHTML(reason))
		}
		verdict += "\n│\n╰─❰ — ❱"
	}
	if _, err := cb.Edit(verdict, htmlSend); err != nil {
		sendTraceback(fmt.Sprintf("finalizeApprovalCard edit failed: %v", err))
	}
}

func notifyApprovalResult(targetUserID int64, accepted bool, reason string) {
	if accepted {
		c.SendMessage(targetUserID,
			"╭─❰ ✅ 𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗 ❱\n│\n"+
				"│  Your access request has been approved!\n│\n"+
				"│  Send /start to begin.\n│\n"+
				"╰─❰ 🎉 Welcome aboard ❱",
			htmlSend,
		)
		return
	}
	text := "╭─❰ ❌ 𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗 ❱\n│\n" +
		"│  Your access request was rejected."
	if reason != "" {
		text += fmt.Sprintf("\n│\n│  <b>Reason:</b> %s", escapeHTML(reason))
	}
	text += "\n│\n╰─❰ — ❱"
	c.SendMessage(targetUserID, text, htmlSend)
}

func askForRejectionReason(reviewerID int64, p pendingRejection) bool {
	if cg.IsListening(reviewerID) {
		notifyApprovalResult(p.targetUserID, false, "")
		clearPendingAccessRequest(p.targetUserID)
		return false
	}
	rejectMu.Lock()
	pendingReject[reviewerID] = p
	rejectMu.Unlock()

	cg.SetListening(reviewerID)
	go func() {
		defer cg.StopListening(reviewerID)

		msgs, ok := cg.Recv(reviewerID, 5*time.Minute)
		rejectMu.Lock()
		pend, stillPending := pendingReject[reviewerID]
		delete(pendingReject, reviewerID)
		rejectMu.Unlock()

		if !stillPending {
			return
		}

		reason := ""
		if ok && len(msgs) > 0 {
			reason = strings.TrimSpace(msgs[0].Text())
			if reason == "-" {
				reason = ""
			}
		}

		notifyApprovalResult(pend.targetUserID, false, reason)
		clearPendingAccessRequest(pend.targetUserID)
		c.SendMessage(reviewerID,
			"╭─❰ ❌ 𝗥𝗘𝗝𝗘𝗖𝗧𝗜𝗢𝗡 𝗦𝗘𝗡𝗧 ❱\n│\n"+
				"│  The requester has been notified.\n│\n"+
				"╰─❰ — ❱",
			htmlSend,
		)
	}()
	return true
}