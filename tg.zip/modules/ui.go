package modules

import (
	"fmt"
	"strings"
	"sync"
	"time"

	"tgmultibot/utils"

	"github.com/amarnathcjd/gogram/telegram"
)

// ── Animated progress bar ───────────────────────────────────────────────────
// "▰▰▰▱▱▱ 30% ⠹ · 3/10" rendered in the bot's panel box, with a rotating
// braille spinner. Flood-safe: the message is edited at most once every
// ~1.2 s (Telegram limits message edits); the FINAL text is always rendered
// exactly once, no matter how many steps were skipped.

const (
	uiBarWidth   = 10
	uiSpinner    = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
	uiMinEditGap = 1200 * time.Millisecond
)

type uiProgress struct {
	mu       sync.Mutex
	userID   int64
	msg      *telegram.NewMessage
	total    int
	done     int
	label    string
	spinnerN int
	lastEdit time.Time
}

// newUIProgress sends the initial "0%" frame. Returns nil-safe object —
// every method tolerates a nil receiver or a failed initial send.
func newUIProgress(userID int64, label string, total int) *uiProgress {
	p := &uiProgress{userID: userID, total: total, label: label}
	msg, err := c.SendMessage(userID, p.render(), &telegram.SendOptions{ParseMode: telegram.HTML})
	if err == nil {
		p.msg = msg
		p.lastEdit = time.Now()
	}
	return p
}

// SetDone reports absolute progress (done items finished).
func (p *uiProgress) SetDone(done int) {
	if p == nil {
		return
	}
	p.mu.Lock()
	p.done = done
	p.spinnerN++
	due := time.Since(p.lastEdit) >= uiMinEditGap
	p.mu.Unlock()
	if due {
		p.editFrame()
	}
}

// Step bumps the progress by one item.
func (p *uiProgress) Step() {
	if p == nil {
		return
	}
	p.mu.Lock()
	done := p.done + 1
	p.mu.Unlock()
	p.SetDone(done)
}

// Finish always renders finalText (the completion banner), regardless of the
// edit throttle. Falls back to a fresh message if the progress one is gone.
func (p *uiProgress) Finish(finalText string, opts ...*telegram.SendOptions) {
	if p == nil {
		return
	}
	sendOpts := &telegram.SendOptions{ParseMode: telegram.HTML}
	if len(opts) > 0 && opts[0] != nil {
		sendOpts = opts[0]
	}
	p.mu.Lock()
	msg := p.msg
	p.mu.Unlock()

	if msg != nil {
		if _, err := msg.Edit(finalText, sendOpts); err == nil {
			return
		}
	}
	c.SendMessage(p.userID, finalText, sendOpts)
}

func (p *uiProgress) editFrame() {
	p.mu.Lock()
	text := p.render()
	msg := p.msg
	p.lastEdit = time.Now()
	p.mu.Unlock()
	if msg != nil {
		_, _ = msg.Edit(text, &telegram.SendOptions{ParseMode: telegram.HTML})
	}
}

func (p *uiProgress) render() string {
	pct, filled := 0, 0
	if p.total > 0 {
		pct = p.done * 100 / p.total
		filled = p.done * uiBarWidth / p.total
		if filled > uiBarWidth {
			filled = uiBarWidth
		}
	}
	sp := []rune(uiSpinner)[p.spinnerN%len(uiSpinner)]
	bar := strings.Repeat("▰", filled) + strings.Repeat("▱", uiBarWidth-filled)
	return fmt.Sprintf(
		"╭─❰ ⏳ %s ❱\n│\n"+
			"│  %s  %d%% %c\n"+
			"│  ⚙️  %d / %d done\n│\n"+
			"╰─❰ — ❱",
		p.label, bar, pct, sp, p.done, p.total,
	)
}

// uiLabel converts a plain English label into the UI's small-caps style.
func uiLabel(s string) string { return utils.SmallCaps(s) }

// busyMsg ek hi jagah ka "process running" box (pehle 5 jagah copy-paste tha).
func busyMsg(active string) string {
	return "╭─❰ ⚙️ ᴘʀᴏᴄᴇꜱꜱ ʀᴜɴɴɪɴɢ ❱\n│\n" +
		"│  Currently active:  <code>" + escapeHTML(active) + "</code>\n│\n" +
		"│  Send /cancel to stop it first.\n│\n" +
		"╰─❰ 🚫 /cancel to stop ❱"
}
