# What was fixed
Secrets/config: no hardcoded token/API hash/owner (env only), .env files removed,
ENC_KEY from env (legacy key only for decrypting old data), .env.example added.
Security: delegation re-validated on every action + cleared on terminate; delegates
cannot add clients, phones hidden; unauthorized prompt rate-limited; mandatory
channel join is opt-in; OTP/2FA messages deleted; zip-bomb/size limits; HTML escaping.
Bugs: conversation channel race; client-slice data race; auto-react/view scoped to the
real owner + chat-id normalised + skips own messages + jitter; leave/stop/end now stops
the auto-rejoin monitor (no more rejoin loops), stale calls closed, Stop() outside lock;
flood-wait respects cancel; reject flow no longer hijacks other conversations; pending
requests expire; OTP listener no longer uses an invalid inline reply keyboard; DB save
failure reported; startup connects max 8 at once with retry; graceful shutdown; reactions
no longer fetched via the bot; per-download media dir + 500MB cap + startup cleanup.
Build: Dockerfile runs install.sh and installs ffmpeg; .dockerignore fixed; app.json/README.
Misc: Mongo index on token, dead code removed, bio row removed, phone-login OTP retry.

# Review fixes (Nov 2026)
Build: project now compiles — removed 5 duplicate Btn* constants (handlers.go
redeclared authorized.go's with DIFFERENT values); button layer rewritten on
gogram's native .Success()/.Danger()/.Primary() helpers (old code used the
non-existent telegram.InlineKeyboardButton type + a reflection hack); main.go
startupMessage now takes *telegram.UserObj (GetMe's actual type); ntgcalls
callback user-data is the Go instance pointer instead of a uintptr round-trip
(go vet clean).
Config: ENC_KEY is enforced (32+ chars, fail fast) — previously the bot silently
encrypted sessions with the hard-coded legacy key when it was missing.
DB: empty Clients/Delegates/AuthorizedUsers arrays are now $unset — removing the
LAST client/delegate/approved-user used to silently keep the old array in
MongoDB, so removals resurrected after a restart.
Join: manager returns AlreadyMember/ChatID for USER_ALREADY_PARTICIPANT instead
of a nil-channel success; auto-react/view add no longer counts an
already-joined chat as FAILED (it saves the chat now).
Voice chat: validateVCPeer rejects InputPeerUser again (joining a user account
was possible because the guard returned the positive id); removing/disabling a
client now stops its voice-chat session (it used to keep streaming until the
file ended and leak its session entry); failed replays delete the parked media
file instead of leaking it; join/voice flows re-prompt up to 3 times like the
player does.
Player: control panel shows NOW PLAYING while streaming; error summaries are
inserted by the panel builder (no more brittle TrimSuffix footer surgery);
playback-end notification goes to the user who started that playback, not
always to the grantor; removeClientMe-failure removes the client so Added and
Total counts stay consistent.
Buttons: 🚫 Cancel and /start now cancel a running conversation (Cancel used
to be forwarded to the flow as input and burned an attempt); timeouts restore
the menu keyboard instead of clearing it; Terminate buttons carry the delegate
ID instead of a list index.
Misc: dead code removed (PlayMediaInVoiceChat, Player interface + Status,
ClearStoppedMedia, GetMongoDBStats, served-user read helpers + usersMap,
client getters, auto-chat Is* helpers, OnIncomingCall, GetVoiceChatManager);
unit tests for the pure parsers (resolveMsgLink/extractOTP/normalizeAccessToken);
CI now runs install.sh + go build + go vet + go test on every push (it was
format-only, which is how a non-compiling commit landed); NOTE: .env is NOT
included in this zip on purpose — copy .env.example and fill every value.

# Panel systems (Nov 2026) — reference-bot parity
New main-menu systems, all wired through the styled buttons:
📩 SMS Inbox — captures login codes/service messages arriving on connected
accounts (peer 777000), newest-first with masked phone, capped ring buffer.
📤 Export Zip — packs every stored account as a REAL Telethon-format
.session SQLite file (tgconv decode -> sqlite schema our own importer reads)
inside a zip and sends it as a document; temp file removed after upload.
📦 Import Zip — alias for the upload flow, which now ALSO accepts raw .txt
gogram string sessions (files and zip entries).
🤖 Auto Call — third auto-panel (DB list `acc`): when a group call goes
ACTIVE in a registered chat, all of the owner's clients auto-join the voice
chat via the existing JoinVoiceChat path; per (callID, owner) dedup, failed
joins retryable, scheduled calls skipped, call-end cleans markers.
⏱ Uptime / 🏓 Ping / 📊 Status / 👤 My Info — process uptime + goroutines +
memory, Telegram API RTT + Mongo health, per-user stats (clients, playing
chats, automation counts; owner also sees global pool + DB health), role/
delegation summary.
🧹 Clear My Auto — wipes the effective owner's react/view/call lists in one
tap and cleans the in-memory reverse indexes.
🔄 Restart Accounts — reconnects the owner's clients from stored sessions
(stops VC sessions first, gentle 2s pacing, per-account problem list).
Hooks: manager.SetOnClientAdded fires (outside the lock) for every attached
connection — inbox/auto-call handlers register once per client, including
startup-restored accounts. UserState gains acc; updateUserState $unset covers
it. Config: .env ships with PASTE_... placeholders — Load() treats them as
missing and prints a step-by-step setup guide (values are NOT in the zip;
paste your own token/URI and restart).

# UI refresh (Nov 2026) — small caps + animated progress
Style: the whole UI now uses Unicode small caps (ꜰʟᴀꜱʜ style) — startup banner
reads "ꜰʟᴀꜱʜ ɪꜱ ᴏɴʟɪɴᴇ", every panel/box title is converted from the old
bold-sans wordmarks (2124 chars swept across 19 files). utils.SmallCaps()
converts any string at runtime (letters only; digits/emoji pass through).
Progress: modules/ui.go adds an animated progress bar — ▰▱ bar + percentage +
rotating braille spinner (⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏), flood-safe (max one edit per 1.2 s,
final banner always rendered exactly once, falls back to a fresh message if
the progress one is gone). Wired into: session upload processing (per-file),
Export Zip (per-account), Restart Accounts (manager now reports (done,total)
via an optional onProgress callback — RestartOwnerClients signature changed).
