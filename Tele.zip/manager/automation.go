package manager

import (
	"context"
	"log"
	"math/rand"
	"time"

	"tgmultibot/database"
	"tgmultibot/utils"

	"github.com/amarnathcjd/gogram/telegram"
)

// autoReactKey identifies a single message being auto-reacted to, shared
// across every client's automationHandler call for that message.
type autoReactKey struct {
	chatID int64
	msgID  int32
}

var autoReactStates = utils.NewCache[autoReactKey, *reactionState](2 * time.Minute)

// chatIDVariants returns every id form a chat may be stored under
// (marked -100..., raw positive channel id).
func chatIDVariants(chatID int64) []int64 {
	ids := []int64{chatID}
	switch {
	case chatID < -1000000000000:
		ids = append(ids, -chatID-1000000000000)
	case chatID > 0:
		ids = append(ids, -1000000000000-chatID)
	}
	return ids
}

func intersects(a, b []int64) bool {
	for _, x := range a {
		for _, y := range b {
			if x == y {
				return true
			}
		}
	}
	return false
}

func (m *ClientManager) automationHandler(msg *telegram.NewMessage) error {
	if msg.Message != nil && msg.Message.Out {
		return nil // never react to / view our own outgoing messages
	}

	chatID := msg.ChatID()

	var reactOwners, viewOwners []int64
	for _, id := range chatIDVariants(chatID) {
		reactOwners = append(reactOwners, database.GetReactOwners(id)...)
		viewOwners = append(viewOwners, database.GetViewOwners(id)...)
	}
	if len(reactOwners) == 0 && len(viewOwners) == 0 {
		return nil
	}

	// Only act if one of the users who enabled this chat actually owns THIS
	// client (previously any user's client reacted for everybody).
	mine := m.ownersOfClient(msg.Client)
	reactEnabled := intersects(reactOwners, mine)
	viewEnabled := intersects(viewOwners, mine)
	if !reactEnabled && !viewEnabled {
		return nil
	}

	msgID := int32(msg.Message.ID)

	if reactEnabled {
		go func() {
			// Random 0-3s jitter so all accounts do not hit Telegram at the same instant.
			time.Sleep(time.Duration(rand.Intn(3000)) * time.Millisecond)

			reactions, err := m.GetAllowedReactions(msg.Client, chatID)
			if err != nil {
				log.Printf("auto-react skipped: chat=%d msg=%d err=%v", chatID, msgID, err)
				return
			}

			key := autoReactKey{chatID: chatID, msgID: msgID}
			state := autoReactStates.GetOrCreate(key, newReactionState)
			reaction := state.pick(reactions)

			err = msg.Client.SendReaction(msg.Peer, msgID, []any{reaction}, true)

			if isReactionsTooMany(err) {
				state.markTooMany()
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				if fallback, ok := state.pickFallback(ctx); ok {
					reaction = fallback
					err = msg.Client.SendReaction(msg.Peer, msgID, []any{reaction}, true)
				}
				cancel()
			}

			if err != nil {
				log.Printf("auto-react failed: chat=%d msg=%d reaction=%s err=%v", chatID, msgID, reaction, err)
				return
			}
			state.markUsed(reaction)
		}()
	}

	if viewEnabled {
		go func() {
			time.Sleep(time.Duration(rand.Intn(2000)) * time.Millisecond)
			if _, err := msg.Client.MessagesGetMessagesViews(msg.Peer, []int32{msgID}, true); err != nil {
				log.Printf("auto-view failed: chat=%d msg=%d err=%v", chatID, msgID, err)
			}
		}()
	}

	return nil
}
