package manager

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/amarnathcjd/gogram/telegram"
)

type JoinChannelResult struct {
	AccountID         int64
	Channel           *telegram.Channel // non-nil on a confirmed join (or when the chat was resolvable)
	ChatID            int64             // positive raw channel ID when known (Channel.ID)
	AlreadyMember     bool              // success without a channel object — account was already inside
	InviteRequestSent bool              // true on INVITE_REQUEST_SENT — request submitted, awaiting approval
	Error             error
}

func isJoinRequestSent(err error) bool {
	if err == nil {
		return false
	}
	return strings.Contains(strings.ToUpper(err.Error()), "INVITE_REQUEST_SENT")
}

// resolveChannel best-effort resolves a channel reference to *telegram.Channel.
// Used when JoinChannel reports success without returning the chat object
// (e.g. USER_ALREADY_PARTICIPANT on code paths that return nil, nil).
func resolveChannel(client *telegram.Client, channel any) *telegram.Channel {
	peer, err := client.ResolvePeer(channel)
	if err != nil {
		return nil
	}
	inPeer, ok := peer.(*telegram.InputPeerChannel)
	if !ok {
		return nil
	}
	resp, err := client.ChannelsGetChannels([]telegram.InputChannel{
		&telegram.InputChannelObj{ChannelID: inPeer.ChannelID, AccessHash: inPeer.AccessHash},
	})
	if err != nil {
		return nil
	}
	if chats, ok := resp.(*telegram.MessagesChatsObj); ok {
		for _, ch := range chats.Chats {
			if c, ok := ch.(*telegram.Channel); ok {
				return c
			}
		}
	}
	return nil
}

// joinChannelWithRetry attempts to join a channel, sleeping and retrying on FLOOD_WAIT.
func joinChannelWithRetry(ctx context.Context, client *telegram.Client, channel any) (*telegram.Channel, error) {
	const maxRetries = 3
	const maxWait = 120 // seconds: never sleep longer than this for one join
	for attempt := 1; attempt <= maxRetries; attempt++ {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		ch, err := client.JoinChannel(channel)
		if err == nil {
			return ch, nil
		}
		if strings.Contains(strings.ToUpper(err.Error()), "USER_ALREADY_PARTICIPANT") {
			return ch, nil // already a member counts as success
		}

		if wait := FloodWaitSeconds(err); wait > 0 {
			if wait > maxWait {
				return nil, fmt.Errorf("FLOOD_WAIT_%d too long, skipped: %w", wait, err)
			}
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(time.Duration(wait+1) * time.Second):
			}
			continue
		}

		return ch, err
	}
	return nil, fmt.Errorf("failed after %d retries (FLOOD_WAIT)", maxRetries)
}

func (m *ClientManager) JoinChannel(ctx context.Context, ownerID int64, channel any) []JoinChannelResult {
	m.mu.RLock()
	clients := append([]*ManagedClient(nil), m.clients[ownerID]...)
	m.mu.RUnlock()

	if len(clients) == 0 {
		return []JoinChannelResult{{Error: fmt.Errorf("no clients found for ownerID %d", ownerID)}}
	}

	results := make([]JoinChannelResult, len(clients))
	var wg sync.WaitGroup

	for i, mc := range clients {
		wg.Add(1)
		go func(idx int, mc *ManagedClient) {
			defer wg.Done()
			if ctx.Err() != nil {
				results[idx] = JoinChannelResult{AccountID: mc.AccountID, Error: ctx.Err()}
				return
			}
			ch, err := joinChannelWithRetry(ctx, mc.Client, channel)
			if isJoinRequestSent(err) {
				results[idx] = JoinChannelResult{AccountID: mc.AccountID, InviteRequestSent: true}
				return
			}
			if ShouldDisableClient(err) {
				m.DisableClient(mc.OwnerID, mc.AccountID, string(ClassifyError(err)))
			}
			// Success without a channel object (USER_ALREADY_PARTICIPANT or a
			// nil,nil gogram path) still counts as joined — but flows that
			// need the chat ID (auto-react/view saving) need it resolved.
			if err == nil && ch == nil {
				ch = resolveChannel(mc.Client, channel)
			}
			res := JoinChannelResult{AccountID: mc.AccountID, Channel: ch, Error: err}
			if ch != nil {
				res.ChatID = ch.ID
			} else if err == nil {
				res.AlreadyMember = true
			}
			results[idx] = res
		}(i, mc)
	}

	wg.Wait()
	return results
}
