package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"

	_ "github.com/joho/godotenv/autoload"

	"github.com/amarnathcjd/gogram/telegram"
)

// No secret has a default value any more. Everything comes from the
// environment (or a local .env that is never committed).
var (
	ApiID    = getEnvInt("API_ID", 0)
	ApiHash  = getEnv("API_HASH", "")
	Token    = getEnv("BOT_TOKEN", "")
	LoggerID = getEnvInt64("LOGGER_ID", -1004376999626)
	MongoURL = getEnv("MONGO_URL", "")
	DbName   = getEnv("DB_NAME", "xydbbrc")

	OwnerID = getEnvInt64("OWNER_ID", 0)
	Owner   *telegram.UserObj

	// MandatoryChannels is OPT-IN. Accounts are only auto-joined to these
	// chats when the operator explicitly lists them (comma separated).
	MandatoryChannels = splitCSV(getEnv("MANDATORY_CHANNELS", ""))
)

func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

func getEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func getEnvInt(key string, def int) int {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	return n
}

func getEnvInt64(key string, def int64) int64 {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	n, err := strconv.ParseInt(v, 10, 64)
	if err != nil {
		return def
	}
	return n
}

func Load() error {
	missing := []string{}
	// A value counts as "missing" when it is empty OR still carries the
	// PASTE_... placeholder from the .env that ships with the zip.
	unfilled := func(v string) bool {
		return v == "" || strings.Contains(v, "PASTE_")
	}
	if ApiID == 0 {
		missing = append(missing, "API_ID")
	}
	if unfilled(ApiHash) {
		missing = append(missing, "API_HASH")
	}
	if unfilled(Token) {
		missing = append(missing, "BOT_TOKEN")
	}
	if unfilled(MongoURL) {
		missing = append(missing, "MONGO_URL")
	}
	if OwnerID == 0 {
		missing = append(missing, "OWNER_ID")
	}
	if len(missing) > 0 {
		return fmt.Errorf(
			"missing/unfilled env vars: %v\n"+
				"\n  Setup (2 min):\n"+
				"  1. Open the .env file next to the bot\n"+
				"  2. API_ID + API_HASH  ->  my.telegram.org  (API development tools)\n"+
				"  3. BOT_TOKEN          ->  @BotFather\n"+
				"  4. MONGO_URL          ->  free MongoDB Atlas cluster URI\n"+
				"  5. OWNER_ID           ->  your numeric Telegram user id\n"+
				"  6. ENC_KEY            ->  run: openssl rand -hex 32\n"+
				"  7. Restart the bot", missing)
	}
	// ENC_KEY encrypts every session string and phone number stored in
	// MongoDB. Without it crypto.go silently falls back to the compromised
	// legacy key, so we fail fast instead of starting with weak encryption.
	// (Old records stay decryptable via the legacy path and are transparently
	// re-encrypted with the new key on their next save.)
	if s := os.Getenv("ENC_KEY"); len(s) < 32 {
		return fmt.Errorf(
			"ENC_KEY must be set to 32+ random characters (got %d) - it encrypts sessions/phones in MongoDB\n"+
				"  Generate one with: openssl rand -hex 32", len(s))
	}
	return nil
}

func ResolveOwner(client *telegram.Client) error {
	user, err := client.GetUser(OwnerID)
	if err != nil {
		return fmt.Errorf("failed to resolve owner (OWNER_ID=%d): %w", OwnerID, err)
	}
	if user == nil {
		return fmt.Errorf("failed to resolve owner (OWNER_ID=%d): user not found", OwnerID)
	}
	Owner = user
	return nil
}
