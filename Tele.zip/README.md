# Telegram Multi Bot

Go bot that manages many Telegram accounts: bulk reactions, joins, voice-chat
player, auto-react / auto-view, delegated access.

## Setup
1. `cp .env.example .env` and fill **every** value (no secret has a default any more).
2. Set `ENC_KEY` (32+ random chars) - it encrypts sessions/phones stored in MongoDB.
3. Local build: `bash install.sh` (downloads libntgcalls), then `go build`.
   Needs `ffmpeg` + `ffprobe` on PATH for the player.
4. Docker/Heroku: `Dockerfile` already runs `install.sh` and installs ffmpeg.

## Security notes
- Never commit `.env`. If a token/secret was ever shared, rotate it.
- Delegates can use the grantor's clients but cannot add their own, and phone
  numbers are hidden in delegated context.
- `MANDATORY_CHANNELS` is opt-in; empty means no auto-join.
