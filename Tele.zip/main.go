package main

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"

	"tgmultibot/config"
	"tgmultibot/database"
	"tgmultibot/manager"
	"tgmultibot/modules"

	"github.com/amarnathcjd/gogram/telegram"
)

var html = &telegram.SendOptions{ParseMode: telegram.HTML}

// UI wordmarks — Unicode small caps (ꜰʟᴀꜱʜ style): rendered natively by
// every Telegram client, no fonts needed. Panel titles across the modules
// follow the same style; utils.SmallCaps() converts any string at runtime.
const (
	wordmarkOnline   = "ꜰʟᴀꜱʜ ɪꜱ ᴏɴʟɪɴᴇ"
	wordmarkRestored = "ꜰʟᴀꜱʜ ʀᴇꜱᴛᴏʀᴇᴅ"
)

func main() {
	if err := run(); err != nil {
		log.Fatal(err)
	}
}

func run() error {
	if err := config.Load(); err != nil {
		return fmt.Errorf("load config: %w", err)
	}

	dbClose, err := database.Load(config.MongoURL, config.DbName)
	if err != nil {
		return fmt.Errorf("connect to MongoDB: %w", err)
	}
	defer dbClose()

	cm := manager.NewClientManager(int32(config.ApiID), config.ApiHash)

	client, err := telegram.NewClient(telegram.ClientConfig{
		AppID:    int32(config.ApiID),
		AppHash:  config.ApiHash,
		LogLevel: telegram.LogInfo,
	})
	if err != nil {
		return fmt.Errorf("create client: %w", err)
	}

	if err := client.LoginBot(config.Token); err != nil {
		return fmt.Errorf("login bot: %w", err)
	}

	if err := config.ResolveOwner(client); err != nil {
		return fmt.Errorf("resolve bot owner: %w", err)
	}

	if err := modules.Load(client, cm); err != nil {
		return fmt.Errorf("load modules: %w", err)
	}

	me, err := client.GetMe()
	if err != nil {
		return fmt.Errorf("get bot info: %w", err)
	}

	log.Printf("Bot started as @%s", me.Username)

	// Graceful shutdown: close every managed account + MongoDB cleanly.
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigCh
		log.Println("Shutting down...")
		cm.StopAll()
		client.Stop()
		dbClose()
		os.Exit(0)
	}()

	notify(client, startupMessage(me))

	cm.RestoreFromDB(func(msg string) {
		notify(client, restoreMessage(msg))
	})

	client.Idle()
	return nil
}

// notify sends msg to the logger chat, if one is configured.
func notify(client *telegram.Client, msg string) {
	if config.LoggerID == 0 {
		return
	}
	client.SendMessage(config.LoggerID, msg, html)
}

// startupMessage renders the "Bot Online" banner.
func startupMessage(me *telegram.UserObj) string {
	return fmt.Sprintf(
		"╭─❰ ✨ %s ✨ ❱\n"+
			"│\n"+
			"│  👤  <b>Name</b>      ›  %s\n"+
			"│  🔗  <b>Username</b>  ›  @%s\n"+
			"│  🆔  <b>ID</b>        ›  <code>%d</code>\n"+
			"│\n"+
			"╰─❰ ⚡ <i>Ready to serve</i> ❱",
		wordmarkOnline, me.FirstName, me.Username, me.ID,
	)
}

// restoreMessage wraps a restore-status line in the same boxed style.
func restoreMessage(msg string) string {
	return fmt.Sprintf(
		"╭─❰ ♻️ %s ❱\n"+
			"│  %s\n"+
			"╰─❰ ✅ ❱",
		wordmarkRestored, msg,
	)
}
