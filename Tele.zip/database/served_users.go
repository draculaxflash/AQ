package database

// AddServedUser records that a Telegram user has interacted with the bot.
// (The read-side helpers — ServedUsers/IsServedUser/RemoveServedUser — were
// removed: nothing ever called them, the usersMap index included.)
func AddServedUser(id int64) error {
	return modifyBotState(func(s *BotState) bool {
		var added bool
		s.Users, added = addUnique(s.Users, id)
		return added
	})
}
