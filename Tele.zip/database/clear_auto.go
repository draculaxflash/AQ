package database

// Clear helpers for the "🧹 Clear My Auto" button. Each clears the user's
// whole chat list for one automation and cleans up the in-memory reverse
// indexes the message-driven features use.

func ClearAutoReactChats(userID int64) (int, error) {
	state, err := getUserState(userID)
	if err != nil {
		return 0, err
	}
	removed := len(state.AutoReactChats)
	if removed == 0 {
		return 0, nil
	}
	if err := modifyUserState(userID, func(s *UserState) bool {
		s.AutoReactChats = nil
		return true
	}); err != nil {
		return 0, err
	}

	reactOwnersMu.Lock()
	for _, chatID := range state.AutoReactChats {
		reactOwners[chatID], _ = removeElement(reactOwners[chatID], userID)
		if len(reactOwners[chatID]) == 0 {
			delete(reactOwners, chatID)
		}
	}
	reactOwnersMu.Unlock()

	return removed, nil
}

func ClearAutoViewChats(userID int64) (int, error) {
	state, err := getUserState(userID)
	if err != nil {
		return 0, err
	}
	removed := len(state.AutoViewChats)
	if removed == 0 {
		return 0, nil
	}
	if err := modifyUserState(userID, func(s *UserState) bool {
		s.AutoViewChats = nil
		return true
	}); err != nil {
		return 0, err
	}

	viewOwnersMu.Lock()
	for _, chatID := range state.AutoViewChats {
		viewOwners[chatID], _ = removeElement(viewOwners[chatID], userID)
		if len(viewOwners[chatID]) == 0 {
			delete(viewOwners, chatID)
		}
	}
	viewOwnersMu.Unlock()

	return removed, nil
}
