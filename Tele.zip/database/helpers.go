package database

import (
	"context"
	"time"

	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

var upsertOpt = options.UpdateOne().SetUpsert(true)

func ctx() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), 5*time.Second)
}

// addUnique adds an element to a slice if it's not already present.
// Returns the new slice and true if the element was added.
func addUnique[T comparable](slice []T, element T) ([]T, bool) {
	for _, v := range slice {
		if v == element {
			return slice, false
		}
	}
	out := make([]T, len(slice), len(slice)+1)
	copy(out, slice)
	return append(out, element), true
}

// removeElement removes an element from a slice if it's present.
// Returns the new slice and true if the element was removed.
func removeElement[T comparable](slice []T, element T) ([]T, bool) {
	for i, v := range slice {
		if v == element {
			out := make([]T, 0, len(slice)-1)
			out = append(out, slice[:i]...)
			out = append(out, slice[i+1:]...)
			return out, true
		}
	}
	return slice, false
}

// contains checks if a slice contains an element.
func contains[T comparable](slice []T, element T) bool {
	for _, v := range slice {
		if v == element {
			return true
		}
	}
	return false
}
