package database

// AutoCallChats: chats where the owner's accounts automatically join the
// voice chat as soon as a group call becomes active (the "🤖 Auto Call"
// panel). No reverse owners-map needed — the trigger arrives on the owner's
// own client, so the watcher checks this list directly (cached).

func AddAutoCallChat(userID, chatID int64) error {
	return modifyUserState(userID, func(s *UserState) bool {
		var added bool
		s.AutoCallChats, added = addUnique(s.AutoCallChats, chatID)
		return added
	})
}

func RemoveAutoCallChat(userID, chatID int64) error {
	return modifyUserState(userID, func(s *UserState) bool {
		var removed bool
		s.AutoCallChats, removed = removeElement(s.AutoCallChats, chatID)
		return removed
	})
}

func GetAutoCallChats(userID int64) ([]int64, error) {
	state, err := getUserState(userID)
	if err != nil {
		return nil, err
	}
	out := make([]int64, len(state.AutoCallChats))
	copy(out, state.AutoCallChats)
	return out, nil
}

// ClearAutoCallChats removes every auto-call chat for the user and returns
// how many were removed.
func ClearAutoCallChats(userID int64) (int, error) {
	state, err := getUserState(userID)
	if err != nil {
		return 0, err
	}
	removed := len(state.AutoCallChats)
	if removed == 0 {
		return 0, nil
	}
	if err := modifyUserState(userID, func(s *UserState) bool {
		s.AutoCallChats = nil
		return true
	}); err != nil {
		return 0, err
	}
	return removed, nil
}
