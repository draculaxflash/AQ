package database

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"io"
	"log"
	"os"
	"sync"
)

// The AES-256 key now comes from the ENC_KEY environment variable
// (any string; it is hashed with SHA-256 to 32 bytes).
//
// legacyKey is the OLD key that used to be hard-coded in the source. It is
// kept ONLY so sessions already stored in MongoDB can still be decrypted
// (they are transparently re-encrypted with the new key next time they are
// saved). Once every record has been re-saved you can delete legacyKey.
// Treat the old key as compromised: set ENC_KEY and re-add / re-save sessions.
var legacyKey = []byte("c7f1b9a3e6d4082f5a91c3b7e0d2f4a8")

var (
	keyOnce    sync.Once
	primaryKey []byte
)

func getKey() []byte {
	keyOnce.Do(func() {
		if s := os.Getenv("ENC_KEY"); s != "" {
			h := sha256.Sum256([]byte(s))
			primaryKey = h[:]
			return
		}
		log.Println("WARNING: ENC_KEY is not set - falling back to the legacy built-in key. Set ENC_KEY!")
		primaryKey = legacyKey
	})
	return primaryKey
}

func newGCM(key []byte) (cipher.AEAD, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

// encryptStr encrypts raw with AES-GCM and returns base64(nonce||ciphertext||tag).
func encryptStr(raw string) (string, error) {
	if raw == "" {
		return "", nil
	}
	gcm, err := newGCM(getKey())
	if err != nil {
		return "", fmt.Errorf("encryptStr: new gcm: %w", err)
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", fmt.Errorf("encryptStr: nonce: %w", err)
	}
	sealed := gcm.Seal(nonce, nonce, []byte(raw), nil)
	return base64.StdEncoding.EncodeToString(sealed), nil
}

func openWith(key, data []byte) (string, error) {
	gcm, err := newGCM(key)
	if err != nil {
		return "", err
	}
	ns := gcm.NonceSize()
	if len(data) < ns {
		return "", fmt.Errorf("ciphertext too short")
	}
	plain, err := gcm.Open(nil, data[:ns], data[ns:], nil)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}

// decryptStr reverses encryptStr (tries the configured key, then the legacy key).
func decryptStr(enc string) (string, error) {
	if enc == "" {
		return "", nil
	}
	data, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", fmt.Errorf("decryptStr: base64: %w", err)
	}
	plain, err := openWith(getKey(), data)
	if err == nil {
		return plain, nil
	}
	if string(getKey()) != string(legacyKey) {
		if plain, lerr := openWith(legacyKey, data); lerr == nil {
			return plain, nil
		}
	}
	return "", fmt.Errorf("decryptStr: %w", err)
}
