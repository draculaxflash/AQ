package utils

import "strings"

// smallCapsRunes index 0..25 corresponds to A..Z (and a..z).
var smallCapsRunes = []rune("ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ")

// SmallCaps renders ASCII letters in the Unicode "small capital" style used
// across the bot's UI (ꜰʟᴀꜱʜ). Digits, punctuation and emojis pass through
// unchanged — they have no small-cap glyphs and clients would render tofu
// boxes for substitutes.
func SmallCaps(s string) string {
	if s == "" || strings.TrimSpace(s) == "" {
		return s
	}
	var b strings.Builder
	b.Grow(len(s))
	for _, r := range s {
		switch {
		case r >= 'A' && r <= 'Z':
			b.WriteRune(smallCapsRunes[r-'A'])
		case r >= 'a' && r <= 'z':
			b.WriteRune(smallCapsRunes[r-'a'])
		default:
			b.WriteRune(r)
		}
	}
	return b.String()
}
