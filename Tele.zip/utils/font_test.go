package utils

import "testing"

func TestSmallCaps(t *testing.T) {
	if got := SmallCaps("FLASH"); got != "ꜰʟᴀꜱʜ" {
		t.Fatalf("got %q, want ꜰʟᴀꜱʜ", got)
	}
	if got := SmallCaps("flash"); got != "ꜰʟᴀꜱʜ" {
		t.Fatalf("got %q, want ꜰʟᴀꜱʜ", got)
	}
	if got := SmallCaps("OTP 12345!"); got != "ᴏᴛᴘ 12345!" {
		t.Fatalf("got %q, want ᴏᴛᴘ 12345!", got)
	}
	if got := SmallCaps("mods 🔥 ok"); got != "ᴍᴏᴅꜱ 🔥 ᴏᴋ" {
		t.Fatalf("got %q", got)
	}
	if got := SmallCaps(""); got != "" {
		t.Fatalf("empty string changed: %q", got)
	}
}
