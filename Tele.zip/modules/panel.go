package modules

import (
	"fmt"
	"runtime"
	"strings"
	"time"

	"tgmultibot/config"
	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

var botStartedAt = time.Now()

func panelReplyOpts(userID int64) *telegram.SendOptions {
	return &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)}
}

func humanDuration(d time.Duration) string {
	s := int(d.Seconds())
	if s < 60 {
		return fmt.Sprintf("%ds", s)
	}
	m, h := (s/60)%60, s/3600
	if h == 0 {
		return fmt.Sprintf("%dm %ds", m, s%60)
	}
	return fmt.Sprintf("%dh %dm", h, m)
}

// ⏱ Uptime
func handleUptime(m *telegram.NewMessage) error {
	userID := m.SenderID()
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)

	text := fmt.Sprintf(
		"╭─❰ ⏱ ᴜᴘᴛɪᴍᴇ ❱\n│\n"+
			"│  🕒  <b>Uptime</b>     ›  %s\n"+
			"│  🚀  <b>Started</b>    ›  %s\n"+
			"│  🧵  <b>Goroutines</b> ›  %d\n"+
			"│  💾  <b>Memory</b>     ›  %d MB\n"+
			"╰─❰ ⚡ Running strong ❱",
		humanDuration(time.Since(botStartedAt)),
		botStartedAt.Format("02 Jan 15:04 MST"),
		runtime.NumGoroutine(),
		ms.HeapAlloc/(1024*1024),
	)
	_, err := m.Reply(text, panelReplyOpts(userID))
	return err
}

// 🏓 Ping
func handlePing(m *telegram.NewMessage) error {
	userID := m.SenderID()
	latency := c.Ping()

	mongo := "✅"
	if err := database.Ping(); err != nil {
		mongo = "❌ " + err.Error()
	}

	text := fmt.Sprintf(
		"╭─❰ 🏓 ᴘɪɴɢ ❱\n│\n"+
			"│  📡  <b>Telegram API</b>  ›  <code>%d ms</code>\n"+
			"│  🍃  <b>Database</b>      ›  %s\n"+
			"╰─❰ ⚡ Pong ❱",
		latency.Milliseconds(), escapeHTML(mongo),
	)
	_, err := m.Reply(text, panelReplyOpts(userID))
	return err
}

// 📊 Status
func handleStatus(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	reactN, _ := database.GetAutoReactChats(ownerID)
	viewN, _ := database.GetAutoViewChats(ownerID)
	callN, _ := database.GetAutoCallChats(ownerID)

	text := fmt.Sprintf(
		"╭─❰ 📊 ꜱᴛᴀᴛᴜꜱ ❱\n│\n"+
			"│  🕒  <b>Uptime</b>        ›  %s\n"+
			"│  👥  <b>Your clients</b>  ›  %d connected\n"+
			"│  🎙  <b>Playing in</b>    ›  %d chat(s)\n"+
			"│  🔁  <b>Auto React</b>   ›  %d chat(s)\n"+
			"│  👁  <b>Auto View</b>    ›  %d chat(s)\n"+
			"│  🤖  <b>Auto Call</b>    ›  %d chat(s)\n│\n",
		humanDuration(time.Since(botStartedAt)),
		cm.Count(ownerID),
		len(cm.Playlist(ownerID)),
		len(reactN), len(viewN), len(callN),
	)

	// Owner-only extras: global account pool + database health.
	if config.Owner != nil && userID == config.Owner.ID {
		mongo := "✅ healthy"
		if err := database.Ping(); err != nil {
			mongo = "❌ " + err.Error()
		}
		text += fmt.Sprintf(
			"│  🌐  <b>Total accounts</b> ›  %d (%d unique)\n"+
				"│  🍃  <b>Database</b>      ›  %s\n│\n",
			cm.TotalCount(), cm.UniqueAccountCount(), escapeHTML(mongo),
		)
	}
	text += "╰─❰ ⚡ All systems ❱"

	_, err := m.Reply(text, panelReplyOpts(userID))
	return err
}

// 👤 My Info
func handleMyInfo(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)
	personal := isPersonalCtx(userID)

	delegates, _ := database.ListDelegates(userID)
	grantors := database.GrantorsFor(userID)

	text := fmt.Sprintf(
		"╭─❰ 👤 ᴍʏ ɪɴꜰᴏ ❱\n│\n"+
			"│  🆔  <b>Your ID</b>     ›  <code>%d</code>\n"+
			"│  🎛  <b>Context</b>     ›  %s\n"+
			"│  👥  <b>Clients</b>     ›  %d connected\n│\n"+
			"│  🔑  <b>Delegates</b>   ›  %d\n"+
			"│  🤝  <b>Granted by</b>  ›  %d owner(s)\n│\n",
		userID,
		map[bool]string{true: "👤 Personal", false: fmt.Sprintf("🔑 Delegated (<code>%d</code>)", ownerID)}[personal],
		cm.Count(ownerID),
		len(delegates), len(grantors),
	)

	if !personal {
		reactN, _ := database.GetAutoReactChats(ownerID)
		viewN, _ := database.GetAutoViewChats(ownerID)
		callN, _ := database.GetAutoCallChats(ownerID)
		text += fmt.Sprintf(
			"│  🔁  Auto React › %d  👁 Auto View › %d\n"+
				"│  🤖  Auto Call  › %d\n│\n",
			len(reactN), len(viewN), len(callN),
		)
	}
	text += "╰─❰ ⚡ — ❱"

	_, err := m.Reply(text, panelReplyOpts(userID))
	return err
}

// 🧹 Clear My Auto — wipes the effective owner's auto react/view/call lists.
func handleClearMyAuto(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	reactN, err1 := database.ClearAutoReactChats(ownerID)
	viewN, err2 := database.ClearAutoViewChats(ownerID)
	callN, err3 := database.ClearAutoCallChats(ownerID)

	if err1 != nil || err2 != nil || err3 != nil {
		sendTraceback(fmt.Sprintf("ClearMyAuto for user %d: %v / %v / %v", userID, err1, err2, err3))
		_, err := m.Reply(
			"╭─❰ ❌ ᴄʟᴇᴀʀ ꜰᴀɪʟᴇᴅ ❱\n│\n│  Could not clear, try again.\n│\n╰─❰ — ❱",
			panelReplyOpts(userID),
		)
		return err
	}

	if reactN+viewN+callN == 0 {
		_, err := m.Reply(
			"╭─❰ 🧹 ᴄʟᴇᴀʀ ᴍʏ ᴀᴜᴛᴏ ❱\n│\n"+
				"│  Nothing to clear — no auto react,\n"+
				"│  auto view or auto call chats set.\n│\n"+
				"╰─❰ ✨ Already clean ❱",
			panelReplyOpts(userID),
		)
		return err
	}

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ 🧹 ᴄʟᴇᴀʀᴇᴅ ❱\n│\n"+
				"│  🔁  Auto React  ›  %d chat(s) removed\n"+
				"│  👁  Auto View   ›  %d chat(s) removed\n"+
				"│  🤖  Auto Call   ›  %d chat(s) removed\n│\n"+
				"╰─❰ ✨ All automation stopped ❱",
			reactN, viewN, callN,
		),
		panelReplyOpts(userID),
	)
	return err
}

// 📦 Import Zip — same upload flow as Upload Session (accepts .zip with
// .session files, raw .session files, and .txt string sessions).
func handleImportZip(m *telegram.NewMessage) error {
	return handleUploadSessionPrompt(m)
}

// 🔄 Restart Accounts — reconnect every client of the effective owner from
// the stored sessions.
func handleRestartAccounts(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	if existing := ps.current(userID); existing != "" {
		_, err := m.Reply(
			fmt.Sprintf(
				"╭─❰ ⚙️ ᴘʀᴏᴄᴇꜱꜱ ʀᴜɴɴɪɴɢ ❱\n│\n"+
					"│  Currently active: <code>%s</code>\n│\n"+
					"│  Send /cancel to stop it first.\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(existing),
			),
			panelReplyOpts(userID),
		)
		return err
	}

	if cm.Count(ownerID) == 0 {
		_, err := m.Reply(noClientsMsg(userID), panelReplyOpts(userID))
		return err
	}

	prog := newUIProgress(userID, uiLabel("RESTARTING"), cm.Count(ownerID))

	go func() {
		defer func() {
			if r := recover(); r != nil {
				sendTraceback(fmt.Sprintf("panic in RestartAccounts for user %d: %v", userID, r))
			}
		}()

		restarted, problems := cm.RestartOwnerClients(ownerID, func(done, total int) {
			prog.SetDone(done)
		})

		var text string
		if len(problems) == 0 {
			text = fmt.Sprintf(
				"╭─❰ ✅ ʀᴇꜱᴛᴀʀᴛᴇᴅ ❱\n│\n"+
					"│  ♻️  <b>Reconnected</b>  ›  %d account(s)\n│\n"+
					"╰─❰ ✨ All accounts fresh ❱",
				restarted,
			)
		} else {
			var p strings.Builder
			for i, pr := range problems {
				if i >= 10 {
					p.WriteString(fmt.Sprintf("│  … and %d more\n", len(problems)-10))
					break
				}
				p.WriteString(fmt.Sprintf("│  • <code>%s</code>\n", escapeHTML(pr)))
			}
			text = fmt.Sprintf(
				"╭─❰ ⚠️ ʀᴇꜱᴛᴀʀᴛ ᴅᴏɴᴇ ❱\n│\n"+
					"│  ♻️  <b>Reconnected</b>  ›  %d\n"+
					"│  ❌  <b>Failed</b>       ›  %d\n│\n"+
					"%s╰─❰ See details above ❱",
				restarted, len(problems), p.String(),
			)
		}
		if prog != nil {
			prog.Finish(text, panelReplyOpts(userID))
		} else {
			c.SendMessage(userID, text, panelReplyOpts(userID))
		}
	}()

	return nil
}
