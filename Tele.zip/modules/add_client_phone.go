package modules

import (
	"context"
	"fmt"
	"regexp"
	"strings"
	"time"

	"tgmultibot/config"

	"github.com/amarnathcjd/gogram/telegram"
)

var otpRunRE = regexp.MustCompile(`\d{5,6}`)

func addClientMethodKB() *telegram.KeyboardBuilder {
	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnAddByPhone))
	kb.AddRow(telegram.Button.Text(BtnUploadSession))
	kb.AddRow(telegram.Button.Text(BtnAddClientCancel))
	return kb
}

func buildAddClientBackKB() telegram.ReplyMarkup {
	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))
	return kb.BuildReply(ropts)
}

func handleAddClientBack(m *telegram.NewMessage) error {
	return handleStart(m)
}

func handleAddClientCancel(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ps.done(userID)
	_, err := m.Reply(
		"╭─❰ 🚫 ᴀᴅᴅ ᴄʟɪᴇɴᴛ ᴄᴀɴᴄᴇʟʟᴇᴅ ❱\n│\n"+
			"│  No changes were made.\n│\n"+
			"╰─❰ — ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
	)
	return err
}

func handleAddByPhonePrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	if !isPersonalCtx(userID) || isDelegateOnly(userID) {
		_, err := m.Reply(
			"╭─❰ 🔒 ᴘᴇʀꜱᴏɴᴀʟ ᴏɴʟʏ ❱\n│\n"+
				"│  Add Client is available in <b>Personal</b> context.\n│\n"+
				"│  Tap <b>🔄 Switch Access → ✅ Personal</b>\n"+
				"│  to switch back.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return err
	}
	ctx, ok := guardProcess(m, "Add Client")
	if !ok {
		return nil
	}

	cg.SetListening(userID)

	_, err := m.Reply(
		"╭─❰ 📱 ᴀᴅᴅ ʙʏ ᴘʜᴏɴᴇ ❱\n│\n"+
			"│  Follow the prompts — check your messages.\n│\n"+
			"│  <i>Tap 🔙 Back to cancel, or send /cancel.</i>\n│\n"+
			"╰─❰ ⌨️ Awaiting your phone ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildAddClientBackKB()},
	)
	if err != nil {
		ps.done(userID)
		cg.StopListening(userID)
		return err
	}

	go phoneLoginLoop(ctx, userID)
	return nil
}

func handleUploadSessionPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()
	if !isPersonalCtx(userID) || isDelegateOnly(userID) {
		_, err := m.Reply(
			"╭─❰ 🔒 ᴘᴇʀꜱᴏɴᴀʟ ᴏɴʟʏ ❱\n│\n"+
				"│  Add Client is available in <b>Personal</b> context.\n│\n"+
				"│  Tap <b>🔄 Switch Access → ✅ Personal</b>\n"+
				"│  to switch back.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return err
	}
	ctx, ok := guardProcess(m, "Add Client")
	if !ok {
		return nil
	}

	cg.SetListening(userID)

	_, err := m.Reply(
		"╭─❰ 📂 ᴜᴘʟᴏᴀᴅ ꜱᴇꜱꜱɪᴏɴ ❱\n│\n"+
			"│  Send your Telegram session file(s):\n│\n"+
			"│  📄  A single <code>.session</code> file\n"+
			"│  📦  A <code>.zip</code> containing multiple\n"+
			"│      <code>.session</code> files\n"+
			"│  🗂  Multiple <code>.session</code> files at once\n"+
			"│      (sent as an album)\n│\n"+
			"│  <i>Tap 🔙 Back to cancel, or send /cancel.</i>\n│\n"+
			"╰─❰ ⌨️ Awaiting your file ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildAddClientBackKB()},
	)
	if err != nil {
		ps.done(userID)
		cg.StopListening(userID)
		return err
	}

	go addClientLoop(ctx, userID)
	return nil
}

func phoneLoginLoop(ctx context.Context, userID int64) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in phoneLoginLoop: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	phone, ok := askText(ctx, userID,
		"╭─❰ 📱 ᴀᴅᴅ ʙʏ ᴘʜᴏɴᴇ ❱\n│\n"+
			"│  Send the phone number with country code.\n│\n"+
			"│  Example:  <code>+1234567890</code>\n│\n"+
			"│  <i>Tap 🔙 Back to cancel, or send /cancel.</i>\n│\n"+
			"╰─❰ ⌨️ Awaiting your phone ❱",
		isValidPhone,
		"❌ <b>Invalid phone number.</b>\n\nSend it with the country code, e.g. <code>+1234567890</code>.")
	if !ok {
		return
	}

	client, err := telegram.NewClient(telegram.ClientConfig{
		AppID:         int32(config.ApiID),
		AppHash:       config.ApiHash,
		MemorySession: true,
	})
	if err != nil {
		sendPhoneError(userID, "create client", err)
		return
	}
	if err := client.Connect(); err != nil {
		client.Stop()
		sendPhoneError(userID, "connect", err)
		return
	}

	hash, err := client.SendCode(phone)
	if err != nil {
		client.Stop()
		sendPhoneError(userID, "send code", err)
		return
	}

	var auth any
	for otpTry := 1; ; otpTry++ {
		otpMsg, ok := askText(ctx, userID,
			fmt.Sprintf(
				"╭─❰ 🔑 ᴏᴛᴘ ꜱᴇɴᴛ ❱\n│\n"+
					"│  Code sent to:  <code>%s</code>\n│\n"+
					"│  Paste the full message or just the digits —\n"+
					"│  I'll extract the code automatically.\n│\n"+
					"│  <i>Tap 🔙 Back to cancel, or send /cancel.</i>\n│\n"+
					"╰─❰ ⌨️ Awaiting your code ❱",
				phone,
			),
			func(s string) bool { return len(extractOTPDigits(s)) >= 5 },
			"❌ <b>No code detected.</b>\n\nSend the 5-digit OTP, or paste the full message.")
		if !ok {
			client.Stop()
			return
		}
		otp := extractOTPDigits(otpMsg)
		auth, err = client.AuthSignIn(phone, hash, otp, nil)
		if err != nil && otpTry < maxAttempts && telegram.MatchError(err, "PHONE_CODE_INVALID") {
			c.SendMessage(userID, "❌ <b>Wrong code.</b> Please try again.", &telegram.SendOptions{ParseMode: telegram.HTML})
			continue
		}
		break
	}
	switch {
	case err != nil && telegram.MatchError(err, "SESSION_PASSWORD_NEEDED"):
		password, ok := askText(ctx, userID,
			"╭─❰ 🔐 ᴛᴡᴏ-ꜰᴀᴄᴛᴏʀ ❱\n│\n"+
				"│  2FA is enabled for this account.\n│\n"+
				"│  Send the account's 2FA password.\n│\n"+
				"│  <i>Tap 🔙 Back to cancel, or send /cancel.</i>\n│\n"+
				"╰─❰ ⌨️ Awaiting your password ❱",
			func(s string) bool { return strings.TrimSpace(s) != "" },
			"❌ Password cannot be empty.")
		if !ok {
			client.Stop()
			return
		}
		accPassword, gErr := client.AccountGetPassword()
		if gErr != nil {
			client.Stop()
			sendPhoneError(userID, "fetch 2FA settings", gErr)
			return
		}
		inputPassword, cErr := telegram.GetInputCheckPassword(password, accPassword)
		if cErr != nil {
			client.Stop()
			sendPhoneError(userID, "compute 2FA password", cErr)
			return
		}
		if _, cpErr := client.AuthCheckPassword(inputPassword); cpErr != nil {
			client.Stop()
			sendPhoneError(userID, "2FA password", cpErr)
			return
		}
	case err != nil:
		client.Stop()
		sendPhoneError(userID, "login", err)
		return
	default:
		if _, signUp := auth.(*telegram.AuthAuthorizationSignUpRequired); signUp {
			client.Stop()
			c.SendMessage(userID,
				"╭─❰ ❌ ɴᴏᴛ ʀᴇɢɪꜱᴛᴇʀᴇᴅ ❱\n│\n"+
					"│  This number is not on Telegram.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})
			return
		}
	}

	sess := client.ExportSession()
	client.Stop()

	mc, err := cm.AddClient(userID, sess)
	if err != nil {
		sendTraceback(fmt.Sprintf("phoneLoginLoop AddClient error for user %d: %v", userID, err))
		c.SendMessage(userID,
			"╭─❰ ❌ ꜱᴀᴠᴇ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  Could not save this account.\n│\n"+
				"╰─❰ Details below ❱\n\n"+
				"<pre>"+escapeHTML(err.Error())+"</pre>",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})
		return
	}

	me := mc.Client.Me()
	name := "Unknown"
	phoneStr := phone
	var meID int64
	if me != nil {
		name = strings.TrimSpace(me.FirstName + " " + me.LastName)
		if me.Phone != "" {
			phoneStr = "+" + me.Phone
		}
		meID = me.ID
	}
	c.SendMessage(userID, fmt.Sprintf(
		"╭─❰ ✅ ᴀᴄᴄᴏᴜɴᴛ ᴀᴅᴅᴇᴅ ❱\n│\n"+
			"│  👤  <b>Name</b>   ›  %s\n"+
			"│  📞  <b>Phone</b>  ›  <code>%s</code>\n"+
			"│  🆔  <b>ID</b>     ›  <code>%d</code>\n│\n"+
			"╰─❰ ✨ Ready to use ❱",
		escapeHTML(name), phoneStr, meID,
	), &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})

	go joinMandatoryChannels(userID)
}

func askText(ctx context.Context, userID int64, prompt string, validate func(string) bool, invalidMsg string) (string, bool) {
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		if ctx.Err() != nil {
			return "", false
		}
		c.SendMessage(userID, prompt,
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildAddClientBackKB()})

		msg, ok := recvText(ctx, userID)
		if !ok {
			return "", false
		}
		if msg == "" || (validate != nil && !validate(msg)) {
			if attempt < maxAttempts {
				c.SendMessage(userID,
					fmt.Sprintf(
						"%s\n\n🔄 <i>Attempt %d/%d — <b>%d</b> remaining.</i>",
						invalidMsg, attempt, maxAttempts, maxAttempts-attempt,
					),
					&telegram.SendOptions{ParseMode: telegram.HTML})
			} else {
				c.SendMessage(userID,
					"╭─❰ 🚫 ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴇᴍᴘᴛꜱ ❱\n│\n"+
						"│  Tap <b>➕ Add Client</b> to start over.\n│\n"+
						"╰─❰ — ❱",
					&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})
			}
			continue
		}
		return msg, true
	}
	return "", false
}

func recvText(ctx context.Context, userID int64) (string, bool) {
	msgs, ok := cg.Recv(userID, 5*time.Minute)
	if !ok {
		if ctx.Err() == nil && cg.IsListening(userID) {
			c.SendMessage(userID,
				"╭─❰ ⏰ ᴛɪᴍᴇᴅ ᴏᴜᴛ ❱\n│\n"+
					"│  Tap <b>➕ Add Client</b> to try again.\n│\n"+
					"╰─❰ — ❱",
				&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})
		}
		return "", false
	}
	for _, m := range msgs {
		if t := strings.TrimSpace(m.Text()); t != "" {
			// Delete the user's message (phone / OTP / 2FA password) from chat.
			go m.Delete()
			return t, true
		}
	}
	return "", false
}

func isValidPhone(s string) bool {
	digits := 0
	for _, r := range s {
		if r >= '0' && r <= '9' {
			digits++
		}
	}
	return digits >= 8 && digits <= 15
}

func extractOTPDigits(s string) string {
	if m := otpRunRE.FindString(s); m != "" {
		return m
	}
	var b strings.Builder
	for _, r := range s {
		if r >= '0' && r <= '9' {
			b.WriteRune(r)
		}
	}
	return b.String()
}

func sendPhoneError(userID int64, stage string, err error) {
	sendTraceback(fmt.Sprintf("phone login (%s) error for user %d: %v", stage, userID, err))
	c.SendMessage(userID,
		fmt.Sprintf(
			"╭─❰ ❌ ʟᴏɢɪɴ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  <b>Stage:</b>  %s\n│\n"+
				"╰─❰ Details below ❱\n\n"+
				"<pre>%s</pre>",
			escapeHTML(stage), escapeHTML(err.Error()),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)})
}
