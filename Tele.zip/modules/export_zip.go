package modules

import (
	"archive/zip"
	"bytes"
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
	tgconv "github.com/mtgo-labs/session-converter"
	_ "modernc.org/sqlite"
)

// handleExportZip packs every stored account of the effective owner into a
// real Telethon-format .session SQLite archive and sends the zip. Sessions
// are decrypted from MongoDB on the fly; nothing is written to disk except a
// temporary zip that is removed right after the upload.
func handleExportZip(m *telegram.NewMessage) error {
	userID := m.SenderID()
	ownerID := effectiveOwnerID(userID)

	clients, err := database.UserClients(ownerID)
	if err != nil {
		sendTraceback(fmt.Sprintf("ExportZip for user %d: %v", userID, err))
		_, err := m.Reply(
			"╭─❰ ❌ ᴇxᴘᴏʀᴛ ꜰᴀɪʟᴇᴅ ❱\n│\n│  Could not load your accounts.\n│\n╰─❰ — ❱",
			panelReplyOpts(userID),
		)
		return err
	}
	if len(clients) == 0 {
		_, err := m.Reply(
			"╭─❰ 📤 ᴇxᴘᴏʀᴛ ᴢɪᴘ ❱\n│\n"+
				"│  You have no accounts to export.\n│\n"+
				"│  ➕ Add clients first.\n│\n"+
				"╰─❰ — ❱",
			panelReplyOpts(userID),
		)
		return err
	}

	prog := newUIProgress(userID, uiLabel("EXPORTING"), len(clients))

	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)

	exported, failed := 0, 0
	var failLines []string
	for i, ci := range clients {
		prog.SetDone(i + 1) // count every attempt, success or fail
		sess := ci.Session()
		if sess == "" {
			failed++
			failLines = append(failLines, fmt.Sprintf("account %d: empty session", ci.AccountID))
			continue
		}
		s, _, derr := tgconv.Decode(sess)
		if derr != nil {
			failed++
			failLines = append(failLines, fmt.Sprintf("account %d: decode: %v", ci.AccountID, derr))
			continue
		}
		sqlBytes, werr := telethonSQLiteBytes(s)
		if werr != nil {
			failed++
			failLines = append(failLines, fmt.Sprintf("account %d: %v", ci.AccountID, werr))
			continue
		}
		w, zerr := zw.CreateHeader(&zip.FileHeader{
			Name:     fmt.Sprintf("%s_session.session", sanitizeSessionName(ci.Phone(), ci.AccountID)),
			Modified: time.Now(),
		})
		if zerr != nil {
			failed++
			continue
		}
		if _, werr := w.Write(sqlBytes); werr != nil {
			failed++
			continue
		}
		exported++
	}
	zw.Close()

	if exported == 0 {
		for _, fl := range failLines {
			sendTraceback(fmt.Sprintf("ExportZip for user %d: %s", userID, fl))
		}
		_, err := m.Reply(
			"╭─❰ ❌ ᴇxᴘᴏʀᴛ ꜰᴀɪʟᴇᴅ ❱\n│\n│  No session could be packed.\n│\n╰─❰ — ❱",
			panelReplyOpts(userID),
		)
		return err
	}

	tmpPath := filepath.Join(playMediaDir, fmt.Sprintf("export_%d_%d.zip", userID, time.Now().Unix()))
	if err := os.MkdirAll(playMediaDir, 0o755); err != nil {
		sendTraceback(fmt.Sprintf("ExportZip mkdir for user %d: %v", userID, err))
		return nil
	}
	if err := os.WriteFile(tmpPath, buf.Bytes(), 0o600); err != nil {
		sendTraceback(fmt.Sprintf("ExportZip write for user %d: %v", userID, err))
		return nil
	}
	defer os.Remove(tmpPath)

	prog.Finish(fmt.Sprintf(
		"╭─❰ 📤 ᴇxᴘᴏʀᴛ ᴢɪᴘ ❱\n│\n"+
			"│  ✅  <b>Exported</b>  ›  %d session(s)\n"+
			"│  ❌  <b>Failed</b>    ›  %d\n│\n"+
			"│  Telethon-compatible <code>.session</code>\n"+
			"│  files inside — re-importable anytime.\n│\n"+
			"╰─❰ ⚠️ Keep the file private ❱",
		exported, failed,
	), panelReplyOpts(userID))

	_, err = c.SendMedia(userID, tmpPath, &telegram.MediaOptions{
		ForceDocument: true,
		FileName:      fmt.Sprintf("sessions_%d.zip", time.Now().Unix()),
		MimeType:      "application/zip",
	})
	if err != nil {
		sendTraceback(fmt.Sprintf("ExportZip send for user %d: %v", userID, err))
	}
	return err
}

// sanitizeSessionName turns a phone number into a safe file name part.
func sanitizeSessionName(phone string, accountID int64) string {
	p := strings.TrimLeft(strings.TrimSpace(phone), "+")
	p = strings.Map(func(r rune) rune {
		if (r >= '0' && r <= '9') || (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') {
			return r
		}
		return -1
	}, p)
	if p == "" {
		return fmt.Sprintf("acc_%d", accountID)
	}
	return p
}

// telethonSQLiteBytes writes a Telethon-compatible .session SQLite database
// (same schema our own importer reads) into a byte buffer.
func telethonSQLiteBytes(s *tgconv.Session) ([]byte, error) {
	if len(s.AuthKey) != 256 {
		return nil, fmt.Errorf("invalid auth key length: %d", len(s.AuthKey))
	}
	s.FillDefaults() // fills ServerAddress/Port from the DC id when missing

	tmp, err := os.CreateTemp("", "export_*.session")
	if err != nil {
		return nil, fmt.Errorf("mktemp: %w", err)
	}
	tmpName := tmp.Name()
	tmp.Close()
	defer os.Remove(tmpName)

	db, err := sql.Open("sqlite", tmpName)
	if err != nil {
		return nil, fmt.Errorf("open sqlite: %w", err)
	}

	schema := []string{
		`CREATE TABLE version (version integer primary key)`,
		`CREATE TABLE sessions (dc_id integer primary key, server_address text, port integer, auth_key blob, takeout_id integer)`,
		`CREATE TABLE entities (id integer primary key, hash integer not null, username text, phone integer, name text)`,
		`CREATE TABLE sent_files (md5_digest text, file_size integer, type integer, id integer, hash integer, PRIMARY KEY(md5_digest, file_size, type))`,
		`CREATE TABLE update_state (id integer primary key, pts integer, qts integer, date integer, seq integer)`,
		`INSERT INTO version (version) VALUES (2)`,
	}
	for _, q := range schema {
		if _, err := db.Exec(q); err != nil {
			db.Close()
			return nil, fmt.Errorf("schema: %w", err)
		}
	}
	if _, err := db.Exec(
		`INSERT INTO sessions (dc_id, server_address, port, auth_key, takeout_id) VALUES (?, ?, ?, ?, NULL)`,
		s.DCID, s.ServerAddress, s.Port, s.AuthKey,
	); err != nil {
		db.Close()
		return nil, fmt.Errorf("insert session: %w", err)
	}
	if err := db.Close(); err != nil {
		return nil, fmt.Errorf("close sqlite: %w", err)
	}

	out, err := os.ReadFile(tmpName)
	if err != nil {
		return nil, fmt.Errorf("read sqlite: %w", err)
	}
	return out, nil
}
