package modules

import "testing"

// Basic unit tests for the pure parsing helpers (no network, no globals).

func TestResolveMsgLinkPublic(t *testing.T) {
	peer, msgID, err := resolveMsgLink("t.me/username/123")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if peer != "username" || msgID != 123 {
		t.Fatalf("got peer=%v msgID=%d, want username/123", peer, msgID)
	}
}

func TestResolveMsgLinkPrivate(t *testing.T) {
	peer, msgID, err := resolveMsgLink("https://t.me/c/1234567890/456")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if peer != chanIDToPeer(1234567890) {
		t.Fatalf("got peer=%v, want marked id %d", peer, chanIDToPeer(1234567890))
	}
	if msgID != 456 {
		t.Fatalf("got msgID=%d, want 456", msgID)
	}
}

func TestResolveMsgLinkQuerySuffix(t *testing.T) {
	// t.me links copied from media groups often carry a ?single query param;
	// Sscanf stops at the separator and still parses the message id.
	_, msgID, err := resolveMsgLink("t.me/username/999?single")
	if err != nil || msgID != 999 {
		t.Fatalf("got msgID=%d err=%v, want 999 and nil error", msgID, err)
	}
}

func TestResolveMsgLinkInvalid(t *testing.T) {
	for _, link := range []string{"t.me/username", "t.me/c/abc/1", "not a link"} {
		if _, _, err := resolveMsgLink(link); err == nil {
			t.Fatalf("expected error for %q", link)
		}
	}
}

func TestChanIDToPeer(t *testing.T) {
	if got := chanIDToPeer(1234567890); got != -1001234567890 {
		t.Fatalf("got %d, want -1001234567890", got)
	}
}

func TestExtractOTP(t *testing.T) {
	cases := map[string]string{
		"Telegram code 12345":              "12345",
		"Login code: 54321. Do not share":  "54321",
		"Your code is 98765, expires soon": "98765",
	}
	for in, want := range cases {
		if got := extractOTP(in); got != want {
			t.Fatalf("extractOTP(%q) = %q, want %q", in, got, want)
		}
	}
	// No digits -> the full message is returned verbatim.
	const raw = "Hello from Telegram"
	if got := extractOTP(raw); got != raw {
		t.Fatalf("extractOTP(%q) = %q, want the raw message", raw, got)
	}
}

func TestNormalizeAccessToken(t *testing.T) {
	token, ok := normalizeAccessToken("k3f9-qxj2-7h4p-mn8r")
	if !ok || token != "K3F9-QXJ2-7H4P-MN8R" {
		t.Fatalf("got %q ok=%v, want uppercase token and true", token, ok)
	}
	if _, ok := normalizeAccessToken("SHORT"); ok {
		t.Fatal("expected false for a token that is too short")
	}
	if _, ok := normalizeAccessToken("ABCD-EFGH-IJKL-MNOP"); !ok {
		t.Fatal("expected true for a valid-format token")
	}
}

func TestContains64(t *testing.T) {
	list := []int64{1, 2, 3}
	if !contains64(list, 2) {
		t.Fatal("expected true for a present element")
	}
	if contains64(list, 9) {
		t.Fatal("expected false for a missing element")
	}
	if contains64(nil, 1) {
		t.Fatal("expected false for an empty list")
	}
}

func TestSanitizeSessionName(t *testing.T) {
	if got := sanitizeSessionName("+91 98765 43210", 42); got != "919876543210" {
		t.Fatalf("got %q, want digits-only phone", got)
	}
	if got := sanitizeSessionName("", 42); got != "acc_42" {
		t.Fatalf("got %q, want acc_42 fallback", got)
	}
	if got := sanitizeSessionName("+", 7); got != "acc_7" {
		t.Fatalf("got %q, want acc_7 fallback", got)
	}
}

func TestTruncateRunes(t *testing.T) {
	if got := truncateRunes("hello   world", 10); got != "hello wor…" {
		t.Fatalf("got %q", got)
	}
	if got := truncateRunes("short", 10); got != "short" {
		t.Fatalf("got %q", got)
	}
	if got := truncateRunes("  spaced\tout\n ", 30); got != "spaced out" {
		t.Fatalf("got %q", got)
	}
}
