package modules

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

// ── Client hooks ────────────────────────────────────────────────────────────
// Every managed userbot connection gets two hooks registered once:
//   1. OnMessage  → 📩 SMS Inbox capture (Telegram service codes, peer 777000)
//   2. UpdateGroupCall raw handler → 🤖 Auto Call auto-join
// Registration happens through manager.SetOnClientAdded, so restored startup
// accounts and freshly added accounts are covered alike.

const telegramServicePeer = 777000

type inboxEntry struct {
	accountID int64
	phone     string
	text      string
	at        time.Time
}

var (
	inboxMu      sync.Mutex
	inboxEntries []inboxEntry // newest last, capped

	hooksMu       sync.Mutex
	hookedClients = map[*telegram.Client]bool{}
)

func registerClientHooks(client *telegram.Client) {
	hooksMu.Lock()
	if hookedClients[client] {
		hooksMu.Unlock()
		return
	}
	hookedClients[client] = true
	hooksMu.Unlock()

	// 📩 SMS Inbox: capture messages from the Telegram service account
	// (777000) — login codes and service notices received on this account.
	client.On(telegram.OnMessage, func(m *telegram.NewMessage) error {
		if m.Message == nil || m.Message.Out {
			return nil
		}
		if m.SenderID() != telegramServicePeer {
			return nil
		}
		text := strings.TrimSpace(m.Text())
		if text == "" {
			return nil
		}
		accountID, phone := cm.AccountInfoOf(client)
		if accountID == 0 {
			return nil
		}
		inboxMu.Lock()
		inboxEntries = append(inboxEntries, inboxEntry{
			accountID: accountID,
			phone:     phone,
			text:      truncateRunes(text, 64),
			at:        time.Now(),
		})
		if len(inboxEntries) > 50 {
			inboxEntries = inboxEntries[len(inboxEntries)-50:]
		}
		inboxMu.Unlock()
		return nil
	})

	// 🤖 Auto Call: watch for group call updates on this connection.
	client.AddRawHandler(&telegram.UpdateGroupCall{}, handleGroupCallUpdate)
}

// ── 📩 SMS Inbox ────────────────────────────────────────────────────────────

func handleSMSInbox(m *telegram.NewMessage) error {
	userID := m.SenderID()

	inboxMu.Lock()
	entries := make([]inboxEntry, len(inboxEntries))
	copy(entries, inboxEntries)
	inboxMu.Unlock()

	if len(entries) == 0 {
		_, err := m.Reply(
			"╭─❰ 📩 ꜱᴍꜱ ɪɴʙᴏx ❱\n│\n"+
				"│  Nothing received yet.\n│\n"+
				"│  Login codes and service messages sent\n"+
				"│  to your connected accounts (from\n"+
				"│  Telegram, 777000) show up here.\n│\n"+
				"╰─❰ 💤 Empty ❱",
			panelReplyOpts(userID),
		)
		return err
	}

	var body strings.Builder
	body.WriteString("╭─❰ 📩 ꜱᴍꜱ ɪɴʙᴏꜱ ❱\n│\n")
	// newest first, max 10 shown
	shown := 10
	if len(entries) < shown {
		shown = len(entries)
	}
	for i := len(entries) - 1; i >= len(entries)-shown; i-- {
		e := entries[i]
		label := formatInboxPhone(e.phone, e.accountID)
		body.WriteString(fmt.Sprintf(
			"│  📱  <b>%s</b>\n"+
				"│      <code>%s</code>\n"+
				"│      🕒 %s ago\n│\n",
			label,
			escapeHTML(e.text),
			humanDuration(time.Since(e.at)),
		))
	}
	body.WriteString(fmt.Sprintf(
		"╰─❰ ⚡ %d message(s) captured — newest first ❱", len(entries),
	))

	_, err := m.Reply(body.String(), panelReplyOpts(userID))
	return err
}

func formatInboxPhone(phone string, accountID int64) string {
	p := strings.TrimSpace(phone)
	if p == "" {
		return fmt.Sprintf("acc %d", accountID)
	}
	// mask middle digits for privacy in shared chats
	if len(p) > 7 {
		return p[:4] + "•••" + p[len(p)-3:]
	}
	return p
}

func truncateRunes(s string, max int) string {
	r := []rune(strings.Join(strings.Fields(s), " "))
	if len(r) <= max {
		return string(r)
	}
	return string(r[:max-1]) + "…"
}

// ── 🤖 Auto Call watcher ────────────────────────────────────────────────────

var (
	autoCallMu       sync.Mutex
	autoCallJoinedBy = map[int64]map[int64]bool{} // group call ID -> ownerID set
)

// handleGroupCallUpdate fires on every group-call change seen by any managed
// account. When the call is ACTIVE and the owner enabled 🤖 Auto Call for
// that chat, every client of that owner joins the voice chat automatically.
func handleGroupCallUpdate(raw telegram.Update, client *telegram.Client) error {
	up, ok := raw.(*telegram.UpdateGroupCall)
	if !ok || up.Call == nil {
		return nil
	}

	switch call := up.Call.(type) {
	case *telegram.GroupCallDiscarded:
		// call ended — forget the join markers for it
		autoCallMu.Lock()
		delete(autoCallJoinedBy, call.ID)
		autoCallMu.Unlock()
		return nil

	case *telegram.GroupCallObj:
		if call.ScheduleDate != 0 {
			return nil // scheduled call, not started yet
		}
		peerCh, ok := up.Peer.(*telegram.PeerChannel)
		if !ok {
			return nil
		}
		chatIDNum := -1000000000000 - peerCh.ChannelID

		for _, ownerID := range cm.OwnersOfClient(client) {
			chats, err := database.GetAutoCallChats(ownerID)
			if err != nil || !contains64(chats, chatIDNum) {
				continue
			}

			autoCallMu.Lock()
			per, seen := autoCallJoinedBy[call.ID]
			if !seen {
				per = make(map[int64]bool)
				autoCallJoinedBy[call.ID] = per
				if len(autoCallJoinedBy) > 500 {
					autoCallJoinedBy = map[int64]map[int64]bool{}
				}
			}
			if per[ownerID] {
				autoCallMu.Unlock()
				continue // already joined this call for this owner
			}
			per[ownerID] = true
			autoCallMu.Unlock()

			go func(ownerID, chatIDNum, callID int64) {
				defer func() {
					if r := recover(); r != nil {
						sendTraceback(fmt.Sprintf("panic in autoCall join (owner %d): %v", ownerID, r))
					}
				}()
				results := cm.JoinVoiceChat(context.Background(), ownerID, chatIDNum, 0)
				joined := 0
				for _, r := range results {
					if r.Err == nil {
						joined++
					}
				}
				if joined == 0 {
					// allow a retry if the join failed
					autoCallMu.Lock()
					if per, ok := autoCallJoinedBy[callID]; ok {
						delete(per, ownerID)
					}
					autoCallMu.Unlock()
					return
				}
				title, _ := cm.ChatTitle(ownerID, chatIDNum)
				c.SendMessage(ownerID,
					fmt.Sprintf(
						"╭─❰ 🤖 ᴀᴜᴛᴏ ᴄᴀʟʟ ❱\n│\n"+
							"│  🎙  <b>Joined</b>  ›  %d account(s)\n"+
							"│  📢  <b>Chat</b>    ›  %s\n│\n"+
							"╰─❰ ⚡ Voice chat is live ❱",
						joined, escapeHTML(title),
					),
					&telegram.SendOptions{ParseMode: telegram.HTML},
				)
			}(ownerID, chatIDNum, call.ID)
		}
	}
	return nil
}
