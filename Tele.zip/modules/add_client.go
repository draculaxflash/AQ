package modules

import (
	"archive/zip"
	"bytes"
	"context"
	"fmt"
	"io"
	"path/filepath"
	"strings"
	"time"

	"tgmultibot/utils"

	"github.com/amarnathcjd/gogram/telegram"
)

const (
	maxAttempts          = 3
	maxSessionUploadSize = 20 << 20 // 20 MB per uploaded file
	maxZipEntries        = 500
	maxSessionEntrySize  = 1 << 20 // 1 MB per .session inside a zip
)

func handleAddClientPrompt(m *telegram.NewMessage) error {
	userID := m.SenderID()

	if !isPersonalCtx(userID) || isDelegateOnly(userID) {
		_, err := m.Reply(
			"╭─❰ 🔒 ᴘᴇʀꜱᴏɴᴀʟ ᴏɴʟʏ ❱\n│\n"+
				"│  Add Client is available in <b>Personal</b> context.\n│\n"+
				"│  Tap <b>🔄 Switch Access → ✅ Personal</b>\n"+
				"│  to switch back.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return err
	}

	if existing := ps.current(userID); existing != "" {
		_, err := m.Reply(
			fmt.Sprintf(
				"╭─❰ ⚙️ ᴘʀᴏᴄᴇꜱꜱ ʀᴜɴɴɪɴɢ ❱\n│\n"+
					"│  Currently active: <code>%s</code>\n│\n"+
					"│  Send /cancel to stop it first.\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(existing),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
		)
		return err
	}

	_, err := m.Reply(
		"╭─❰ ➕ ᴀᴅᴅ ᴄʟɪᴇɴᴛꜱ ❱\n│\n"+
			"│  📱  <b>Add by Phone Number</b>\n"+
			"│      Login with phone + OTP\n│\n"+
			"│  📤  <b>Upload Session</b>\n"+
			"│      Send a <code>.session</code> or <code>.zip</code> file\n│\n"+
			"╰─❰ ✨ Choose a method below ❱",
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: addClientMethodKB().BuildReply(ropts)},
	)
	return err
}

func addClientLoop(ctx context.Context, userID int64) {
	defer func() {
		if r := recover(); r != nil {
			sendTraceback(fmt.Sprintf("panic in addClientLoop: %v", r))
		}
		ps.done(userID)
		cg.StopListening(userID)
	}()

	for attempt := 1; attempt <= maxAttempts; attempt++ {
		if ctx.Err() != nil {
			return
		}

		msgs, ok := cg.Recv(userID, 5*time.Minute)
		if !ok {
			if ctx.Err() == nil && cg.IsListening(userID) {
				c.SendMessage(userID,
					"╭─❰ ⏰ ᴛɪᴍᴇᴅ ᴏᴜᴛ ❱\n│\n"+
						"│  Tap <b>➕ Add Client</b> to try again.\n│\n"+
						"╰─❰ — ❱",
					&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: buildMenuKB(userID)},
				)
			}
			return
		}

		if ctx.Err() != nil {
			return
		}

		warn := validateMessages(msgs, attempt)
		if warn != "" {
			c.SendMessage(userID, warn, &telegram.SendOptions{ParseMode: telegram.HTML})
			if attempt == maxAttempts {
				c.SendMessage(userID,
					"╭─❰ 🚫 ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴇᴍᴘᴛꜱ ❱\n│\n"+
						"│  Tap <b>➕ Add Client</b> to start over.\n│\n"+
						"╰─❰ — ❱",
					&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: telegram.Button.Clear()},
				)
			} else {
				cg.SetListening(userID)
			}
			continue
		}

		if err := processSessionFiles(ctx, userID, msgs); err != nil {
			sendTraceback(fmt.Sprintf("processSessionFiles error for user %d: %v", userID, err))
		}
		return
	}
}

func processSessionFiles(ctx context.Context, userID int64, msgs []*telegram.NewMessage) error {
	type sessionEntry struct {
		name     string
		data     []byte
		isString bool // .txt entries already contain a gogram string session
	}
	var sessionFiles []sessionEntry
	var invalid []string

	for _, m := range msgs {
		if m.File == nil {
			continue
		}
		fname := strings.ToLower(m.File.Name)
		ext := strings.ToLower(m.File.Ext)

		if isMediaExt(ext) {
			invalid = append(invalid, m.File.Name)
			continue
		}
		if !strings.HasSuffix(fname, ".session") && !strings.HasSuffix(fname, ".zip") && !strings.HasSuffix(fname, ".txt") {
			invalid = append(invalid, m.File.Name)
			continue
		}

		var buf bytes.Buffer
		if _, err := m.Download(&telegram.DownloadOptions{Buffer: &buf}); err != nil {
			return fmt.Errorf("download failed for %s: %w", m.File.Name, err)
		}
		data := buf.Bytes()
		if len(data) > maxSessionUploadSize {
			invalid = append(invalid, m.File.Name+" (too large)")
			continue
		}

		if strings.HasSuffix(fname, ".zip") {
			extracted, err := extractSessionsFromZip(data)
			if err != nil {
				return fmt.Errorf("zip extract failed: %w", err)
			}
			for _, e := range extracted {
				sessionFiles = append(sessionFiles, sessionEntry{e.name, e.data, e.isString})
			}
		} else if strings.HasSuffix(fname, ".txt") {
			// Raw gogram string session (as exported by Export Zip's txt mode
			// or copied from other bots).
			base := strings.TrimSuffix(filepath.Base(fname), ".txt")
			sessionFiles = append(sessionFiles, sessionEntry{base, data, true})
		} else {
			base := strings.TrimSuffix(filepath.Base(fname), ".session")
			sessionFiles = append(sessionFiles, sessionEntry{base, data, false})
		}
	}

	if len(invalid) > 0 {
		var skipped strings.Builder
		skipped.WriteString(fmt.Sprintf(
			"╭─❰ ⚠️ ꜱᴋɪᴘᴘᴇᴅ %d ❱\n│\n│  Unsupported file(s):\n",
			len(invalid),
		))
		for _, name := range invalid {
			skipped.WriteString(fmt.Sprintf("│  • <code>%s</code>\n", escapeHTML(name)))
		}
		skipped.WriteString("│\n╰─❰ — ❱")
		c.SendMessage(userID, skipped.String(), &telegram.SendOptions{ParseMode: telegram.HTML})
	}

	if len(sessionFiles) == 0 {
		c.SendMessage(userID,
			"╭─❰ ❌ ɴᴏ ꜱᴇꜱꜱɪᴏɴꜱ ❱\n│\n"+
				"│  No valid session files were found.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return nil
	}

	total := len(sessionFiles)
	prog := newUIProgress(userID, uiLabel("PROCESSING"), total)

	added, failed, skippedCount := 0, 0, 0
	var errLines []string

	for i, sf := range sessionFiles {
		if ctx.Err() != nil {
			skippedCount = total - i
			break
		}

		var sessStr string
		var err error
		if sf.isString {
			sessStr = strings.TrimSpace(string(sf.data))
			if sessStr == "" || strings.ContainsAny(sessStr, " \n\r\t") {
				err = fmt.Errorf("invalid session string")
			}
		} else {
			sessStr, err = utils.ConvertSessionFile(sf.data, sf.name)
		}
		if err != nil {
			errLines = append(errLines,
				fmt.Sprintf("• <code>%s</code> — convert failed: %s", escapeHTML(sf.name), escapeHTML(err.Error())))
			sendTraceback(fmt.Sprintf("convert failed for user %d (%s): %v", userID, sf.name, err))
			failed++
			continue
		}

		if ctx.Err() != nil {
			skippedCount = total - i
			break
		}

		mc, err := cm.AddClient(userID, sessStr)
		if err != nil {
			errLines = append(errLines,
				fmt.Sprintf("• <code>%s</code> — start failed: %s", escapeHTML(sf.name), escapeHTML(err.Error())))
			sendTraceback(fmt.Sprintf("AddClient start failed for user %d (%s): %v", userID, sf.name, err))
			failed++
			continue
		}

		if mc.Client.Me() == nil {
			// The connection is live but account info could not be read.
			// Remove the client again so Added/Failed and cm.Count stay
			// consistent (previously it stayed attached but counted failed).
			if rmErr := cm.RemoveClientByID(userID, mc.AccountID); rmErr != nil {
				sendTraceback(fmt.Sprintf("cleanup after GetMe nil failed for user %d (%s): %v", userID, sf.name, rmErr))
			}
			errLines = append(errLines,
				fmt.Sprintf("• <code>%s</code> — could not fetch account info", escapeHTML(sf.name)))
			sendTraceback(fmt.Sprintf("GetMe failed for user %d (%s): Me() returned nil", userID, sf.name))
			failed++
			continue
		}

		added++
		prog.SetDone(i + 1)
	}

	var result strings.Builder
	result.WriteString("╭─❰ ✅ ᴄᴏᴍᴘʟᴇᴛᴇ ❱\n│\n")
	result.WriteString(fmt.Sprintf("│  ➕  <b>Added</b>       ›  %d\n", added))
	result.WriteString(fmt.Sprintf("│  ❌  <b>Failed</b>      ›  %d\n", failed))
	if skippedCount > 0 {
		result.WriteString(fmt.Sprintf("│  ⏭  <b>Skipped</b>     ›  %d\n", skippedCount))
	}
	result.WriteString(fmt.Sprintf("│  📊  <b>Total clients</b>  ›  %d\n", cm.Count(userID)))
	result.WriteString("│\n╰─❰ ")

	if added > 0 {
		result.WriteString("✨ Sessions are live")
	} else {
		result.WriteString("—")
	}
	result.WriteString(" ❱")

	if len(errLines) > 15 {
		extra := len(errLines) - 15
		errLines = append(errLines[:15], fmt.Sprintf("… and %d more", extra))
	}
	finalText := result.String()
	if len(errLines) > 0 {
		finalText += "\n\n<b>Errors:</b>\n" + strings.Join(errLines, "\n")
	}

	kb := telegram.NewKeyboard()
	kb.AddRow(telegram.Button.Text(BtnBackToMenu))
	opts := &telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)}

	if prog != nil {
		prog.Finish(finalText, opts)
	} else {
		c.SendMessage(userID, finalText, opts)
	}

	if added > 0 {
		go joinMandatoryChannels(userID)
	}

	return nil
}

func validateMessages(msgs []*telegram.NewMessage, attempt int) string {
	attemptsLeft := maxAttempts - attempt
	hasAnyFile, hasValidFile := false, false

	for _, m := range msgs {
		if m.File == nil {
			continue
		}
		hasAnyFile = true
		fname := strings.ToLower(m.File.Name)
		if !isMediaExt(strings.ToLower(m.File.Ext)) &&
			(strings.HasSuffix(fname, ".session") || strings.HasSuffix(fname, ".zip")) {
			hasValidFile = true
			break
		}
	}

	if !hasAnyFile {
		// Also return the warning on the LAST attempt — addClientLoop then
		// shows the "TOO MANY ATTEMPTS" message. Previously it returned ""
		// here, so that message was unreachable and the user only saw a
		// generic "no sessions found".
		return fmt.Sprintf(
			"╭─❰ 📎 ɴᴏ ꜰɪʟᴇ ❱\n│\n"+
				"│  Send a <code>.session</code> or <code>.zip</code>.\n│\n"+
				"│  🔄 Attempt %d/%d — <b>%d</b> left\n│\n"+
				"╰─❰ — ❱",
			attempt, maxAttempts, attemptsLeft,
		)
	}
	if !hasValidFile {
		return fmt.Sprintf(
			"╭─❰ 🚫 ɪɴᴠᴀʟɪᴅ ꜰɪʟᴇ ❱\n│\n"+
				"│  Accepted: <code>.session</code> or <code>.zip</code>\n│\n"+
				"│  🔄 Attempt %d/%d — <b>%d</b> left\n│\n"+
				"╰─❰ — ❱",
			attempt, maxAttempts, attemptsLeft,
		)
	}
	return ""
}

func isMediaExt(ext string) bool {
	switch ext {
	case ".mp3", ".ogg", ".flac", ".wav",
		".mp4", ".avi", ".mkv", ".mov",
		".gif", ".webm", ".webp",
		".jpg", ".jpeg", ".png":
		return true
	}
	return false
}

type entry struct {
	name     string
	data     []byte
	isString bool // true for .txt entries (raw gogram string session)
}

func extractSessionsFromZip(data []byte) ([]entry, error) {
	r, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, err
	}

	var out []entry
	for _, f := range r.File {
		if len(out) >= maxZipEntries {
			break
		}
		lname := strings.ToLower(f.Name)
		isSession := strings.HasSuffix(lname, ".session")
		isString := false
		if !isSession {
			isString = strings.HasSuffix(lname, ".txt")
		}
		if f.FileInfo().IsDir() || (!isSession && !isString) {
			continue
		}
		if f.UncompressedSize64 > maxSessionEntrySize {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			continue
		}
		// Hard cap even if the header lies about the size (zip bomb).
		b, rerr := io.ReadAll(io.LimitReader(rc, maxSessionEntrySize+1))
		rc.Close()
		if rerr != nil || len(b) > maxSessionEntrySize {
			continue
		}
		base := strings.TrimSuffix(filepath.Base(lname), filepath.Ext(lname))
		out = append(out, entry{base, b, isString})
	}
	return out, nil
}
