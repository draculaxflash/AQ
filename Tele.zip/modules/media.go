package modules

import (
	"sync"
	"time"

	"github.com/amarnathcjd/gogram/telegram"
)

var (
	groupBuf   = make(map[int64][]*telegram.NewMessage)
	groupMu    sync.Mutex
	groupTimer = make(map[int64]*time.Timer)
)

func handleMediaCollector(m *telegram.NewMessage) error {
	userID := m.SenderID()
	if !cg.IsListening(userID) {
		return nil
	}

	// back button pressed while waiting — cancel the running process so its
	// goroutine cannot race out a "Timed out" message, then let the specific
	// handler fire (start/access panel/add-client menu). The 🚫 Cancel button
	// belongs to the add-client keyboards and must cancel the conversation
	// too — previously its text was forwarded to the flow as input and
	// burned one of the attempts instead of cancelling anything.
	if m.Text() == BtnBackToMenu || m.Text() == BtnBackToAccess || m.Text() == BtnAddClientBack || m.Text() == BtnAddClientCancel {
		ps.cancel(userID)
		return nil
	}
	if m.Text() == "/cancel" {
		cg.StopListening(userID)
		return nil
	}
	// /start must always (re)open the main menu, even mid-conversation:
	// cancel the process, stop listening and let the /start handler run.
	if m.Text() == "/start" {
		ps.cancel(userID)
		cg.StopListening(userID)
		return nil
	}

	groupedID := m.Message.GroupedID

	if groupedID == 0 {
		cg.Send(userID, []*telegram.NewMessage{m})
	} else {
		groupMu.Lock()
		groupBuf[groupedID] = append(groupBuf[groupedID], m)

		if t, ok := groupTimer[groupedID]; ok {
			t.Reset(1 * time.Second)
			groupMu.Unlock()
		} else {
			groupTimer[groupedID] = time.AfterFunc(1*time.Second, func() {
				groupMu.Lock()
				msgs := groupBuf[groupedID]
				delete(groupBuf, groupedID)
				delete(groupTimer, groupedID)
				groupMu.Unlock()

				if len(msgs) > 0 {
					cg.Send(msgs[0].SenderID(), msgs)
				}
			})
			groupMu.Unlock()
		}
	}

	// stop propagation — prevent the remaining handlers in this group from firing
	return telegram.ErrEndGroup
}
