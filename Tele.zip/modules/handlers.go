package modules

import (
	"context"
	"fmt"
	"os"
	"runtime/debug"

	"tgmultibot/config"
	"tgmultibot/manager"

	"github.com/amarnathcjd/gogram/telegram"
)

var (
	c     *telegram.Client
	cm    *manager.ClientManager
	ropts = telegram.BuildReplyOptions{ResizeKeyboard: true}
)

// ── Button text constants (handler matching ke liye) ──
const (
	BtnAddClient       = "➕ Add Client"
	BtnAddByPhone      = "📱 Add by Phone Number"
	BtnUploadSession   = "📤 Upload Session"
	BtnAddClientBack   = "🔙 Back"
	BtnAddClientCancel = "🚫 Cancel"
	BtnMyClients       = "📋 My Clients"
	BtnReact           = "❣️ Send Reaction"
	BtnJoinChannel     = "🔗 Join Channel"
	BtnJoinVoiceChat   = "🎙 Join Voice Chat"
	BtnLeaveVoiceChat  = "🔇 Leave Voice Chat"
	BtnPlayMedia       = "🎵 Player"
	BtnPanelList       = "📋 List Chats"
	BtnPanelAdd        = "➕ Add Chat"
	BtnAutoReact       = "🔁 Auto React"
	BtnAutoView        = "👁 Auto View"
	BtnBackToMenu      = "🔙 Back to Menu"
	BtnSwitchAccess    = "🔄 Switch Access"

	// ── System panel buttons (parity with the reference panels) ──
	BtnUptime     = "⏱ Uptime"
	BtnPing       = "🏓 Ping"
	BtnStatus     = "📊 Status"
	BtnMyInfo     = "👤 My Info"
	BtnSmsInbox   = "📩 SMS Inbox"
	BtnExportZip  = "📤 Export Zip"
	BtnImportZip  = "📦 Import Zip"
	BtnAutoCall   = "🤖 Auto Call"
	BtnClearAuto  = "🧹 Clear My Auto"
	BtnRestartAcc = "🔄 Restart Accounts"

	// Access-related constants. Single source of truth is authorized.go —
	// do NOT redeclare them here (duplicate const = compile error).
)

const handlerGroup = 1

// ── Colour styles ──
const (
	ClrSuccess = "success" // green
	ClrDanger  = "danger"  // red
	ClrPrimary = "primary" // blue
)

// styleOf har button ke liye native colour decide karta hai.
func styleOf(text string) string {
	switch text {
	case BtnAddClient, BtnAddByPhone, BtnUploadSession,
		BtnJoinChannel, BtnJoinVoiceChat,
		BtnAutoCall, BtnExportZip, BtnImportZip:
		return ClrSuccess

	case BtnAddClientCancel, BtnLeaveVoiceChat, BtnClearAuto:
		return ClrDanger

	case BtnMyClients, BtnPanelList, BtnPanelAdd,
		BtnAutoReact, BtnAutoView, BtnReact,
		BtnPlayMedia, BtnSwitchAccess,
		BtnUptime, BtnPing, BtnStatus, BtnMyInfo,
		BtnSmsInbox, BtnRestartAcc:
		return ClrPrimary

	default:
		return "" // neutral — koi colour nahi
	}
}

// styledText reply-keyboard button banata hai aur native colour lagata hai.
// Gogram me ready-made helpers hain: KeyboardButtonObj.Style (tl flag:10) ko
// .Success() / .Danger() / .Primary() set karte hain — reflection ki
// zaroorat nahi (pehle yahan reflect-based applyStyle tha jo na compile
// hota tha na zaroori tha).
func styledText(text string) *telegram.KeyboardButtonObj {
	b := telegram.Button.Text(text)
	switch styleOf(text) {
	case ClrSuccess:
		return b.Success()
	case ClrDanger:
		return b.Danger()
	case ClrPrimary:
		return b.Primary()
	}
	return b
}

// applyStyleInline inline callback button par native colour lagata hai.
// Note: KeyboardButtonStyle gogram ke custom TL layer ka feature hai —
// official Telegram clients ise ignore kar sakte hain, to colours client
// par render ho ya na ho, behaviour same rehta hai.
func applyStyleInline(btn *telegram.KeyboardButtonCallback, style string) *telegram.KeyboardButtonCallback {
	if btn == nil {
		return nil
	}
	switch style {
	case ClrSuccess:
		return btn.Success()
	case ClrDanger:
		return btn.Danger()
	case ClrPrimary:
		return btn.Primary()
	}
	return btn
}

func Load(client *telegram.Client, mgr *manager.ClientManager) error {
	c = client
	cm = mgr

	// Remove media left over from a previous run (crash / restart).
	_ = os.RemoveAll(playMediaDir)

	cm.SetOnPlaybackEnd(func(ownerID int64, chatIDNum int64) {
		go notifyPlayerPlaybackEnd(ownerID, chatIDNum)
	})

	// Register the SMS-inbox + auto-call hooks on every live userbot
	// connection — including the accounts restored from the database AFTER
	// this Load call (RestoreFromDB fires SetOnClientAdded for each).
	cm.SetOnClientAdded(registerClientHooks)
	cm.EachClient(registerClientHooks)

	// Media collector runs before every other handler so uploaded files and
	// albums reach the active conversation listener (OTP, session upload,
	// panel add) instead of being dropped as unhandled messages.
	c.On(telegram.OnMessage, wrap(handleMediaCollector)).SetGroup(handlerGroup)

	c.On("message:/start", wrap(handleStart)).SetGroup(handlerGroup)
	c.On("message:/cancel", wrap(handleCancel)).SetGroup(handlerGroup)
	c.On("message:/help", ownerWrap(handleHelp)).SetGroup(handlerGroup)
	c.On("message:/approved", ownerWrap(handleApprovedUsers)).SetGroup(handlerGroup)
	c.On("message:/approve", ownerWrap(handleApproveUser)).SetGroup(handlerGroup)
	c.On("message:/disapprove", ownerWrap(handleDisapproveUser)).SetGroup(handlerGroup)

	c.On("message:"+BtnAddClient, wrap(handleAddClientPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAddByPhone, wrap(handleAddByPhonePrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnUploadSession, wrap(handleUploadSessionPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAddClientCancel, wrap(handleAddClientCancel)).SetGroup(handlerGroup)
	c.On("message:"+BtnAddClientBack, wrap(handleAddClientBack)).SetGroup(handlerGroup)
	c.On("message:"+BtnMyClients, wrap(handleMyClients)).SetGroup(handlerGroup)
	c.On("message:"+BtnReact, wrap(handleReactPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnJoinChannel, wrap(handleJoinChannelPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnJoinVoiceChat, wrap(handleJoinVoiceChatPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnLeaveVoiceChat, wrap(handleLeaveVoiceChat)).SetGroup(handlerGroup)
	c.On("message:"+BtnPlayMedia, wrap(handlePlayerPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnBackToMenu, wrap(handleStart)).SetGroup(handlerGroup)

	c.On("message:"+BtnAutoReact, wrap(handleAutoReactPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAutoView, wrap(handleAutoViewPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnAutoCall, wrap(handleAutoCallPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnPanelList, wrap(handlePanelListPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnPanelAdd, wrap(handlePanelAddPrompt)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleAutoChatCallback)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleClientCallback)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handlePlayerCallback)).SetGroup(handlerGroup)

	// ── System panel ──
	c.On("message:"+BtnUptime, wrap(handleUptime)).SetGroup(handlerGroup)
	c.On("message:"+BtnPing, wrap(handlePing)).SetGroup(handlerGroup)
	c.On("message:"+BtnStatus, wrap(handleStatus)).SetGroup(handlerGroup)
	c.On("message:"+BtnMyInfo, wrap(handleMyInfo)).SetGroup(handlerGroup)
	c.On("message:"+BtnSmsInbox, wrap(handleSMSInbox)).SetGroup(handlerGroup)
	c.On("message:"+BtnExportZip, wrap(handleExportZip)).SetGroup(handlerGroup)
	c.On("message:"+BtnImportZip, wrap(handleImportZip)).SetGroup(handlerGroup)
	c.On("message:"+BtnClearAuto, wrap(handleClearMyAuto)).SetGroup(handlerGroup)
	c.On("message:"+BtnRestartAcc, wrap(handleRestartAccounts)).SetGroup(handlerGroup)

	c.On("message:"+BtnAccess, wrap(handleAccessPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnGetToken, wrap(handleGetToken)).SetGroup(handlerGroup)
	c.On("message:"+BtnEnterToken, wrap(handleEnterTokenPrompt)).SetGroup(handlerGroup)
	c.On("message:"+BtnMyDelegates, wrap(handleMyDelegates)).SetGroup(handlerGroup)
	c.On("message:"+BtnBackToAccess, wrap(handleAccessPrompt)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleAccessCallback)).SetGroup(handlerGroup)

	c.On("message:"+BtnSwitchAccess, wrap(handleSwitchAccess)).SetGroup(handlerGroup)
	c.On(telegram.OnCallback, wrapCb(handleSwitchAccessCallback)).SetGroup(handlerGroup)

	return nil
}

func handleCancel(m *telegram.NewMessage) error {
	userID := m.SenderID()
	name := ps.current(userID)
	if name == "" {
		_, err := m.Reply(
			"╭─❰ ℹ️ ɴᴏ ᴀᴄᴛɪᴠᴇ ᴘʀᴏᴄᴇꜱꜱ ❱\n│\n"+
				"│  Nothing is running right now.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ps.cancel(userID)

	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnBackToMenu))

	_, err := m.Reply(
		fmt.Sprintf(
			"╭─❰ 🚫 ᴄᴀɴᴄᴇʟʟᴇᴅ ❱\n│\n"+
				"│  Process:  <code>%s</code>\n│\n"+
				"╰─❰ 🔙 Tap Back to Menu to continue ❱",
			escapeHTML(name),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
	)
	return err
}

func guardProcess(m *telegram.NewMessage, name string) (context.Context, bool) {
	kb := telegram.NewKeyboard()
	kb.AddRow(styledText(BtnBackToMenu))
	return guardProcessWithKeyboard(m, name, kb)
}

func guardProcessWithKeyboard(
	m *telegram.NewMessage,
	name string,
	kb *telegram.KeyboardBuilder,
) (context.Context, bool) {
	userID := m.SenderID()
	if existing := ps.current(userID); existing != "" {
		m.Reply(
			fmt.Sprintf(
				"╭─❰ ⚙️ ᴘʀᴏᴄᴇꜱꜱ ʀᴜɴɴɪɴɢ ❱\n│\n"+
					"│  Currently active:  <code>%s</code>\n│\n"+
					"│  Send /cancel to stop it first.\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(existing),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML, ReplyMarkup: kb.BuildReply(ropts)},
		)
		return nil, false
	}
	ctx, ok := ps.tryStart(userID, name)
	return ctx, ok
}

// wrap guards a *message* handler: only private chats, only authorized users,
// always panic-safe, always traceback-logged. telegram.ErrEndGroup is treated
// as a normal short-circuit (used by sendUnauthorizedPrompt and similar) and
// is not logged as an error.
func wrap(fn func(*telegram.NewMessage) error) func(*telegram.NewMessage) error {
	return func(m *telegram.NewMessage) (err error) {
		if !m.IsPrivate() {
			return nil
		}
		defer func() {
			if r := recover(); r != nil {
				sendTraceback(fmt.Sprintf("panic in handler: %v\n%s", r, debug.Stack()))
				err = fmt.Errorf("panic: %v", r)
			}
		}()

		if !isAuthorizedOrOwner(m.SenderID()) {
			return sendUnauthorizedPrompt(m)
		}

		if err = fn(m); err != nil && err != telegram.ErrEndGroup {
			sendTraceback(fmt.Sprintf("error in handler: %v\n%s", err, debug.Stack()))
		}
		return
	}
}

// wrapCb guards a *callback* handler: only private chats, only authorized
// users (except the access-request button, which unauthorized users must be
// able to tap), always panic-safe, always traceback-logged.
func wrapCb(fn func(*telegram.CallbackQuery) error) func(*telegram.CallbackQuery) error {
	return func(cb *telegram.CallbackQuery) (err error) {
		if !cb.IsPrivate() {
			return nil
		}
		defer func() {
			if r := recover(); r != nil {
				sendTraceback(fmt.Sprintf("panic in callback: %v\n%s", r, debug.Stack()))
				err = fmt.Errorf("panic: %v", r)
			}
		}()

		if !isUnauthorizedAccessRequestCallback(cb.DataString()) && !isAuthorizedOrOwner(cb.GetSenderID()) {
			_, err = cb.Answer("🚫 You are not authorized to use this bot.", &telegram.CallbackOptions{Alert: true})
			return
		}

		if err = fn(cb); err != nil {
			sendTraceback(fmt.Sprintf("error in callback: %v\n%s", err, debug.Stack()))
		}
		return
	}
}

// sendTraceback posts a formatted traceback to the configured logger chat.
// The body is HTML-escaped — stack traces routinely contain `<`, `>`, and `&`
// (from generic type names like `map[string]*foo`), and raw `<pre>` blocks
// would otherwise swallow or misrender them.
func sendTraceback(text string) {
	if config.LoggerID == 0 {
		return
	}
	c.SendMessage(
		config.LoggerID,
		"╭─❰ ❌ ᴇʀʀᴏʀ ᴛʀᴀᴄᴇʙᴀᴄᴋ ❱\n\n<pre>"+escapeHTML(text)+"</pre>",
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)
}
