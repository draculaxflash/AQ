package modules

import (
	"errors"
	"fmt"
	"runtime/debug"
	"strconv"
	"strings"

	"tgmultibot/config"
	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

const helpText = `╭─❰ 🎛 ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅꜱ ❱

ɢᴇɴᴇʀᴀʟ
  <code>/start</code>    —  Open the main menu
  <code>/cancel</code>   —  Cancel the current process
  <code>/help</code>     —  Show this help

ꜰᴇᴀᴛᴜʀᴇꜱ
  ➕   <b>Add Client</b>        —  Attach a client via phone or session
  📋   <b>My Clients</b>        —  View / manage attached clients
  ❣️   <b>Send Reaction</b>     —  React to posts
  🔗   <b>Join Channel</b>      —  Join a group or channel
  🎙   <b>Join Voice Chat</b>   —  Join a voice chat
  🔇   <b>Leave Voice Chat</b>  —  Leave all voice chats
  🎵   <b>Player</b>            —  Play audio/video in voice chats
  🔁   <b>Auto React</b>        —  Auto-react to new posts
  👁   <b>Auto View</b>         —  Auto-view posts
  🔑   <b>Access</b>            —  Tokens &amp; delegate management
  🔄   <b>Switch Access</b>     —  Act as another user's clients

ᴏᴡɴᴇʀ ᴏɴʟʏ
  <code>/approved</code>            —  List approved users
  <code>/approve &lt;user&gt;</code>    —  Add an approved user
  <code>/disapprove &lt;user&gt;</code> —  Remove an approved user

╰─❰ ✨ <i>&lt;user&gt; = Telegram ID, @username or t.me link</i> ❱`

func ownerWrap(fn func(*telegram.NewMessage) error) func(*telegram.NewMessage) error {
	return func(m *telegram.NewMessage) error {
		if !m.IsPrivate() {
			return nil
		}
		if config.Owner == nil || m.SenderID() != config.Owner.ID {
			return nil
		}
		defer func() {
			if r := recover(); r != nil {
				trace := fmt.Sprintf("panic in owner handler: %v\n%s", r, debug.Stack())
				sendTraceback(trace)
			}
		}()
		if err := fn(m); err != nil && err != telegram.ErrEndGroup {
			sendTraceback(fmt.Sprintf("error in owner handler: %v\n%s", err, debug.Stack()))
		}
		return nil
	}
}

func handleHelp(m *telegram.NewMessage) error {
	_, err := m.Reply(helpText, &telegram.SendOptions{ParseMode: telegram.HTML})
	return err
}

func handleApprovedUsers(m *telegram.NewMessage) error {
	users, err := database.ListAuthorizedUsers()
	if err != nil {
		sendTraceback(fmt.Sprintf("ListAuthorizedUsers: %v", err))
		_, err := m.Reply(
			"╭─❰ ❌ ʟᴏᴀᴅ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  Could not fetch approved users.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	if len(users) == 0 {
		_, err := m.Reply(
			"╭─❰ ✅ ᴀᴘᴘʀᴏᴠᴇᴅ ᴜꜱᴇʀꜱ ❱\n│\n"+
				"│  No one is approved yet.\n│\n"+
				"│  ➕  <code>/approve &lt;user&gt;</code>\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	var sb strings.Builder
	sb.WriteString("╭─❰ ✅ ᴀᴘᴘʀᴏᴠᴇᴅ ᴜꜱᴇʀꜱ ❱\n│\n")
	sb.WriteString(fmt.Sprintf("│  <b>%d</b> user(s) with access:\n│\n", len(users)))
	for _, userID := range users {
		sb.WriteString("│  " + userLine(userID) + "\n")
	}
	sb.WriteString("│\n")
	sb.WriteString("│  ➕  <b>Add</b>     ›  <code>/approve &lt;user&gt;</code>\n")
	sb.WriteString("│  ➖  <b>Remove</b>  ›  <code>/disapprove &lt;user&gt;</code>\n│\n")
	sb.WriteString("╰─❰ ✨ Tap an ID to copy ❱")

	_, err = m.Reply(sb.String(), &telegram.SendOptions{ParseMode: telegram.HTML})
	return err
}

// userLine renders one approved user as an aligned "icon › id" row.
func userLine(userID int64) string {
	user, err := c.GetUser(userID)
	if err != nil || user == nil {
		return fmt.Sprintf("👤  <code>%d</code>", userID)
	}

	name := strings.TrimSpace(user.FirstName + " " + user.LastName)
	if name == "" {
		name = fmt.Sprintf("User %d", userID)
	}

	if user.Username != "" {
		return fmt.Sprintf("👤  @%s  ›  <code>%d</code>", escapeHTML(user.Username), userID)
	}
	return fmt.Sprintf("👤  <a href=\"tg://user?id=%d\">%s</a>  ›  <code>%d</code>",
		userID, escapeHTML(name), userID)
}

func handleApproveUser(m *telegram.NewMessage) error {
	targetID, err := ownerTargetFromMessage(m)
	if err != nil {
		_, rerr := m.Reply(
			fmt.Sprintf(
				"╭─❰ ⚠️ ɪɴᴠᴀʟɪᴅ ᴛᴀʀɢᴇᴛ ❱\n│\n"+
					"│  %s\n│\n"+
					"│  Usage:  <code>/approve &lt;user&gt;</code>\n"+
					"│  Or reply to that user's message.\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(err.Error()),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return rerr
	}

	if config.Owner != nil && targetID == config.Owner.ID {
		_, err := m.Reply(
			"╭─❰ 👑 ᴏᴡɴᴇʀ ❱\n│\n"+
				"│  The owner is already authorized by\n"+
				"│  default.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ok, err := database.IsAuthorized(targetID)
	if err == nil && ok {
		_, err := m.Reply(
			fmt.Sprintf(
				"╭─❰ ℹ️ ᴀʟʀᴇᴀᴅʏ ᴀᴘᴘʀᴏᴠᴇᴅ ❱\n│\n"+
					"│  %s\n│\n"+
					"╰─❰ — ❱",
				userLine(targetID),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	if err := database.AddAuthorizedUser(targetID); err != nil {
		sendTraceback(fmt.Sprintf("AddAuthorizedUser(%d): %v", targetID, err))
		_, err := m.Reply(
			"╭─❰ ❌ ᴀᴘᴘʀᴏᴠᴇ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  Please try again.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	_, err = m.Reply(
		fmt.Sprintf(
			"╭─❰ ✅ ᴀᴘᴘʀᴏᴠᴇᴅ ❱\n│\n"+
				"│  %s\n│\n"+
				"╰─❰ ✨ They can /start now ❱",
			userLine(targetID),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)
	return err
}

func handleDisapproveUser(m *telegram.NewMessage) error {
	targetID, err := ownerTargetFromMessage(m)
	if err != nil {
		_, rerr := m.Reply(
			fmt.Sprintf(
				"╭─❰ ⚠️ ɪɴᴠᴀʟɪᴅ ᴛᴀʀɢᴇᴛ ❱\n│\n"+
					"│  %s\n│\n"+
					"│  Usage:  <code>/disapprove &lt;user&gt;</code>\n"+
					"│  Or reply to that user's message.\n│\n"+
					"╰─❰ — ❱",
				escapeHTML(err.Error()),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return rerr
	}

	if config.Owner != nil && targetID == config.Owner.ID {
		_, err := m.Reply(
			"╭─❰ 👑 ᴄᴀɴɴᴏᴛ ʀᴇᴍᴏᴠᴇ ❱\n│\n"+
				"│  You can't remove the owner.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	ok, err := database.IsAuthorized(targetID)
	if err == nil && !ok {
		_, err := m.Reply(
			fmt.Sprintf(
				"╭─❰ ℹ️ ɴᴏᴛ ᴀᴘᴘʀᴏᴠᴇᴅ ❱\n│\n"+
					"│  %s\n│\n"+
					"╰─❰ — ❱",
				userLine(targetID),
			),
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	if err := database.RemoveAuthorizedUser(targetID); err != nil {
		sendTraceback(fmt.Sprintf("RemoveAuthorizedUser(%d): %v", targetID, err))
		_, err := m.Reply(
			"╭─❰ ❌ ʀᴇᴍᴏᴠᴇ ꜰᴀɪʟᴇᴅ ❱\n│\n"+
				"│  Please try again.\n│\n"+
				"╰─❰ — ❱",
			&telegram.SendOptions{ParseMode: telegram.HTML},
		)
		return err
	}

	_, err = m.Reply(
		fmt.Sprintf(
			"╭─❰ ✅ ʀᴇᴍᴏᴠᴇᴅ ❱\n│\n"+
				"│  %s\n│\n"+
				"╰─❰ 🚫 They no longer have access ❱",
			userLine(targetID),
		),
		&telegram.SendOptions{ParseMode: telegram.HTML},
	)
	return err
}

// ownerTargetFromMessage resolves the target user for the owner commands.
//   - With an argument: a numeric ID is used directly, otherwise it is resolved
//     via ResolvePeer (supports @username / username / t.me links).
//   - Without an argument: the sender of the replied-to message is used.
func ownerTargetFromMessage(m *telegram.NewMessage) (int64, error) {
	raw := strings.TrimSpace(m.Text())
	raw = strings.TrimPrefix(raw, "/")
	fields := strings.Fields(raw)

	var arg string
	if len(fields) > 1 {
		arg = strings.Join(fields[1:], " ")
	}

	if arg == "" {
		replyID := m.ReplyToMsgID()
		if replyID == 0 {
			return 0, errors.New("no target found")
		}
		msgs, err := c.GetMessages(m.ChatID(), &telegram.SearchOption{IDs: []int32{replyID}})
		if err != nil || len(msgs) == 0 {
			return 0, errors.New("could not fetch the replied message")
		}
		senderID := msgs[0].SenderID()
		if senderID == 0 {
			return 0, errors.New("could not determine the replied message's sender")
		}
		return senderID, nil
	}

	if id, err := strconv.ParseInt(arg, 10, 64); err == nil {
		return id, nil
	}

	clean := strings.TrimSpace(arg)
	clean = strings.TrimPrefix(clean, "https://t.me/")
	clean = strings.TrimPrefix(clean, "http://t.me/")
	clean = strings.TrimPrefix(clean, "@")
	clean = strings.Trim(clean, "/")

	peer, err := c.ResolvePeer(clean)
	if err != nil {
		return 0, fmt.Errorf("could not resolve %q", arg)
	}
	switch p := peer.(type) {
	case *telegram.InputPeerUser:
		return p.UserID, nil
	case *telegram.InputPeerChat:
		return -p.ChatID, nil
	case *telegram.InputPeerChannel:
		return -1000000000000 - p.ChannelID, nil
	}
	return 0, fmt.Errorf("could not resolve %q", arg)
}
