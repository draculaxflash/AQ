package modules

import (
	"tgmultibot/database"

	"github.com/amarnathcjd/gogram/telegram"
)

func handleStart(m *telegram.NewMessage) error {
	userID := m.SenderID()

	ps.cancel(userID)

	go database.AddServedUser(userID)

	text := `╭─❰ 👋 ᴡᴇʟᴄᴏᴍᴇ ʙᴏᴀʀᴅ ❱
│
│  ✨  <b>Client Manager</b>
│      Run bulk actions across many
│      Telegram accounts at once.
│
╰─❰ — ❱

🎯 ꜰᴇᴀᴛᴜʀᴇꜱ

  📱   Unlimited clients via session files
  📋   Manage connected accounts anytime
  ❣️   Bulk reactions on any message
  🔗   Bulk channel &amp; group joins
  🎙   Voice chat join &amp; leave
  🎵   Full-featured voice player
  🔁   Auto-react &amp; auto-view
  🔑   Token-based delegated access

🚀 ɢᴇᴛᴛɪɴɢ ꜱᴛᴀʀᴛᴇᴅ

  𝟭  ➕  <b>Add Client</b>
      Send a <code>.session</code> file to attach

  𝟮  📋  <b>My Clients</b>
      View, inspect or remove accounts

  𝟯  🔄  <b>Switch Access</b>
      Act as a delegated grantor's clients

💡  <i>Send /cancel anytime to stop the current process.</i>`

	_, err := m.Reply(text, &telegram.SendOptions{
		ParseMode:   telegram.HTML,
		ReplyMarkup: buildMenuKB(userID),
	})
	return err
}
